package com.example.ketabkhan

import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.auth.api.identity.Identity
import java.util.Locale

/** General settings: speech engine and voices, OCR, sounds. */
class SettingsActivity : AppCompatActivity() {
    private lateinit var box: LinearLayout
    private var sampleTts: TextToSpeech? = null

    private val authLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        try {
            val data = r.data ?: throw IllegalStateException("no data")
            val res = Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(data)
            if (res.accessToken != null) { Prefs.setOcrEngine(this, "drive"); Ui.toast(this, "ورود به گوگل‌درایو انجام شد.") }
            else Ui.toast(this, "ورود به گوگل‌درایو انجام نشد.")
        } catch (e: Exception) {
            Ui.toast(this, "ورود به گوگل‌درایو انجام نشد.")
        }
        build()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "تنظیمات"
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Ui.BG)
        Ui.rtl(scroll)
        box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val p = Ui.dp(this, 12)
        box.setPadding(p, p, p, p)
        scroll.addView(box)
        setContentView(scroll)
        build()
    }

    override fun onDestroy() {
        sampleTts?.shutdown()
        super.onDestroy()
    }

    private fun add(v: android.view.View) {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, Ui.dp(this, 4), 0, Ui.dp(this, 4))
        box.addView(v, lp)
    }

    private fun check(text: String, on: Boolean, set: (Boolean) -> Unit) {
        val c = CheckBox(this)
        c.text = text
        c.textSize = 16f
        c.setTextColor(Ui.TEXT)
        c.isChecked = on
        c.setOnCheckedChangeListener { _, b -> set(b) }
        add(c)
    }

    private fun build() {
        box.removeAllViews()
        val head = Ui.label(this, "تنظیمات", 22f, Ui.TEXT, true)
        androidx.core.view.ViewCompat.setAccessibilityHeading(head, true)
        add(head)

        add(Ui.label(this, "متن به گفتار", 18f, Ui.ACCENT, true))
        add(Ui.button(this, "موتور متن به گفتار: " + (Prefs.engine(this) ?: "پیش‌فرض گوشی"), false) { pickEngine() })
        add(Ui.button(this, "صدای فارسی: " + (Prefs.voiceFa(this) ?: "پیش‌فرض"), false) { pickVoice(true) })
        add(Ui.button(this, "صدای انگلیسی: " + (Prefs.voiceEn(this) ?: "پیش‌فرض"), false) { pickVoice(false) })
        add(Ui.button(this, "تنظیمات متن به گفتارِ سیستم", false) {
            try { startActivity(android.content.Intent("com.android.settings.TTS_SETTINGS")) }
            catch (e: Exception) { Ui.toast(this, "این صفحه باز نشد.") }
        })

        add(Ui.label(this, "تشخیص متن (OCR)", 18f, Ui.ACCENT, true))
        val engine = if (Prefs.ocrEngine(this) == "drive") "گوگل‌درایو (آنلاین)" else "آفلاین (Tesseract)"
        add(Ui.button(this, "موتور OCR: $engine", false) {
            Ui.choose(this, "موتور تشخیص متن", listOf("آفلاین (Tesseract)", "گوگل‌درایو (آنلاین، معمولاً دقیق‌تر)")) { i ->
                if (i == 0) { Prefs.setOcrEngine(this, "tess"); build() }
                else Ui.confirm(this, "در این حالت، عکسِ هر صفحه به صورت موقت در گوگل‌درایوِ خودتان بارگذاری، با گوگل خوانده و بلافاصله پاک می‌شود. به اینترنت و ورود با حساب گوگل نیاز دارد. ادامه می‌دهید؟") { enableDrive() }
            }
        })
        val model = if (Prefs.ocrModel(this) == "best") "دقیق (کندتر)" else "سریع"
        add(Ui.button(this, "مدل: $model", false) {
            Ui.choose(this, "مدل تشخیص متن", listOf("دقیق (کندتر)", "سریع")) { i ->
                Prefs.setOcrModel(this, if (i == 0) "best" else "fast"); build()
            }
        })
        val lang = when (Prefs.ocrLang(this)) { "fas" -> "فقط فارسی"; "eng" -> "فقط انگلیسی"; else -> "فارسی و انگلیسی" }
        add(Ui.button(this, "زبان: $lang", false) {
            Ui.choose(this, "زبان تشخیص متن", listOf("فارسی و انگلیسی", "فقط فارسی", "فقط انگلیسی")) { i ->
                Prefs.setOcrLang(this, when (i) { 1 -> "fas"; 2 -> "eng"; else -> "all" }); build()
            }
        })
        add(Ui.label(this, "تغییر موتور، مدل یا زبان برای کتاب‌هایی که از این پس ساخته می‌شوند اعمال می‌شود. اگر درایو در دسترس نباشد، به صورت خودکار از حالت آفلاین استفاده می‌شود.", 13f, Ui.TEXT2))

        add(Ui.label(this, "عمومی", 18f, Ui.ACCENT, true))
        check("به خواندن کتاب صوتی، هنگام تعویض برنامه یا خاموش کردن صفحه ادامه بده", Prefs.bgRead(this)) { Prefs.setBgRead(this, it) }
        check("صدای مشخص کننده‌ی تکمیلِ پردازش", Prefs.doneSound(this)) { Prefs.setDoneSound(this, it) }
        check("صدای ورق زدن", Prefs.pageSound(this)) { Prefs.setPageSound(this, it) }
    }

    private fun enableDrive() {
        Identity.getAuthorizationClient(this).authorize(DriveOcr.request())
            .addOnSuccessListener { res ->
                val pi = res.pendingIntent
                if (res.hasResolution() && pi != null) {
                    authLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                } else {
                    Prefs.setOcrEngine(this, "drive")
                    Ui.toast(this, "ورود به گوگل‌درایو انجام شد.")
                    build()
                }
            }
            .addOnFailureListener {
                Ui.toast(this, "ورود به گوگل ممکن نیست. اینترنت، سرویس‌های گوگل‌پلی و ثبت پروژه در گوگل را بررسی کنید.")
            }
    }

    private fun pickEngine() {
        var tmp: TextToSpeech? = null
        tmp = TextToSpeech(this) { st ->
            val list = if (st == TextToSpeech.SUCCESS) (tmp?.engines ?: emptyList()) else emptyList()
            runOnUiThread {
                tmp?.shutdown()
                if (list.isEmpty()) { Ui.toast(this, "متن‌به‌گفتار نصب نیست. لطفا یک موتور متن‌به‌گفتار نصب کنید."); return@runOnUiThread }
                val names = listOf("پیش‌فرض گوشی") + list.map { it.label ?: it.name }
                Ui.choose(this, "موتور متن به گفتار را انتخاب کنید", names) { i ->
                    Prefs.setEngine(this, if (i == 0) null else list[i - 1].name)
                    Prefs.setVoiceFa(this, null)
                    Prefs.setVoiceEn(this, null)
                    build()
                }
            }
        }
    }

    private fun pickVoice(persian: Boolean) {
        sampleTts?.shutdown()
        var t: TextToSpeech? = null
        t = TextToSpeech(this, { st ->
            runOnUiThread {
                val tts = t
                if (st != TextToSpeech.SUCCESS || tts == null) { Ui.toast(this, "خطای غیرمنتظره هنگام راه‌اندازی موتور تبدیل متن به گفتار."); return@runOnUiThread }
                val voices = try {
                    (tts.voices ?: emptySet()).filter {
                        if (persian) TtsUtil.isPersianVoice(it.locale) else it.locale.language.equals("en", true)
                    }.sortedBy { it.name }
                } catch (e: Exception) { emptyList() }
                if (voices.isEmpty()) {
                    Ui.toast(this, "صدایی برای این زبان در موتور انتخاب‌شده پیدا نشد. زبان را در تنظیمات متن به گفتار سیستم نصب کنید.")
                    tts.shutdown()
                    return@runOnUiThread
                }
                sampleTts = tts
                val names = listOf("پیش‌فرض") + voices.map { it.name + " (" + it.locale.toString() + ")" }
                Ui.choose(this, "صدا را انتخاب کنید", names) { i ->
                    val v = if (i == 0) null else voices[i - 1]
                    if (persian) Prefs.setVoiceFa(this, v?.name) else Prefs.setVoiceEn(this, v?.name)
                    if (v != null) {
                        tts.voice = v
                        tts.speak(if (persian) "این یک نمونه صدا است." else "This is a voice sample.", TextToSpeech.QUEUE_FLUSH, null, "sample")
                    }
                    build()
                }
            }
        }, Prefs.engine(this))
    }
}
