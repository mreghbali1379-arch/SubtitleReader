package com.example.ketabkhan

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Collects the photos of a book's pages (camera or gallery), then starts reading them. */
class PhotosActivity : AppCompatActivity() {
    private lateinit var listBox: LinearLayout
    private lateinit var status: TextView
    private lateinit var scroll: ScrollView

    private val camFile get() = File(File(cacheDir, "cam").apply { mkdirs() }, "shot.jpg")

    private val takePicture = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) addPhoto(Uri.fromFile(camFile))
    }
    private val pickImages = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            Thread {
                for (u in uris) ImageUtil.importTo(this, u, Stage.next(this))
                runOnUiThread { refresh() }
            }.start()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "میزان کردن عکس"
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        Ui.rtl(root)
        val pad = Ui.dp(this, 12)
        root.setPadding(pad, pad, pad, pad)

        val head = Ui.label(this, "عکس‌های کتاب", 22f, Ui.TEXT, true)
        androidx.core.view.ViewCompat.setAccessibilityHeading(head, true)
        root.addView(head)
        root.addView(Ui.label(this, "برای دقت بیشتر، از وجود نور کافی مطمئن شوید و صفحه‌ی حاوی متن را تا حد امکان صاف نگه دارید.", 14f, Ui.TEXT2))
        status = Ui.label(this, "", 16f, Ui.TEXT)
        status.setPadding(0, pad, 0, pad)
        root.addView(status)

        scroll = ScrollView(this)
        listBox = LinearLayout(this)
        listBox.orientation = LinearLayout.VERTICAL
        scroll.addView(listBox)
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        root.addView(Ui.button(this, "افزودن عکس بعدی با دوربین", false) { camera() })
        root.addView(Ui.button(this, "افزودن عکس از گالری", false) { pickImages.launch(arrayOf("image/*")) })
        root.addView(Ui.button(this, "خواندنِ متن") { create() })
        setContentView(root)

        if (savedInstanceState == null && intent.getBooleanExtra("camera", false)) camera()
        refresh()
    }

    private fun camera() {
        try {
            val uri = FileProvider.getUriForFile(this, packageName + ".files", camFile)
            takePicture.launch(uri)
        } catch (e: Exception) {
            Ui.toast(this, "دوربین باز نشد.")
        }
    }

    private fun addPhoto(src: Uri) {
        Thread {
            ImageUtil.importTo(this, src, Stage.next(this))
            camFile.delete()
            runOnUiThread { refresh() }
        }.start()
    }

    private fun refresh() {
        val files = Stage.files(this)
        listBox.removeAllViews()
        status.text = if (files.isEmpty()) "عکسی بارگذاری نشد" else "تعداد عکس‌ها: ${files.size}"
        files.forEachIndexed { i, f ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.setPadding(0, Ui.dp(this, 6), 0, Ui.dp(this, 6))
            val img = ImageView(this)
            img.setImageBitmap(ImageUtil.loadFile(f, 260))
            img.contentDescription = "عکس ${i + 1} از ${files.size}"
            img.scaleType = ImageView.ScaleType.CENTER_CROP
            row.addView(img, LinearLayout.LayoutParams(Ui.dp(this, 90), Ui.dp(this, 120)))
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.setPadding(Ui.dp(this, 10), 0, 0, 0)
            col.addView(Ui.label(this, "عکس ${i + 1}", 16f))
            col.addView(Ui.button(this, "چرخاندن عکس ${i + 1}", false) {
                Thread { ImageUtil.rotateFile(f); runOnUiThread { refresh() } }.start()
            })
            col.addView(Ui.button(this, "پاک کردن عکس ${i + 1}", false) {
                Ui.confirm(this, "آیا میخواهید این عکس را پاک کنید؟") {
                    f.delete()
                    Ui.toast(this, "عکس پاک شد.")
                    refresh()
                }
            })
            row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            listBox.addView(row)
        }
    }

    private fun create() {
        val files = Stage.files(this)
        if (files.isEmpty()) { Ui.toast(this, "عکسی بارگذاری نشد"); return }
        val def = "عکس‌ها " + SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date())
        Ui.input(this, "نام کتاب صوتی را وارد کنید", def) { n ->
            val m = BookStore.create(this, n.trim().ifEmpty { def }, "images", files.size)
            val dir = File(BookStore.dir(this, m.id), "images").apply { mkdirs() }
            files.forEachIndexed { i, f -> f.copyTo(File(dir, String.format("%05d.jpg", i)), true) }
            Stage.clear(this)
            Processor.start(this, m.id)
            startActivity(Intent(this, PlayerActivity::class.java).putExtra("id", m.id))
            finish()
        }
    }
}
