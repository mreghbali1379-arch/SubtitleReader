package com.example.ketabkhan

import android.content.Context

/** Small settings store shared by all screens. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** Package name of the chosen speech engine, or null for the phone's default. */
    fun engine(c: Context): String? = sp(c).getString("tts_engine", null)
    fun setEngine(c: Context, e: String?) { sp(c).edit().putString("tts_engine", e).apply() }

    fun voiceFa(c: Context): String? = sp(c).getString("voice_fa", null)
    fun setVoiceFa(c: Context, v: String?) { sp(c).edit().putString("voice_fa", v).apply() }
    fun voiceEn(c: Context): String? = sp(c).getString("voice_en", null)
    fun setVoiceEn(c: Context, v: String?) { sp(c).edit().putString("voice_en", v).apply() }

    fun rate(c: Context): Float = sp(c).getFloat("rate", 1.0f)
    fun setRate(c: Context, v: Float) { sp(c).edit().putFloat("rate", v).apply() }
    fun pitch(c: Context): Float = sp(c).getFloat("pitch", 1.0f)
    fun setPitch(c: Context, v: Float) { sp(c).edit().putFloat("pitch", v).apply() }
    fun fontSp(c: Context): Int = sp(c).getInt("font_sp", 20)
    fun setFontSp(c: Context, v: Int) { sp(c).edit().putInt("font_sp", v).apply() }

    /** page, para, sentence, word or wordspell */
    fun navMode(c: Context): String = sp(c).getString("nav_mode", "sentence") ?: "sentence"
    fun setNavMode(c: Context, v: String) { sp(c).edit().putString("nav_mode", v).apply() }

    /** OCR language: "all" or one code such as fas / eng. */
    fun ocrLang(c: Context): String = sp(c).getString("ocr_lang", "all") ?: "all"
    fun setOcrLang(c: Context, v: String) { sp(c).edit().putString("ocr_lang", v).apply() }
    /** OCR model: "best" (more accurate, slower) or "fast". */
    fun ocrModel(c: Context): String = sp(c).getString("ocr_model", "best") ?: "best"
    fun setOcrModel(c: Context, v: String) { sp(c).edit().putString("ocr_model", v).apply() }

    /** "tess" = offline Tesseract, "drive" = Google Drive OCR (needs internet and sign-in). */
    fun ocrEngine(c: Context): String = sp(c).getString("ocr_engine", "tess") ?: "tess"
    fun setOcrEngine(c: Context, v: String) { sp(c).edit().putString("ocr_engine", v).apply() }

    fun bgRead(c: Context): Boolean = sp(c).getBoolean("bg_read", true)
    fun setBgRead(c: Context, v: Boolean) { sp(c).edit().putBoolean("bg_read", v).apply() }
    fun doneSound(c: Context): Boolean = sp(c).getBoolean("done_sound", true)
    fun setDoneSound(c: Context, v: Boolean) { sp(c).edit().putBoolean("done_sound", v).apply() }
    fun pageSound(c: Context): Boolean = sp(c).getBoolean("page_sound", false)
    fun setPageSound(c: Context, v: Boolean) { sp(c).edit().putBoolean("page_sound", v).apply() }
}
