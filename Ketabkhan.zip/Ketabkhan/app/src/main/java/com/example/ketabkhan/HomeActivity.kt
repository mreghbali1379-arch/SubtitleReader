package com.example.ketabkhan

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** First screen: the library of audiobooks and the way to make a new one. */
class HomeActivity : AppCompatActivity() {
    private lateinit var listView: ListView
    private lateinit var empty: TextView
    private lateinit var search: EditText
    private var shown: List<BookMeta> = emptyList()

    private val pick = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) handleUris(uris)
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "کتاب‌خوان"
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        Ui.rtl(root)
        val pad = Ui.dp(this, 12)
        root.setPadding(pad, pad, pad, pad)

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        val head = Ui.label(this, "کتاب‌خانه‌ی من", 22f, Ui.TEXT, true)
        head.setPadding(0, 0, 0, Ui.dp(this, 8))
        androidx.core.view.ViewCompat.setAccessibilityHeading(head, true)
        top.addView(head, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(Ui.button(this, "منو", false) { showMenu() })
        root.addView(top)

        search = EditText(this)
        search.hint = "جستجو در کتاب‌های صوتی"
        search.contentDescription = "جستجو در کتاب‌های صوتی"
        search.setTextColor(Ui.TEXT)
        search.setHintTextColor(Ui.TEXT2)
        search.setSingleLine()
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { reload() }
        })
        root.addView(search)

        val frame = FrameLayout(this)
        listView = ListView(this)
        listView.divider = null
        empty = Ui.label(this, WELCOME, 17f, Ui.TEXT2)
        empty.setPadding(Ui.dp(this, 8), Ui.dp(this, 24), Ui.dp(this, 8), 0)
        frame.addView(listView)
        frame.addView(empty)
        root.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        root.addView(Ui.button(this, "ایجاد کتاب صوتی جدید") { showCreate() })
        setContentView(root)

        listView.setOnItemClickListener { _, _, pos, _ -> open(shown[pos]) }
        listView.setOnItemLongClickListener { _, _, pos, _ -> bookMenu(shown[pos]); true }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        Processor.listener = { reload() }
        reload()
    }

    override fun onPause() {
        super.onPause()
        Processor.listener = null
    }

    @Suppress("DEPRECATION")
    private fun streamUris(i: Intent): List<Uri> {
        val out = ArrayList<Uri>()
        if (i.action == Intent.ACTION_SEND_MULTIPLE) {
            i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.let { out.addAll(it) }
        } else {
            i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.let { out.add(it) }
        }
        return out
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val uris = ArrayList<Uri>()
        when (i.action) {
            Intent.ACTION_VIEW -> i.data?.let { uris.add(it) }
            Intent.ACTION_SEND, Intent.ACTION_SEND_MULTIPLE -> {
                uris.addAll(streamUris(i))
                val t = i.getStringExtra(Intent.EXTRA_TEXT)
                if (uris.isEmpty() && !t.isNullOrBlank()) { i.action = null; createText(t); return }
            }
        }
        if (uris.isNotEmpty()) {
            i.action = null
            handleUris(uris)
        }
    }

    private fun reload() {
        val q = search.text.toString().trim()
        val all = BookStore.list(this)
        shown = if (q.isEmpty()) all else all.filter { it.name.contains(q, true) }
        empty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        empty.text = if (q.isNotEmpty()) "کتاب صوتی‌ای با این نام پیدا نشد." else WELCOME
        listView.adapter = object : BaseAdapter() {
            override fun getCount() = shown.size
            override fun getItem(p: Int) = shown[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
                val m = shown[p]
                val row = LinearLayout(this@HomeActivity)
                row.orientation = LinearLayout.VERTICAL
                val pd = Ui.dp(this@HomeActivity, 14)
                row.setPadding(pd, pd, pd, pd)
                row.setBackgroundColor(if (p % 2 == 0) Ui.BAR else Ui.BG)
                val running = Processor.isRunning(m.id)
                val sub = when {
                    m.total == 0 -> "در حال آماده‌سازی..."
                    m.done < m.total && running -> "در حال پردازش: صفحه‌ی ${m.done} از ${m.total}"
                    m.done < m.total -> "پردازش ناتمام: ${m.done} از ${m.total} صفحه"
                    else -> "${m.total} صفحه — صفحه‌ی جاری: ${m.page + 1}"
                }
                row.addView(Ui.label(this@HomeActivity, m.name, 18f, Ui.TEXT, true))
                row.addView(Ui.label(this@HomeActivity, sub, 14f, Ui.TEXT2))
                return row
            }
        }
    }

    private fun open(m: BookMeta) {
        val i = Intent(this, PlayerActivity::class.java)
        i.putExtra("id", m.id)
        startActivity(i)
    }

    private fun bookMenu(m: BookMeta) {
        val items = ArrayList<String>()
        items.add("تغییر نام")
        items.add("پاک کردن کتاب صوتی")
        items.add("اشتراک‌گذاری به عنوان فایل زیپ‌شده (پشتیبان)")
        val incomplete = m.total > 0 && m.done < m.total && !Processor.isRunning(m.id)
        if (incomplete) items.add("پردازش صفحه‌های باقیمانده")
        Ui.choose(this, m.name, items) { i ->
            when (i) {
                0 -> Ui.input(this, "نام کتاب صوتی را وارد کنید", m.name) { n ->
                    if (n.isNotBlank()) { BookStore.update(this, m.id) { it.name = n.trim() }; reload() }
                }
                1 -> Ui.confirm(this, "آیا میخواهید کتاب صوتیِ «${m.name}» را پاک کنید؟") {
                    Processor.cancel(m.id)
                    BookStore.delete(this, m.id)
                    Ui.toast(this, "کتاب صوتی پاک شد")
                    reload()
                }
                2 -> Thread {
                    val f = Exporter.makeZip(this, m)
                    runOnUiThread { Exporter.share(this, f) }
                }.start()
                3 -> { Processor.start(this, m.id); reload() }
            }
        }
    }

    private fun showMenu() {
        Ui.choose(this, "منو", listOf("تنظیمات", "نحوه‌ی استفاده از برنامه", "درباره‌ی برنامه")) { i ->
            when (i) {
                0 -> startActivity(Intent(this, SettingsActivity::class.java))
                1 -> Ui.message(this, "نحوه‌ی استفاده", HELP)
                2 -> Ui.message(this, "کتاب‌خوان", "برنامه‌ی خواندن متن به صورت کتاب صوتی، بدون نیاز به اینترنت، برای فارسی و انگلیسی. تشخیص متن (OCR) و تبدیل متن به گفتار روی خود گوشی انجام می‌شود.")
            }
        }
    }

    private fun showCreate() {
        Ui.choose(this, "ایجاد کتاب صوتی جدید", listOf(
            "بارگذاری فایل (PDF، عکس، DOCX، TXT، PPT، اکسل یا زیپ پشتیبان)",
            "عکس گرفتن با دوربین",
            "خواندن متن کپی‌شده",
            "نوشتن متن"
        )) { i ->
            when (i) {
                0 -> pick.launch(arrayOf("*/*"))
                1 -> { Stage.clear(this); startActivity(Intent(this, PhotosActivity::class.java).putExtra("camera", true)) }
                2 -> {
                    val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    val t = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
                    if (t.isNullOrBlank()) Ui.toast(this, "متنِ کپی‌شده موجود نیست. نخست، متنی کپی و سپس روی این گزینه کلیک کنید.")
                    else createText(t)
                }
                3 -> Ui.input(this, "متن را وارد کنید", "", true) { t ->
                    if (t.isBlank()) Ui.toast(this, "کادرِ متن خالیست.") else createText(t)
                }
            }
        }
    }

    private fun handleUris(uris: List<Uri>) {
        val kinds = uris.map { Importer.kindOf(this, it) }
        if (kinds.all { it == "image" }) { stageImages(uris); return }
        val i = kinds.indexOfFirst { it != "image" && it.isNotEmpty() }
        if (i < 0) { Ui.toast(this, "فعلا نمیتوانم این فایل را پردازش کنم"); return }
        val u = uris[i]
        val name = Importer.nameOf(this, u).substringBeforeLast('.')
        when (kinds[i]) {
            "pdf" -> createPdf(u, name)
            "zip" -> importZip(u)
            else -> createDoc(u, name, kinds[i])
        }
    }

    private fun stageImages(uris: List<Uri>) {
        Ui.toast(this, "در حال آماده‌سازی عکس‌ها، لطفا منتظر بمانید")
        Stage.clear(this)
        Thread {
            for (u in uris) ImageUtil.importTo(this, u, Stage.next(this))
            runOnUiThread { startActivity(Intent(this, PhotosActivity::class.java)) }
        }.start()
    }

    private fun createText(t: String) {
        val m = BookStore.create(this, "متن " + SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date()), "text")
        File(BookStore.dir(this, m.id), "source").writeText(t)
        Processor.start(this, m.id)
        open(m)
    }

    private fun createDoc(u: Uri, name: String, kind: String) {
        Ui.toast(this, "در حال آماده‌سازی فایل، لطفا منتظر بمانید")
        Thread {
            val m = BookStore.create(this, name, kind)
            val ok = Importer.copy(this, u, File(BookStore.dir(this, m.id), "source"))
            runOnUiThread {
                if (!ok) { BookStore.delete(this, m.id); Ui.toast(this, "فایل خوانده نشد.") }
                else { Processor.start(this, m.id); open(m) }
            }
        }.start()
    }

    private fun createPdf(u: Uri, name: String) {
        Ui.toast(this, "در حال بررسی فایل PDF")
        Thread {
            val tmp = File(cacheDir, "pending.pdf")
            var pages = 0
            var err = ""
            if (!Importer.copy(this, u, tmp)) err = "فایل خوانده نشد."
            else try {
                val pfd = ParcelFileDescriptor.open(tmp, ParcelFileDescriptor.MODE_READ_ONLY)
                val r = PdfRenderer(pfd)
                pages = r.pageCount
                r.close()
                pfd.close()
            } catch (e: SecurityException) {
                err = "این PDF رمزدار است و فعلا پشتیبانی نمی‌شود."
            } catch (e: Exception) {
                err = "این فایل PDF باز نشد."
            }
            runOnUiThread {
                if (err.isNotEmpty() || pages == 0) { Ui.toast(this, err.ifEmpty { "صفحه‌ای پیدا نشد." }); return@runOnUiThread }
                askRange(tmp, name, pages)
            }
        }.start()
    }

    private fun askRange(tmp: File, name: String, pages: Int) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        Ui.rtl(box)
        val p = Ui.dp(this, 20)
        box.setPadding(p, p, p, 0)
        val from = EditText(this)
        from.setText("1"); from.hint = "از صفحه"; from.contentDescription = "از صفحه"
        from.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        val to = EditText(this)
        to.setText(pages.toString()); to.hint = "تا صفحه"; to.contentDescription = "تا صفحه"
        to.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        box.addView(Ui.label(this, "تعداد صفحات فایل: $pages", 15f, Ui.TEXT2))
        box.addView(from)
        box.addView(to)
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("انتخابِ صفحات")
            .setView(box)
            .setPositiveButton("تایید") { _, _ ->
                val a = from.text.toString().toIntOrNull() ?: 0
                val b = to.text.toString().toIntOrNull() ?: 0
                if (a < 1 || b > pages || a > b) {
                    Ui.toast(this, "لطفا مقداری بینِ ۱ و $pages وارد کنید و «از صفحه» باید کوچکتر یا مساوی «تا صفحه» باشد.")
                    tmp.delete()
                } else {
                    val m = BookStore.create(this, name, "pdf", b - a + 1, a - 1)
                    tmp.copyTo(File(BookStore.dir(this, m.id), "source"), true)
                    tmp.delete()
                    Processor.start(this, m.id)
                    open(m)
                }
            }
            .setNegativeButton("لغو") { _, _ -> tmp.delete() }
            .show()
    }

    private fun importZip(u: Uri) {
        Ui.toast(this, "در حال بازیابی کتاب صوتی")
        Thread {
            val tmp = File(cacheDir, "restore.zip")
            val ok = Importer.copy(this, u, tmp) && Exporter.importZip(this, tmp)
            tmp.delete()
            runOnUiThread {
                if (ok) { Ui.toast(this, "کتاب صوتی بازیابی شد"); reload() }
                else Ui.toast(this, "این یک فایل زیپ کتاب صوتی معتبر نیست.")
            }
        }.start()
    }

    companion object {
        const val WELCOME = "خوش آمدید!\nکتاب‌خانه‌ی شما خالی است.\nبرای ساختن کتاب صوتی از عکس کتاب و دست‌نوشته، فایل PDF، DOCX، PPT، اکسل و TXT، دکمه‌ی «ایجاد کتاب صوتی جدید» را بزنید. می‌توانید فایل‌ها را از برنامه‌های دیگر هم با «اشتراک‌گذاری» یا «باز کردن با» به این برنامه بفرستید."
        const val HELP = "۱. روی «ایجاد کتاب صوتی جدید» بزنید و یک فایل یا عکس بدهید. می‌توانید با دوربین از صفحه‌ی کتاب عکس بگیرید؛ نور کافی باشد و صفحه را صاف نگه دارید.\n\n" +
            "۲. برنامه متن را روی خود گوشی تشخیص می‌دهد. می‌توانید از همان صفحه‌های اول شروع به گوش دادن کنید و پردازش در پس‌زمینه ادامه می‌یابد.\n\n" +
            "۳. در پخش‌کننده، دکمه‌های قبلی و بعدی بر اساس «حالت پیمایش» (صفحه، پاراگراف، جمله، کلمه یا کلمه با هجی کردن) جابه‌جا می‌شوند. حالت را از «تنظیمات» عوض کنید.\n\n" +
            "۴. در «ابزارها» نشان‌گذاری، یادداشت متنی و صوتی، جستجو، ویرایش متن، متنِ ازقلم‌افتاده، آمار و اشتراک‌گذاری هست.\n\n" +
            "۵. برای پشتیبان‌گیری، کتاب را به صورت فایل زیپ به اشتراک بگذارید و بعدا از «بارگذاری فایل» دوباره بارگذاری کنید."
    }
}
