package com.example.ketabkhan

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/** Colors and small view helpers shared by the screens. */
object Ui {
    val BG = 0xFF121212.toInt()
    val BAR = 0xFF1F1F1F.toInt()
    val ACCENT = 0xFF2196F3.toInt()
    val TEXT = 0xFFEEEEEE.toInt()
    val TEXT2 = 0xFFB0B0B0.toInt()

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun rtl(v: View) { v.layoutDirection = View.LAYOUT_DIRECTION_RTL }

    fun label(c: Context, text: String, sp: Float = 16f, color: Int = TEXT, bold: Boolean = false): TextView {
        val t = TextView(c)
        t.text = text
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        t.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
        return t
    }

    fun button(c: Context, text: String, filled: Boolean = true, onClick: () -> Unit): Button {
        val b = Button(c)
        b.text = text
        b.isAllCaps = false
        b.textSize = 16f
        b.setTextColor(Color.WHITE)
        val g = GradientDrawable()
        g.cornerRadius = dp(c, 10).toFloat()
        g.setColor(if (filled) ACCENT else 0xFF333333.toInt())
        b.background = g
        b.minimumHeight = dp(c, 52)
        b.setOnClickListener { onClick() }
        return b
    }

    fun icon(c: Context, res: Int, desc: String, sizeDp: Int = 56, onClick: () -> Unit): ImageButton {
        val b = ImageButton(c)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(0xFF2A2A2A.toInt())
        b.background = g
        b.setImageResource(res)
        b.scaleType = ImageView.ScaleType.FIT_CENTER
        val p = dp(c, 12)
        b.setPadding(p, p, p, p)
        b.contentDescription = desc
        b.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp))
        lp.setMargins(dp(c, 4), dp(c, 4), dp(c, 4), dp(c, 4))
        b.layoutParams = lp
        return b
    }

    fun toast(c: Context, m: String) { Toast.makeText(c, m, Toast.LENGTH_LONG).show() }

    fun confirm(a: AppCompatActivity, msg: String, onYes: () -> Unit) {
        AlertDialog.Builder(a).setMessage(msg)
            .setPositiveButton("بله") { _, _ -> onYes() }
            .setNegativeButton("خیر", null).show()
    }

    fun message(a: AppCompatActivity, title: String, msg: String) {
        AlertDialog.Builder(a).setTitle(title).setMessage(msg).setPositiveButton("بستن", null).show()
    }

    fun choose(a: AppCompatActivity, title: String, items: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(a).setTitle(title)
            .setItems(items.toTypedArray()) { _, i -> onPick(i) }
            .setNegativeButton("بستن", null).show()
    }

    fun input(a: AppCompatActivity, title: String, initial: String = "", multiline: Boolean = false,
              number: Boolean = false, onOk: (String) -> Unit) {
        val e = EditText(a)
        e.setText(initial)
        e.inputType = when {
            number -> InputType.TYPE_CLASS_NUMBER
            multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            else -> InputType.TYPE_CLASS_TEXT
        }
        if (multiline) { e.minLines = 6; e.gravity = Gravity.TOP }
        e.contentDescription = title
        rtl(e)
        val box = FrameLayout(a)
        val p = dp(a, 20)
        box.setPadding(p, dp(a, 8), p, 0)
        box.addView(e)
        AlertDialog.Builder(a).setTitle(title).setView(box)
            .setPositiveButton("تایید") { _, _ -> onOk(e.text.toString()) }
            .setNegativeButton("لغو", null).show()
    }
}
