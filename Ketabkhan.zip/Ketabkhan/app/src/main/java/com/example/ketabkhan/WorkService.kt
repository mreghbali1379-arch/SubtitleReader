package com.example.ketabkhan

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/** Keeps the app alive (and the CPU awake) while a book is being made or read with the screen off. */
class WorkService : Service() {
    private var wl: PowerManager.WakeLock? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ketabkhan:work")
        wl?.acquire(6 * 60 * 60 * 1000L)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!isNeeded()) { stopSelf(); return START_NOT_STICKY }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("work", "کتاب‌خوان", NotificationManager.IMPORTANCE_LOW))
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, HomeActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, "work")
            .setContentTitle("کتاب‌خوان")
            .setContentText("در حال ساختن یا خواندن کتاب صوتی")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC or ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, n)
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        wl?.let { if (it.isHeld) it.release() }
        super.onDestroy()
    }

    companion object {
        private var count = 0

        @Synchronized fun isNeeded(): Boolean = count > 0

        @Synchronized fun acquire(c: Context) {
            count++
            if (count == 1) {
                try { ContextCompat.startForegroundService(c, Intent(c, WorkService::class.java)) } catch (e: Exception) { }
            }
        }

        @Synchronized fun release(c: Context) {
            if (count > 0) count--
            if (count == 0) {
                try { c.stopService(Intent(c, WorkService::class.java)) } catch (e: Exception) { }
            }
        }
    }
}
