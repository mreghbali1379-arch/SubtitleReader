package com.example.ketabkhan

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.File

object ImageUtil {
    private fun sample(w: Int, h: Int, maxSide: Int): Int {
        var s = 1
        while (maxOf(w, h) / s > maxSide * 2) s *= 2
        return s
    }

    private fun scaleDown(b: Bitmap, maxSide: Int): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= maxSide) return b
        val f = maxSide.toFloat() / m
        val r = Bitmap.createScaledBitmap(b, (b.width * f).toInt().coerceAtLeast(1), (b.height * f).toInt().coerceAtLeast(1), true)
        if (r !== b) b.recycle()
        return r
    }

    /** Reads a picked picture, applies its camera rotation and saves it as a JPEG file. */
    fun importTo(c: Context, uri: Uri, dest: File): Boolean {
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            if (opts.outWidth <= 0) return false
            val o2 = BitmapFactory.Options().apply { inSampleSize = sample(opts.outWidth, opts.outHeight, 3200) }
            var bmp = c.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) } ?: return false
            val orientation = try {
                c.contentResolver.openInputStream(uri)?.use {
                    ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
                } ?: ExifInterface.ORIENTATION_NORMAL
            } catch (e: Exception) { ExifInterface.ORIENTATION_NORMAL }
            val deg = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg != 0f) bmp = rotate(bmp, deg)
            bmp = scaleDown(bmp, 3200)
            dest.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            bmp.recycle()
            true
        } catch (e: Throwable) { false }
    }

    fun rotate(b: Bitmap, deg: Float): Bitmap {
        val m = Matrix().apply { postRotate(deg) }
        val r = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
        if (r !== b) b.recycle()
        return r
    }

    /** Loads a saved picture, reduced so its longest side is about [maxSide] pixels. */
    fun loadFile(f: File, maxSide: Int): Bitmap? {
        return try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.absolutePath, opts)
            if (opts.outWidth <= 0) return null
            val o2 = BitmapFactory.Options().apply { inSampleSize = sample(opts.outWidth, opts.outHeight, maxSide) }
            val b = BitmapFactory.decodeFile(f.absolutePath, o2) ?: return null
            scaleDown(b, maxSide)
        } catch (e: Throwable) { null }
    }

    fun rotateFile(f: File): Boolean {
        val b = loadFile(f, 4000) ?: return false
        val r = rotate(b, 90f)
        f.outputStream().use { r.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        r.recycle()
        return true
    }
}
