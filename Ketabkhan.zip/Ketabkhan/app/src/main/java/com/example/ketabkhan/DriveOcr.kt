package com.example.ketabkhan

import android.content.Context
import android.graphics.Bitmap
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.Tasks
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit
import kotlin.math.max

/**
 * Optional online OCR: the page picture is uploaded to the user's own Google Drive and converted to a
 * Google Doc (Google does the OCR while converting), the text is exported, and the temporary file is deleted.
 * Only the drive.file permission is used, so the app can see just the files it creates.
 */
object DriveOcr {
    private const val SCOPE = "https://www.googleapis.com/auth/drive.file"
    private const val API = "https://www.googleapis.com"

    class Unauthorized : Exception()

    fun request(): AuthorizationRequest =
        AuthorizationRequest.builder().setRequestedScopes(listOf(Scope(SCOPE))).build()

    /** Access token for background work. Null when the user has not signed in yet or Google services are missing. */
    fun tokenBlocking(c: Context): String? = try {
        val r = Tasks.await(Identity.getAuthorizationClient(c).authorize(request()), 20, TimeUnit.SECONDS)
        if (r.hasResolution()) null else r.accessToken
    } catch (e: Exception) { null }

    private fun open(url: String, token: String, method: String): HttpURLConnection {
        val con = URL(url).openConnection() as HttpURLConnection
        con.requestMethod = method
        con.setRequestProperty("Authorization", "Bearer $token")
        con.connectTimeout = 20000
        con.readTimeout = 90000
        return con
    }

    private fun compress(b: Bitmap, q: Int): ByteArray {
        val o = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, q, o)
        return o.toByteArray()
    }

    /** Google's image OCR accepts small files, so keep the JPEG under about 1.8 MB. */
    private fun toJpeg(src: Bitmap): ByteArray {
        var b = src
        val m = max(src.width, src.height)
        val shrink = m > 2200
        if (shrink) {
            val f = 2200f / m
            b = Bitmap.createScaledBitmap(src, (src.width * f).toInt(), (src.height * f).toInt(), true)
        }
        var q = 85
        var out = compress(b, q)
        while (out.size > 1_800_000 && q > 40) { q -= 15; out = compress(b, q) }
        if (shrink) b.recycle()
        return out
    }

    private fun deleteFile(id: String, token: String) {
        try {
            val d = open("$API/drive/v3/files/$id", token, "DELETE")
            d.responseCode
            d.disconnect()
        } catch (e: Exception) { }
    }

    /**
     * Reads one page picture. Returns null if the request failed (no internet, no permission...).
     * Throws [Unauthorized] when the token is no longer valid.
     * [lang] is a language hint such as "fa" or "en", or null to let Google detect it.
     */
    fun ocr(token: String, bmp: Bitmap, lang: String?): String? {
        val jpg = toJpeg(bmp)
        val boundary = "ketabkhan" + System.currentTimeMillis()
        val meta = "{\"name\":\"ketabkhan-temp\",\"mimeType\":\"application/vnd.google-apps.document\"}"
        val url = "$API/upload/drive/v3/files?uploadType=multipart&fields=id" + (if (lang != null) "&ocrLanguage=$lang" else "")
        val con = open(url, token, "POST")
        con.doOutput = true
        con.setRequestProperty("Content-Type", "multipart/related; boundary=$boundary")
        con.outputStream.use { o ->
            o.write("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n--$boundary\r\nContent-Type: image/jpeg\r\n\r\n".toByteArray())
            o.write(jpg)
            o.write("\r\n--$boundary--".toByteArray())
        }
        val code = con.responseCode
        if (code == 401) throw Unauthorized()
        if (code !in 200..299) return null
        val id = JSONObject(con.inputStream.bufferedReader().readText()).optString("id", "")
        if (id.isEmpty()) return null
        try {
            val ex = open("$API/drive/v3/files/$id/export?mimeType=text/plain", token, "GET")
            val c2 = ex.responseCode
            if (c2 == 401) throw Unauthorized()
            if (c2 !in 200..299) return null
            val raw = ex.inputStream.bufferedReader(Charsets.UTF_8).readText().removePrefix("\uFEFF")
            return TextFix.fixPage(raw)
        } finally {
            deleteFile(id, token)
        }
    }

    fun langHint(c: Context): String? = when (Prefs.ocrLang(c)) { "fas" -> "fa"; "eng" -> "en"; else -> null }
}
