package com.example.ketabkhan

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.media.RingtoneManager
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max

/** Turns the source of a book (photos, PDF, Office file, text) into page texts in the background. */
object Processor {
    private val main = Handler(Looper.getMainLooper())
    private val threads = ConcurrentHashMap<String, Thread>()
    private val cancelled = ConcurrentHashMap<String, Boolean>()

    /** Called on the main thread whenever a page is finished. Set by the visible screen. */
    @Volatile var listener: (() -> Unit)? = null

    fun isRunning(id: String): Boolean = threads.containsKey(id)
    fun cancel(id: String) { cancelled[id] = true }
    private fun changed() { main.post { listener?.invoke() } }

    fun start(ctx: Context, id: String) {
        if (threads.containsKey(id)) return
        val app = ctx.applicationContext
        cancelled.remove(id)
        WorkService.acquire(app)
        val t = Thread {
            var complete = false
            try {
                complete = run(app, id)
            } catch (e: Throwable) {
            } finally {
                threads.remove(id)
                WorkService.release(app)
                changed()
                if (complete && Prefs.doneSound(app)) {
                    try { RingtoneManager.getRingtone(app, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))?.play() } catch (e: Exception) { }
                }
            }
        }
        threads[id] = t
        t.start()
    }

    private fun run(app: Context, id: String): Boolean {
        val m = BookStore.load(app, id) ?: return false
        val dir = BookStore.dir(app, id)
        when (m.kind) {
            "docx", "pptx", "xlsx", "txt", "text" -> {
                val pages = FileExtractor.pages(File(dir, "source"), m.kind)
                pages.forEachIndexed { i, t -> BookStore.setPage(app, id, i, t) }
                BookStore.update(app, id) { it.total = pages.size; it.done = pages.size }
                changed()
                return true
            }
            "images" -> {
                val files = (File(dir, "images").listFiles() ?: emptyArray()).sortedBy { it.name }
                if (m.total != files.size) BookStore.update(app, id) { it.total = files.size }
                return ocrLoop(app, id, m.done, files.size) { i -> ImageUtil.loadFile(files[i], 3200) }
            }
            "pdf" -> {
                val pfd = ParcelFileDescriptor.open(File(dir, "source"), ParcelFileDescriptor.MODE_READ_ONLY)
                val r = PdfRenderer(pfd)
                try {
                    return ocrLoop(app, id, m.done, m.total) { i ->
                        val pg = r.openPage(m.from + i)
                        try {
                            val s = 2400f / max(pg.width, pg.height)
                            val bmp = Bitmap.createBitmap((pg.width * s).toInt().coerceAtLeast(1), (pg.height * s).toInt().coerceAtLeast(1), Bitmap.Config.ARGB_8888)
                            bmp.eraseColor(Color.WHITE)
                            pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            bmp
                        } finally {
                            pg.close()
                        }
                    }
                } finally {
                    try { r.close() } catch (e: Exception) { }
                    try { pfd.close() } catch (e: Exception) { }
                }
            }
        }
        return false
    }

    private fun ocrLoop(app: Context, id: String, startAt: Int, total: Int, picture: (Int) -> Bitmap?): Boolean {
        val ocr = OcrHelper(app)
        try {
            // optional online OCR through the user's Google Drive; Tesseract stays as the fallback
            var token: String? = null
            if (Prefs.ocrEngine(app) == "drive") {
                token = DriveOcr.tokenBlocking(app)
                if (token == null) main.post { Ui.toast(app, "ورود به گوگل‌درایو انجام نشد. از تشخیص متن آفلاین استفاده می‌شود.") }
            }
            if (token == null && !ocr.hasData()) {
                main.post { Ui.toast(app, "داده‌ی زبان OCR در برنامه نیست.") }
                return false
            }
            val hint = DriveOcr.langHint(app)
            for (i in startAt until total) {
                if (cancelled[id] == true) return false
                var text = ""
                try {
                    val bmp = picture(i)
                    if (bmp != null) {
                        try {
                            var t: String? = null
                            if (token != null) {
                                try {
                                    t = DriveOcr.ocr(token, bmp, hint)
                                } catch (e: DriveOcr.Unauthorized) {
                                    token = DriveOcr.tokenBlocking(app)
                                    if (token != null) {
                                        try { t = DriveOcr.ocr(token, bmp, hint) } catch (e2: Exception) { token = null }
                                    }
                                } catch (e: Exception) { }
                            }
                            if (t.isNullOrBlank() && ocr.hasData()) t = ocr.recognize(bmp)
                            text = t ?: ""
                        } finally { bmp.recycle() }
                    }
                } catch (e: Throwable) { }
                BookStore.setPage(app, id, i, text)
                BookStore.update(app, id) { it.done = i + 1 }
                changed()
            }
            return true
        } finally {
            ocr.release()
        }
    }
}
