package com.example.ketabkhan

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class BookMeta(
    var id: String,
    var name: String,
    var kind: String,
    var total: Int = 0,
    var done: Int = 0,
    var from: Int = 0,
    var created: Long = System.currentTimeMillis(),
    var page: Int = 0,
    var offset: Int = 0,
    var readMs: Long = 0
) {
    fun toJson(): String = JSONObject().apply {
        put("id", id); put("name", name); put("kind", kind); put("total", total); put("done", done)
        put("from", from); put("created", created); put("page", page); put("offset", offset); put("readMs", readMs)
    }.toString()

    companion object {
        fun fromJson(s: String): BookMeta? = try {
            val o = JSONObject(s)
            BookMeta(o.getString("id"), o.optString("name", ""), o.optString("kind", "text"),
                o.optInt("total"), o.optInt("done"), o.optInt("from"), o.optLong("created"),
                o.optInt("page"), o.optInt("offset"), o.optLong("readMs"))
        } catch (e: Exception) { null }
    }
}

class Bookmark(val page: Int, val offset: Int, val snippet: String)

/** All audiobooks live in files/books/<id>/ . */
object BookStore {
    fun root(c: Context) = File(c.filesDir, "books").apply { mkdirs() }
    fun dir(c: Context, id: String) = File(root(c), id).apply { mkdirs() }

    fun newId(): String = java.lang.Long.toString(System.currentTimeMillis(), 36) + (1000..9999).random()

    @Synchronized fun save(c: Context, m: BookMeta) {
        File(dir(c, m.id), "meta.json").writeText(m.toJson())
    }

    @Synchronized fun load(c: Context, id: String): BookMeta? {
        val f = File(File(root(c), id), "meta.json")
        if (!f.exists()) return null
        return BookMeta.fromJson(f.readText())
    }

    /** Loads, changes and saves the book info in one step so two threads do not overwrite each other. */
    @Synchronized fun update(c: Context, id: String, f: (BookMeta) -> Unit): BookMeta? {
        val m = load(c, id) ?: return null
        f(m)
        save(c, m)
        return m
    }

    fun list(c: Context): List<BookMeta> =
        (root(c).listFiles() ?: emptyArray()).mapNotNull { load(c, it.name) }.sortedByDescending { it.created }

    fun create(c: Context, name: String, kind: String, total: Int = 0, from: Int = 0): BookMeta {
        val m = BookMeta(newId(), name, kind, total, 0, from)
        save(c, m)
        return m
    }

    private fun pageFile(c: Context, id: String, i: Int) =
        File(File(dir(c, id), "pages").apply { mkdirs() }, String.format("p%05d.txt", i))

    fun pageText(c: Context, id: String, i: Int): String {
        val f = pageFile(c, id, i)
        return if (f.exists()) f.readText() else ""
    }

    fun setPage(c: Context, id: String, i: Int, t: String) { pageFile(c, id, i).writeText(t) }

    fun delete(c: Context, id: String) { File(root(c), id).deleteRecursively() }

    // ----- notes -----
    fun notes(c: Context, id: String): String {
        val f = File(dir(c, id), "notes.txt")
        return if (f.exists()) f.readText() else ""
    }
    fun setNotes(c: Context, id: String, t: String) { File(dir(c, id), "notes.txt").writeText(t) }

    // ----- bookmarks -----
    fun bookmarks(c: Context, id: String): MutableList<Bookmark> {
        val f = File(dir(c, id), "bookmarks.json")
        val out = ArrayList<Bookmark>()
        if (!f.exists()) return out
        try {
            val a = JSONArray(f.readText())
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Bookmark(o.getInt("p"), o.getInt("o"), o.optString("s", "")))
            }
        } catch (e: Exception) { }
        return out
    }
    fun setBookmarks(c: Context, id: String, l: List<Bookmark>) {
        val a = JSONArray()
        for (b in l) a.put(JSONObject().put("p", b.page).put("o", b.offset).put("s", b.snippet))
        File(dir(c, id), "bookmarks.json").writeText(a.toString())
    }

    // ----- skipped text -----
    fun skipWords(c: Context, id: String): MutableList<String> {
        val f = File(dir(c, id), "skip.txt")
        return if (f.exists()) f.readLines().filter { it.isNotEmpty() }.toMutableList() else ArrayList()
    }
    fun setSkipWords(c: Context, id: String, l: List<String>) {
        File(dir(c, id), "skip.txt").writeText(l.joinToString("\n"))
    }

    // ----- voice notes -----
    fun voiceDir(c: Context, id: String) = File(dir(c, id), "voice").apply { mkdirs() }
    fun voiceNotes(c: Context, id: String): List<File> =
        (voiceDir(c, id).listFiles() ?: emptyArray()).filter { it.name.endsWith(".m4a") }.sortedBy { it.name }
}

/** Picked files: name, type and copying. */
object Importer {
    fun nameOf(c: Context, u: Uri): String {
        try {
            c.contentResolver.query(u, null, null, null, null)?.use { cur ->
                if (cur.moveToFirst()) {
                    val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) { val n = cur.getString(i); if (!n.isNullOrEmpty()) return n }
                }
            }
        } catch (e: Exception) { }
        return u.lastPathSegment ?: "file"
    }

    /** pdf, docx, pptx, xlsx, txt, zip, image or "" when not supported. */
    fun kindOf(c: Context, u: Uri): String {
        val ext = nameOf(c, u).substringAfterLast('.', "").lowercase()
        val mime = (c.contentResolver.getType(u) ?: "").lowercase()
        return when {
            ext == "pdf" || mime == "application/pdf" -> "pdf"
            ext == "docx" -> "docx"
            ext == "pptx" -> "pptx"
            ext == "xlsx" -> "xlsx"
            ext == "txt" || mime == "text/plain" -> "txt"
            ext == "zip" || mime == "application/zip" || mime == "application/x-zip-compressed" -> "zip"
            ext in listOf("jpg", "jpeg", "png", "webp", "bmp", "gif", "heic") || mime.startsWith("image/") -> "image"
            else -> ""
        }
    }

    fun copy(c: Context, u: Uri, dest: File): Boolean = try {
        c.contentResolver.openInputStream(u)?.use { i -> dest.outputStream().use { o -> i.copyTo(o) } } != null
    } catch (e: Exception) { false }
}

/** Photos waiting to be turned into a book. */
object Stage {
    fun dir(c: Context) = File(c.cacheDir, "stage").apply { mkdirs() }
    fun files(c: Context): List<File> = (dir(c).listFiles() ?: emptyArray()).sortedBy { it.name }
    fun next(c: Context): File {
        val n = (files(c).lastOrNull()?.name?.substringBefore('.')?.toIntOrNull() ?: 0) + 1
        return File(dir(c), String.format("%05d.jpg", n))
    }
    fun clear(c: Context) { dir(c).deleteRecursively() }
}
