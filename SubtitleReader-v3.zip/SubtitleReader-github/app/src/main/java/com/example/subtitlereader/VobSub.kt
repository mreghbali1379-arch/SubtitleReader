package com.example.subtitlereader

import android.graphics.Bitmap
import java.io.ByteArrayOutputStream

/** Decoder for DVD subtitles stored as a pair of files: .idx (text index) and .sub (MPEG data). */
object VobSub {

    class Entry(val timeMs: Long, val filePos: Long)
    class Stream(val lang: String) { val entries = ArrayList<Entry>() }
    class Idx(val palette: IntArray, val streams: List<Stream>)
    class Spu(val startMs: Long, val endMs: Long, val bitmap: Bitmap)

    private fun b(d: ByteArray, p: Int) = if (p in d.indices) d[p].toInt() and 0xFF else 0
    private fun u16(d: ByteArray, p: Int) = (b(d, p) shl 8) or b(d, p + 1)

    fun parseIdx(text: String): Idx {
        val palette = IntArray(16) { if (it == 0) 0xFF000000.toInt() else 0xFFFFFFFF.toInt() }
        val streams = ArrayList<Stream>()
        var cur: Stream? = null
        val tsRe = Regex("timestamp:\\s*(-?)(\\d+):(\\d+):(\\d+):(\\d+),\\s*filepos:\\s*([0-9a-fA-F]+)")
        val idRe = Regex("^id:\\s*([A-Za-z-]{2,3})")
        for (raw in text.lines()) {
            val line = raw.trim()
            if (line.startsWith("palette:", true)) {
                line.substringAfter(':').split(',').forEachIndexed { i, c ->
                    if (i < 16) c.trim().toIntOrNull(16)?.let { palette[i] = (0xFF000000L or it.toLong()).toInt() }
                }
                continue
            }
            val idm = idRe.find(line)
            if (idm != null) {
                val s = Stream(idm.groupValues[1].lowercase())
                streams.add(s); cur = s
                continue
            }
            val m = tsRe.find(line) ?: continue
            if (m.groupValues[1] == "-") continue
            var s = cur
            if (s == null) { s = Stream("xx"); streams.add(s); cur = s }
            val g = m.groupValues
            val ms = g[2].toLong() * 3600000 + g[3].toLong() * 60000 + g[4].toLong() * 1000 + g[5].toLong()
            s.entries.add(Entry(ms, g[6].toLong(16)))
        }
        return Idx(palette, streams.filter { it.entries.isNotEmpty() })
    }

    /** Collects the bytes of one subtitle packet starting at [start] in the .sub file. */
    fun readPacket(d: ByteArray, start: Int): ByteArray? {
        var p = start
        val out = ByteArrayOutputStream()
        var need = -1
        while (p + 6 <= d.size && b(d, p) == 0 && b(d, p + 1) == 0 && b(d, p + 2) == 1) {
            val id = b(d, p + 3)
            if (id == 0xBA) { p += 14 + (b(d, p + 13) and 7); continue }
            val len = u16(d, p + 4)
            val end = minOf(d.size, p + 6 + len)
            if (id == 0xBD) {
                val ds = p + 9 + b(d, p + 8)
                if (ds + 1 < end && b(d, ds) in 0x20..0x3F) out.write(d, ds + 1, end - ds - 1)
                if (need < 0 && out.size() >= 2) need = u16(out.toByteArray(), 0)
                if (need >= 1 && out.size() >= need) return out.toByteArray()
            }
            p += 6 + len
        }
        return if (out.size() > 4) out.toByteArray() else null
    }

    /** Decodes one subtitle packet (control commands + run-length image) into a bitmap. */
    fun decode(pkt: ByteArray, tsMs: Long, palette: IntArray): Spu? {
        if (pkt.size < 6) return null
        var pos = u16(pkt, 2)
        var startDelay = 0L
        var stopDelay = -1L
        val pal = intArrayOf(0, 1, 2, 3)
        val alpha = intArrayOf(0, 15, 15, 15)
        var x1 = 0; var x2 = -1; var y1 = 0; var y2 = -1
        var top = 0; var bottom = 0
        var guard = 0
        while (pos + 4 <= pkt.size && guard++ < 64) {
            val delay = u16(pkt, pos) * 1024L / 90
            val next = u16(pkt, pos + 2)
            var p = pos + 4
            loop@ while (p < pkt.size) {
                when (b(pkt, p)) {
                    0x00, 0x01 -> { startDelay = delay; p++ }
                    0x02 -> { stopDelay = delay; p++ }
                    0x03 -> {
                        val a = b(pkt, p + 1); val c = b(pkt, p + 2)
                        pal[3] = a shr 4; pal[2] = a and 15; pal[1] = c shr 4; pal[0] = c and 15
                        p += 3
                    }
                    0x04 -> {
                        val a = b(pkt, p + 1); val c = b(pkt, p + 2)
                        alpha[3] = a shr 4; alpha[2] = a and 15; alpha[1] = c shr 4; alpha[0] = c and 15
                        p += 3
                    }
                    0x05 -> {
                        x1 = (b(pkt, p + 1) shl 4) or (b(pkt, p + 2) shr 4)
                        x2 = ((b(pkt, p + 2) and 15) shl 8) or b(pkt, p + 3)
                        y1 = (b(pkt, p + 4) shl 4) or (b(pkt, p + 5) shr 4)
                        y2 = ((b(pkt, p + 5) and 15) shl 8) or b(pkt, p + 6)
                        p += 7
                    }
                    0x06 -> { top = u16(pkt, p + 1); bottom = u16(pkt, p + 3); p += 5 }
                    else -> break@loop
                }
            }
            if (next <= pos) break
            pos = next
        }
        val w = x2 - x1 + 1
        val h = y2 - y1 + 1
        if (w !in 1..2000 || h !in 1..2000 || top <= 0) return null

        val idx = IntArray(w * h)
        decodeField(pkt, top, w, h, 0, idx)
        decodeField(pkt, if (bottom > 0) bottom else top, w, h, 1, idx)

        val anyAlpha = alpha.any { it > 0 }
        val colors = IntArray(4) { i ->
            val a = if (anyAlpha) alpha[i] * 17 else if (i == 0) 0 else 255
            (a shl 24) or (palette[pal[i] and 15] and 0xFFFFFF)
        }
        val px = IntArray(w * h) { colors[idx[it]] }
        val bmp = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        val start = tsMs + startDelay
        val end = if (stopDelay > startDelay) tsMs + stopDelay else start + 3000
        return Spu(start, end, bmp)
    }

    private fun decodeField(d: ByteArray, off: Int, w: Int, h: Int, startRow: Int, out: IntArray) {
        var bytePos = off
        var high = true
        fun nib(): Int {
            if (bytePos >= d.size) return 0
            val v = d[bytePos].toInt() and 0xFF
            return if (high) { high = false; v shr 4 } else { high = true; bytePos++; v and 15 }
        }
        var y = startRow
        while (y < h && bytePos < d.size) {
            var x = 0
            while (x < w && bytePos < d.size) {
                var v = nib()
                if (v < 4) {
                    v = (v shl 4) or nib()
                    if (v < 0x10) {
                        v = (v shl 4) or nib()
                        if (v < 0x40) {
                            v = (v shl 4) or nib()
                            if (v < 4) v = v or ((w - x) shl 2)
                        }
                    }
                }
                var len = v shr 2
                val col = v and 3
                if (len > w - x) len = w - x
                if (len <= 0) len = w - x
                for (k in 0 until len) out[y * w + x + k] = col
                x += len
            }
            if (!high) { high = true; bytePos++ }
            y += 2
        }
    }

    /** Converts the best stream (Persian if present) of an idx/sub pair to SRT text with OCR. */
    fun convert(idxText: String, sub: ByteArray, ocr: OcrHelper, say: (String) -> Unit, alive: () -> Boolean): String? {
        val idx = parseIdx(idxText)
        val stream = idx.streams.firstOrNull { it.lang == "fa" || it.lang == "per" || it.lang == "pe" }
            ?: idx.streams.firstOrNull() ?: return null
        val cues = ArrayList<SubtitleFormats.Cue>()
        val n = stream.entries.size
        var mark = 5
        for ((i, e) in stream.entries.withIndex()) {
            if (!alive()) return null
            val pkt = readPacket(sub, e.filePos.toInt())
            val spu = if (pkt != null) decode(pkt, e.timeMs, idx.palette) else null
            if (spu != null) {
                val text = ocr.recognizeSync(spu.bitmap)
                spu.bitmap.recycle()
                if (text == null) return null
                if (text.isNotEmpty()) cues.add(SubtitleFormats.Cue(spu.startMs, spu.endMs, text))
            }
            if (mark <= 95 && (i + 1) * 100 / n >= mark) { say("$mark درصد"); mark += 5 }
        }
        return if (cues.isEmpty()) null else SubtitleFormats.toSrt(cues)
    }
}
