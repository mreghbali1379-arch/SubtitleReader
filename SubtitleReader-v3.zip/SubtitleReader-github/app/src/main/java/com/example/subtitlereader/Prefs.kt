package com.example.subtitlereader

import android.content.Context

/** Small settings store shared by the main screen and the settings screen. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** Package name of the chosen speech engine, or null for the phone's default. */
    fun engine(c: Context): String? = sp(c).getString("tts_engine", null)
    fun setEngine(c: Context, e: String?) { sp(c).edit().putString("tts_engine", e).apply() }

    fun rate(c: Context): Float = sp(c).getFloat("speech_rate", 1.0f)
    fun setRate(c: Context, r: Float) { sp(c).edit().putFloat("speech_rate", r).apply() }

    fun volume(c: Context): Float = sp(c).getFloat("speech_volume", 1.0f)
    fun setVolume(c: Context, v: Float) { sp(c).edit().putFloat("speech_volume", v).apply() }

    /** Manual subtitle delay in ms (positive = subtitle later). Reset when a new film or subtitle is picked. */
    fun syncOffset(c: Context): Long = sp(c).getLong("sync_offset", 0L)
    fun setSyncOffset(c: Context, v: Long) { sp(c).edit().putLong("sync_offset", v).apply() }

    fun syncSupported(c: Context): Boolean = sp(c).getBoolean("sync_supported", false)
    fun setSyncSupported(c: Context, v: Boolean) { sp(c).edit().putBoolean("sync_supported", v).apply() }

    /** Volume of the film's own sound (0..1). */
    fun movieVolume(c: Context): Float = sp(c).getFloat("movie_volume", 1.0f)
    fun setMovieVolume(c: Context, v: Float) { sp(c).edit().putFloat("movie_volume", v).apply() }

    /** Seconds jumped by double tap and by the screen-reader scroll gesture. */
    fun skipSeconds(c: Context): Int = sp(c).getInt("skip_seconds", 10)
    fun setSkipSeconds(c: Context, v: Int) { sp(c).edit().putInt("skip_seconds", v).apply() }

    /** Seconds before the player buttons hide on their own. */
    fun hideSeconds(c: Context): Int = sp(c).getInt("hide_seconds", 5)
    fun setHideSeconds(c: Context, v: Int) { sp(c).edit().putInt("hide_seconds", v).apply() }

    /** Recently opened films as (uri, name), newest first. */
    fun recents(c: Context): List<Pair<String, String>> {
        val raw = sp(c).getString("recents", "") ?: ""
        return raw.split("\n").filter { it.isNotBlank() }.mapNotNull { line ->
            val i = line.indexOf('\t')
            if (i <= 0) null else Pair(line.substring(0, i), line.substring(i + 1))
        }
    }

    private fun saveRecents(c: Context, l: List<Pair<String, String>>) {
        sp(c).edit().putString("recents", l.take(20).joinToString("\n") { it.first + "\t" + it.second }).apply()
    }

    fun addRecent(c: Context, uri: String, name: String) {
        val l = recents(c).filter { it.first != uri }.toMutableList()
        l.add(0, Pair(uri, name.replace('\t', ' ').replace('\n', ' ')))
        saveRecents(c, l)
    }

    fun removeRecent(c: Context, uri: String) {
        saveRecents(c, recents(c).filter { it.first != uri })
    }

    /** Read subtitles that are burned into the picture (hard subs). */
    fun hardsub(c: Context): Boolean = sp(c).getBoolean("hardsub", false)
    fun setHardsub(c: Context, v: Boolean) { sp(c).edit().putBoolean("hardsub", v).apply() }

    /** Height of the bottom part of the picture that is read, in percent. */
    fun hardsubBand(c: Context): Int = sp(c).getInt("hardsub_band", 30)
    fun setHardsubBand(c: Context, v: Int) { sp(c).edit().putInt("hardsub_band", v).apply() }

    /** Seconds between the frames read when building a subtitle file from hard-coded subtitles. */
    fun hardsubStep(c: Context): Int = sp(c).getInt("hardsub_step", 2)
    fun setHardsubStep(c: Context, v: Int) { sp(c).edit().putInt("hardsub_step", v).apply() }

    /** OCR language: "all" (every installed language) or one language code such as fas or eng. */
    fun ocrLang(c: Context): String = sp(c).getString("ocr_lang", "all") ?: "all"
    fun setOcrLang(c: Context, v: String) { sp(c).edit().putString("ocr_lang", v).apply() }

    /** Offline engine: "tesseract" or "paddle" (needs its model downloaded once). */
    fun ocrEngine(c: Context): String = sp(c).getString("ocr_engine", "tesseract") ?: "tesseract"
    fun setOcrEngine(c: Context, v: String) { sp(c).edit().putString("ocr_engine", v).apply() }

    /** Online text recognition (Google Cloud Vision) instead of the offline engine, when converting. */
    fun ocrOnline(c: Context): Boolean = sp(c).getBoolean("ocr_online", false)
    fun setOcrOnline(c: Context, v: Boolean) { sp(c).edit().putBoolean("ocr_online", v).apply() }
    fun ocrKey(c: Context): String = sp(c).getString("ocr_key", "") ?: ""
    fun setOcrKey(c: Context, v: String) { sp(c).edit().putString("ocr_key", v.trim()).apply() }

    /** Which online service is tried first: "gemini" (Google AI Studio key) or "vision" (Google Cloud Vision key). */
    fun ocrProvider(c: Context): String = sp(c).getString("ocr_provider", "gemini") ?: "gemini"
    fun setOcrProvider(c: Context, v: String) { sp(c).edit().putString("ocr_provider", v).apply() }
    fun geminiKey(c: Context): String = sp(c).getString("gemini_key", "") ?: ""
    fun setGeminiKey(c: Context, v: String) { sp(c).edit().putString("gemini_key", v.trim()).apply() }
    fun geminiModel(c: Context): String = sp(c).getString("gemini_model", "gemini-2.5-flash") ?: "gemini-2.5-flash"
    fun setGeminiModel(c: Context, v: String) { sp(c).edit().putString("gemini_model", v.trim()).apply() }

    /** OCR model: "best" (more accurate, slower) or "fast". */
    fun ocrModel(c: Context): String = sp(c).getString("ocr_model", "best") ?: "best"
    fun setOcrModel(c: Context, v: String) { sp(c).edit().putString("ocr_model", v).apply() }
}
