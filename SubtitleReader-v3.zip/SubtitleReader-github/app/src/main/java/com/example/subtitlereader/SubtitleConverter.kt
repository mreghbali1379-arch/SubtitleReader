package com.example.subtitlereader

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.*
import androidx.media3.common.text.CueGroup
import androidx.media3.exoplayer.ExoPlayer
import java.io.File
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger

/**
 * Scans an image-based subtitle track (PGS / DVB) with a hidden player at high speed,
 * runs OCR on every subtitle image and builds an SRT text file.
 */
class SubtitleConverter(private val context: Context, private val ocr: OcrHelper) {

    private class Entry(val start: Long, var end: Long, val text: String)

    private val handler = Handler(Looper.getMainLooper())
    private var player: ExoPlayer? = null
    private val pending = AtomicInteger(0)
    // entries/open are touched only on the OCR thread
    private val entries = ArrayList<Entry>()
    private var open: Entry? = null
    @Volatile private var started = false
    @Volatile private var finished = false
    @Volatile private var cuesSeen = 0
    @Volatile private var textsRead = 0
    private var errorText: String? = null

    /** Why the last conversion produced nothing (spoken to the user). */
    @Volatile var reason: String = ""
    private var lastPct = 0
    private val speed = 16f

    /** Lines finished so far; the player reads them while the rest is still being built. */
    val liveCues = CopyOnWriteArrayList<HardsubConverter.LiveCue>()

    /** Everything before this time (ms) is final. */
    @Volatile var doneMs = 0L

    @Volatile private var resumeFrom = 0L
    private var partFile: File? = null
    private var lastSave = 0L

    private fun commit(e: Entry) {
        entries.add(e)
        liveCues.add(HardsubConverter.LiveCue(e.start, e.end, e.text))
    }

    /** Saves the finished lines and the time to continue from. Safe to call from any thread. */
    private fun savePart() {
        val pos = doneMs
        if (pos <= 0L) return
        val d = player?.duration ?: 0L
        HardsubConverter.writePart(partFile, pos, if (d == C.TIME_UNSET || d < 0) 0L else d,
            liveCues.filter { it.end <= pos })
    }

    fun start(
        video: Uri,
        sub: MediaItem.SubtitleConfiguration?,
        textIndex: Int,
        partFile: File?,
        resume: HardsubConverter.Part?,
        onProgress: (Int) -> Unit,
        onDone: (String?) -> Unit,
        onNoData: () -> Unit
    ) {
        this.partFile = partFile
        if (resume != null && resume.pos > 0) {
            for (c in resume.cues) {
                entries.add(Entry(c.start, c.end, c.text))
                liveCues.add(c)
            }
            resumeFrom = resume.pos
            doneMs = resume.pos
        }
        lastSave = System.currentTimeMillis()
        val pl = ExoPlayer.Builder(context).build()
        player = pl
        pl.trackSelectionParameters = pl.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
            .build()

        fun finish(result: String?, noData: Boolean = false) {
            if (finished) return
            finished = true
            if (result == null && !noData) {
                reason = errorText ?: when {
                    cuesSeen == 0 -> "هیچ تصویر زیرنویسی از این مسیر خوانده نشد"
                    textsRead == 0 -> "تصویرها خوانده شدند اما متنی از آنها تشخیص داده نشد. فایل زبان OCR را بررسی کنید"
                    else -> "متنی ساخته نشد"
                }
            }
            handler.removeCallbacksAndMessages(null)
            player?.release(); player = null
            if (noData) onNoData() else onDone(result)
        }

        val progress = object : Runnable {
            override fun run() {
                val p = player ?: return
                val d = p.duration
                if (d > 0 && d != C.TIME_UNSET) {
                    val pct = (p.currentPosition * 100 / d).toInt() / 5 * 5
                    if (pct in 5..95 && pct > lastPct) { lastPct = pct; onProgress(pct) }
                }
                val now = System.currentTimeMillis()
                if (now - lastSave > 20000) { lastSave = now; savePart() }
                handler.postDelayed(this, 2000)
            }
        }

        fun done() {
            if (pending.decrementAndGet() <= 0) {
                handler.post { if (!finished && started) player?.playWhenReady = true }
            }
        }

        pl.addListener(object : Player.Listener {
            override fun onTracksChanged(tracks: Tracks) {
                if (started || finished || tracks.groups.isEmpty()) return
                val g = tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }.getOrNull(textIndex)
                if (g == null) { errorText = "مسیر زیرنویس پیدا نشد"; handler.post { finish(null) }; return }
                started = true
                pl.trackSelectionParameters = pl.trackSelectionParameters.buildUpon()
                    .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0)).build()
                pl.playbackParameters = PlaybackParameters(speed)
                if (resumeFrom > 0) pl.seekTo(resumeFrom)
                pl.playWhenReady = true
                handler.postDelayed(progress, 2000)
            }

            override fun onCues(cueGroup: CueGroup) {
                if (!started || finished) return
                val t = maxOf(resumeFrom, (if (cueGroup.presentationTimeUs == C.TIME_UNSET) pl.currentPosition * 1000
                         else cueGroup.presentationTimeUs) / 1000)
                // whatever was showing ends now
                pending.incrementAndGet()
                ocr.post {
                    open?.let { it.end = t; commit(it) }
                    open = null
                    doneMs = maxOf(doneMs, t)
                    done()
                }

                val bitmaps = cueGroup.cues.mapNotNull { it.bitmap }
                val text = cueGroup.cues.joinToString(" ") { it.text?.toString() ?: "" }.trim()
                if (bitmaps.isEmpty() && text.isEmpty()) return
                if (bitmaps.isNotEmpty()) cuesSeen++

                // new subtitle: pause until its OCR is finished (keeps memory small and order exact)
                pl.playWhenReady = false
                val sb = StringBuilder(text)
                bitmaps.forEach { bmp ->
                    ocr.recognize(bmp,
                        onText = { sb.append(' ').append(it); textsRead++ },
                        onNoData = { handler.post { finish(null, true) } })
                }
                pending.incrementAndGet()
                ocr.post {
                    val s = sb.toString().trim()
                    if (s.isNotEmpty()) open = Entry(t, t, s)
                    done()
                }
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && started && !finished) {
                    val dur = if (pl.duration == C.TIME_UNSET) 0L else pl.duration
                    ocr.post {
                        open?.let { it.end = dur; commit(it) }
                        open = null
                        doneMs = dur
                        val empty = entries.isEmpty()
                        val srt = buildSrt()
                        // the whole track was read: the saved progress is no longer needed
                        partFile?.let { File(it.parentFile, it.name + ".tmp").delete(); it.delete() }
                        handler.post { finish(if (empty) null else srt) }
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                errorText = "خطای پخش: " + error.errorCodeName
                handler.post { finish(null) }
            }
        })

        val item = MediaItem.Builder().setUri(video).apply {
            if (sub != null) setSubtitleConfigurations(listOf(sub))
        }.build()
        pl.setMediaItem(item)
        pl.prepare()
        pl.playWhenReady = false
    }

    fun cancel() {
        if (started && !finished) savePart()
        finished = true
        handler.removeCallbacksAndMessages(null)
        player?.release(); player = null
    }

    private fun buildSrt(): String {
        val sb = StringBuilder()
        var n = 1
        for (e in entries) {
            val end = if (e.end <= e.start) e.start + 2000 else e.end
            sb.append(n++).append('\n')
                .append(ts(e.start)).append(" --> ").append(ts(end)).append('\n')
                .append(e.text).append("\n\n")
        }
        return sb.toString()
    }

    private fun ts(ms: Long): String = String.format(
        Locale.US, "%02d:%02d:%02d,%03d", ms / 3600000, ms / 60000 % 60, ms / 1000 % 60, ms % 1000)
}
