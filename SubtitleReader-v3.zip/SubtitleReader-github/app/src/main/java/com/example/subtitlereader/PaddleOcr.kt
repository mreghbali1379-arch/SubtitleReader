package com.example.subtitlereader

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.graphics.Bitmap
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.FloatBuffer
import kotlin.math.ceil

/**
 * Offline text-line recognition with the PaddleOCR (PP-OCRv3) Arabic-script model, which covers Persian.
 * Only the recognition model is used: the lines are already cut out of the picture by [OcrHelper].
 * The model files are downloaded once (see [download]) and then work without internet.
 */
class PaddleOcr(private val context: Context) {
    private val dir = File(context.filesDir, "paddle")
    private var env: OrtEnvironment? = null
    private var session: OrtSession? = null
    private var inName = ""
    private var inH = 48
    private var dict: List<String> = emptyList()
    private var loaded = false

    private var triedAssets = false

    private fun filesExist() = File(dir, "rec.onnx").exists() && File(dir, "dict.txt").exists()

    /** The model can be bundled in the app (the GitHub build does this); it is copied out once. */
    private fun copyFromAssets() {
        if (triedAssets) return
        triedAssets = true
        try {
            val names = context.assets.list("paddle") ?: return
            if ("rec.onnx" !in names || "dict.txt" !in names) return
            dir.mkdirs()
            for (n in listOf("dict.txt", "rec.onnx")) {
                val tmp = File(dir, "$n.tmp")
                context.assets.open("paddle/$n").use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                val dst = File(dir, n)
                dst.delete()
                tmp.renameTo(dst)
            }
        } catch (ignored: Exception) {
        }
    }

    fun ready(): Boolean {
        if (filesExist()) return true
        copyFromAssets()
        return filesExist()
    }

    private fun load(): Boolean {
        if (loaded) return session != null
        loaded = true
        return try {
            val e = OrtEnvironment.getEnvironment()
            val opts = OrtSession.SessionOptions().apply { setIntraOpNumThreads(2) }
            val s = e.createSession(File(dir, "rec.onnx").absolutePath, opts)
            inName = s.inputNames.iterator().next()
            val shape = (s.inputInfo[inName]!!.info as TensorInfo).shape
            inH = if (shape.size >= 3 && shape[2] > 0) shape[2].toInt() else 48
            dict = File(dir, "dict.txt").readLines(Charsets.UTF_8).map { it.trimEnd('\r', '\n') }
            env = e
            session = s
            true
        } catch (ex: Throwable) {
            false
        }
    }

    /** Frees the model so new files are picked up next time. */
    @Synchronized fun close() {
        try { session?.close() } catch (ignored: Throwable) {}
        session = null
        env = null
        loaded = false
    }

    /** Reads one text line (dark text on a light background). Returns (text, confidence 0..100) or null on failure. */
    @Synchronized fun read(src: Bitmap): Pair<String, Int>? {
        if (!ready() || !load()) return null
        val e = env ?: return null
        val s = session ?: return null
        try {
            val h = inH
            val w = ceil(h.toDouble() * src.width / src.height).toInt().coerceIn(16, 2400)
            val scaled = Bitmap.createScaledBitmap(src, w, h, true)
            val px = IntArray(w * h)
            scaled.getPixels(px, 0, w, 0, 0, w, h)
            if (scaled !== src) scaled.recycle()
            val data = FloatArray(3 * h * w)
            val plane = h * w
            for (i in px.indices) {
                val c = px[i]
                // PaddleOCR feeds BGR, normalised to -1..1
                data[i] = ((c and 255) / 255f - 0.5f) / 0.5f
                data[plane + i] = (((c shr 8) and 255) / 255f - 0.5f) / 0.5f
                data[2 * plane + i] = (((c shr 16) and 255) / 255f - 0.5f) / 0.5f
            }
            val tensor = OnnxTensor.createTensor(e, FloatBuffer.wrap(data), longArrayOf(1, 3, h.toLong(), w.toLong()))
            try {
                val res = s.run(mapOf(inName to tensor))
                try {
                    @Suppress("UNCHECKED_CAST")
                    val out = res[0].value as Array<Array<FloatArray>>
                    return decode(out[0])
                } finally {
                    res.close()
                }
            } finally {
                tensor.close()
            }
        } catch (ex: Throwable) {
            return null
        }
    }

    /** Greedy CTC decoding, then the right-to-left reordering PaddleOCR applies to Arabic-script models. */
    private fun decode(steps: Array<FloatArray>): Pair<String, Int> {
        if (steps.isEmpty()) return Pair("", 0)
        val classes = steps[0].size
        val chars = ArrayList<String>(classes)
        chars.add("")                       // index 0 is the CTC blank
        chars.addAll(dict)
        if (classes == dict.size + 2) chars.add(" ")
        val sb = ArrayList<String>()
        var last = -1
        var probSum = 0.0
        var n = 0
        for (row in steps) {
            var best = 0
            var bp = row[0]
            for (k in 1 until row.size) if (row[k] > bp) { bp = row[k]; best = k }
            if (best != 0 && best != last && best < chars.size) {
                sb.add(chars[best])
                probSum += bp
                n++
            }
            last = best
        }
        if (n == 0) return Pair("", 0)
        // the model writes the line left to right; tokens of Latin letters and digits stay together, the rest is reversed
        val tokens = ArrayList<String>()
        val cur = StringBuilder()
        val plain = Regex("[a-zA-Z0-9 :*./%+-]")
        for (c in sb) {
            if (!plain.containsMatchIn(c)) {
                if (cur.isNotEmpty()) { tokens.add(cur.toString()); cur.setLength(0) }
                tokens.add(c)
            } else {
                cur.append(c)
            }
        }
        if (cur.isNotEmpty()) tokens.add(cur.toString())
        tokens.reverse()
        val text = TextFix.fix(tokens.joinToString(""))
        return Pair(text, (probSum / n * 100).toInt().coerceIn(1, 100))
    }

    companion object {
        private const val BASE = "https://huggingface.co/monkt/paddleocr-onnx/resolve/main/languages/arabic/"

        /** Downloads the model once (about 9 MB). Returns null on success or a short reason. Blocking. */
        fun download(c: Context): String? {
            val dir = File(c.filesDir, "paddle").apply { mkdirs() }
            for (name in listOf("dict.txt", "rec.onnx")) {
                val tmp = File(dir, "$name.tmp")
                try {
                    val con = URL(BASE + name).openConnection() as HttpURLConnection
                    con.connectTimeout = 15000
                    con.readTimeout = 60000
                    con.instanceFollowRedirects = true
                    if (con.responseCode !in 200..299) return "کد خطا ${con.responseCode}"
                    con.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    if (tmp.length() < 1000) { tmp.delete(); return "فایل دانلودشده ناقص است" }
                    val dst = File(dir, name)
                    dst.delete()
                    if (!tmp.renameTo(dst)) return "ذخیره فایل ناموفق بود"
                } catch (e: Exception) {
                    tmp.delete()
                    return "ارتباط با اینترنت برقرار نشد"
                }
            }
            return null
        }
    }
}
