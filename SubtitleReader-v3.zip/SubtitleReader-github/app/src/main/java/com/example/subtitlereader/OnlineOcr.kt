package com.example.subtitlereader

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Online text recognition. Two services can be used: Google Cloud Vision (accurate, letter by letter) and
 * Gemini through a Google AI Studio key (cheap or free, understands context). The chosen one is tried first,
 * the other one second; every failure returns null so the caller can fall back to the offline engine.
 */
object OnlineOcr {
    private const val VISION = 0
    private const val GEMINI = 1

    @Volatile var ok = 0
    @Volatile var failed = 0
    @Volatile var lastError = ""
    private val blocked = booleanArrayOf(false, false)   // wrong key / no access: stop trying until the next run
    private val bad = intArrayOf(0, 0)

    private const val GEMINI_PROMPT =
        "This image is a cropped video frame that may contain subtitle text. " +
        "Transcribe the subtitle text exactly as it is written (usually Persian or English). " +
        "Do not translate, correct, explain or add anything. Keep line breaks. " +
        "Ignore logos, watermarks, clocks and channel names. " +
        "If there is no subtitle text, answer exactly: NONE"

    fun enabled(c: Context) = Prefs.ocrOnline(c) && (Prefs.ocrKey(c).isNotBlank() || Prefs.geminiKey(c).isNotBlank())

    fun resetStats() {
        ok = 0; failed = 0; lastError = ""
        blocked[0] = false; blocked[1] = false
        bad[0] = 0; bad[1] = 0
    }

    private fun providers(c: Context): List<Int> {
        val first = if (Prefs.ocrProvider(c) == "vision") VISION else GEMINI
        val list = ArrayList<Int>()
        for (p in intArrayOf(first, 1 - first)) {
            val has = if (p == VISION) Prefs.ocrKey(c).isNotBlank() else Prefs.geminiKey(c).isNotBlank()
            if (has && !blocked[p]) list.add(p)
        }
        return list
    }

    private fun encode(b: Bitmap, png: Boolean): String {
        val bo = ByteArrayOutputStream()
        if (png) b.compress(Bitmap.CompressFormat.PNG, 100, bo)
        else b.compress(Bitmap.CompressFormat.JPEG, 92, bo)
        return Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
    }

    private fun short(m: String) = if (m.length > 140) m.substring(0, 140) else m

    private fun errorMessage(body: String): String = try {
        JSONObject(body).getJSONObject("error").optString("message", "")
    } catch (e: Exception) {
        ""
    }

    /**
     * Returns (text, confidence 0..100), or ("", 0) when the picture has no text, or null if every service failed.
     * Blocking: call from a background thread. The bitmap is not recycled.
     */
    fun read(c: Context, src: Bitmap, png: Boolean): Pair<String, Int>? {
        val order = providers(c)
        if (order.isEmpty()) { failed++; return null }
        val img = encode(src, png)
        for (p in order) {
            val r = if (p == VISION) readVision(c, img) else readGemini(c, img, png)
            if (r != null) { ok++; return r }
        }
        failed++
        return null
    }

    private fun hints(c: Context): JSONArray {
        val a = JSONArray()
        when (val p = Prefs.ocrLang(c)) {
            "all" -> { a.put("fa"); a.put("en") }
            "fas" -> a.put("fa")
            "eng" -> a.put("en")
            "ara" -> a.put("ar")
            else -> a.put(p.take(2))
        }
        return a
    }

    private fun readVision(c: Context, img: String): Pair<String, Int>? {
        val req = JSONObject().put("requests", JSONArray().put(JSONObject()
            .put("image", JSONObject().put("content", img))
            .put("features", JSONArray().put(JSONObject().put("type", "DOCUMENT_TEXT_DETECTION")))
            .put("imageContext", JSONObject().put("languageHints", hints(c)))))
        val url = "https://vision.googleapis.com/v1/images:annotate?key=" +
            URLEncoder.encode(Prefs.ocrKey(c).trim(), "UTF-8")
        return call(VISION, url, emptyMap(), req.toString().toByteArray(Charsets.UTF_8)) { text ->
            val r = JSONObject(text).getJSONArray("responses").getJSONObject(0)
            if (r.has("error")) {
                lastError = "Vision: " + short(r.getJSONObject("error").optString("message", "خطای سرویس"))
                null
            } else {
                val full = r.optJSONObject("fullTextAnnotation")
                if (full == null) Pair("", 0) else {
                    val t = TextFix.fix(full.optString("text", ""))
                    val conf = (full.optJSONArray("pages")?.optJSONObject(0)?.optDouble("confidence", 0.9) ?: 0.9) * 100
                    Pair(t, conf.toInt().coerceIn(1, 100))
                }
            }
        }
    }

    private fun readGemini(c: Context, img: String, png: Boolean): Pair<String, Int>? {
        val model = Prefs.geminiModel(c).trim().ifEmpty { "gemini-2.5-flash" }
        val gen = JSONObject().put("temperature", 0).put("maxOutputTokens", 400)
        // thinking only slows this job down and costs more; switching it off is allowed for the 2.5 Flash models
        if (model.startsWith("gemini-2.5-flash")) gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        val parts = JSONArray()
            .put(JSONObject().put("text", GEMINI_PROMPT))
            .put(JSONObject().put("inline_data", JSONObject()
                .put("mime_type", if (png) "image/png" else "image/jpeg")
                .put("data", img)))
        val req = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", parts)))
            .put("generationConfig", gen)
        val url = "https://generativelanguage.googleapis.com/v1beta/models/" +
            URLEncoder.encode(model, "UTF-8") + ":generateContent"
        val headers = mapOf("x-goog-api-key" to Prefs.geminiKey(c).trim())
        return call(GEMINI, url, headers, req.toString().toByteArray(Charsets.UTF_8)) { text ->
            val cand = JSONObject(text).optJSONArray("candidates")?.optJSONObject(0)
            val ps = cand?.optJSONObject("content")?.optJSONArray("parts")
            if (ps == null) {
                lastError = "Gemini: پاسخ خالی (" + (cand?.optString("finishReason", "") ?: "بدون نتیجه") + ")"
                null
            } else {
                val sb = StringBuilder()
                for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text", ""))
                var t = sb.toString().trim()
                if (t.startsWith("```")) t = t.removePrefix("```").substringAfter('\n', "").removeSuffix("```").trim()
                if (t.isEmpty() || t.equals("NONE", true)) Pair("", 0)
                else Pair(TextFix.fix(t), 85)
            }
        }
    }

    private fun call(p: Int, url: String, headers: Map<String, String>, body: ByteArray,
                     parse: (String) -> Pair<String, Int>?): Pair<String, Int>? {
        val name = if (p == VISION) "Vision" else "Gemini"
        for (attempt in 0..1) {
            var con: HttpURLConnection? = null
            try {
                con = URL(url).openConnection() as HttpURLConnection
                con.requestMethod = "POST"
                con.connectTimeout = 8000
                con.readTimeout = 30000
                con.doOutput = true
                con.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                for ((k, v) in headers) con.setRequestProperty(k, v)
                con.outputStream.use { it.write(body) }
                val code = con.responseCode
                val text = (if (code in 200..299) con.inputStream else con.errorStream)
                    ?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
                if (code in 200..299) return parse(text)
                val msg = errorMessage(text)
                val keyProblem = code == 401 || code == 403 ||
                    (code == 400 && (msg.contains("API key", true) || msg.contains("API_KEY", true)))
                if (keyProblem) {
                    blocked[p] = true
                    lastError = "$name: کلید یا دسترسی درست نیست: " + short(msg.ifEmpty { "کد $code" })
                    return null
                }
                if (code == 400) {
                    lastError = "$name: درخواست رد شد: " + short(msg)
                    if (++bad[p] >= 3) blocked[p] = true
                    return null
                }
                lastError = if (code == 429) "$name: سهمیه یا سقف درخواست پر شده است" else "$name: خطای سرور $code"
                if (attempt == 0) Thread.sleep(if (code == 429) 4000L else 1500L)
            } catch (e: InterruptedException) {
                return null
            } catch (e: IOException) {
                lastError = "$name: ارتباط با اینترنت برقرار نشد"
                if (attempt == 0) try { Thread.sleep(1000) } catch (ie: InterruptedException) { return null }
            } catch (e: Exception) {
                lastError = "$name: پاسخ نامعتبر"
                return null
            } finally {
                try { con?.disconnect() } catch (ignored: Exception) {}
            }
        }
        return null
    }
}
