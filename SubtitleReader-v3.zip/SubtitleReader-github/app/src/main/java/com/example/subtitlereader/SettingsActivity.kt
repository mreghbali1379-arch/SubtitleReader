package com.example.subtitlereader

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import kotlin.math.abs

/** Settings in the style of MX Player: grouped rows with a title and a summary. */
class SettingsActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var ocr: OcrHelper
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var persian: Boolean? = null   // null = unknown (the engine may still read Persian)

    private val summaries = ArrayList<Pair<TextView, () -> String>>()
    private lateinit var box: LinearLayout

    private val pickOcrData = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val ok = ocr.importData(uri)
            tell(if (ok) "فایل زبان اضافه شد" else "فایل باید با پسوند traineddata باشد")
            refreshAll()
        }
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun tell(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private val percents = (0..10).map { it * 10 }
    private val speechPercents = (1..10).map { it * 10 }
    private val rates = listOf(0.6f, 0.8f, 1.0f, 1.2f, 1.4f, 1.6f, 1.8f, 2.0f, 2.5f, 3.0f)
    private val skips = listOf(5, 10, 15, 30, 60)
    private val hides = listOf(3, 5, 10, 15)
    private val bands = listOf(20, 30, 40, 50, 100)
    private val steps = listOf(1, 2, 3, 5)

    private fun nearest(list: List<Int>, v: Int): Int {
        var best = 0
        for (i in list.indices) if (abs(list[i] - v) < abs(list[best] - v)) best = i
        return best
    }

    private fun nearestRate(v: Float): Int {
        var best = 0
        for (i in rates.indices) if (abs(rates[i] - v) < abs(rates[best] - v)) best = i
        return best
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ocr = OcrHelper(this)
        tts = TextToSpeech(this, this, Prefs.engine(this))

        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        buildRows()

        val title = TextView(this).apply {
            text = "تنظیمات"
            setTextColor(Color.WHITE)
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }
        ViewCompat.setAccessibilityHeading(title, true)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.BAR)
            val p = dp(8)
            setPadding(p, p, p, p)
            addView(Ui.icon(this@SettingsActivity, R.drawable.ic_back, "بازگشت") { finish() })
            addView(title, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Ui.BG)
            addView(bar, LinearLayout.LayoutParams(-1, -2))
            addView(ScrollView(this@SettingsActivity).apply { addView(box) }, LinearLayout.LayoutParams(-1, 0, 1f))
        })
        refreshAll()
    }

    // ---------- row building ----------

    private fun header(t: String) {
        val v = TextView(this).apply {
            text = t
            setTextColor(Ui.ACCENT)
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(16), dp(24), dp(16), dp(4))
        }
        ViewCompat.setAccessibilityHeading(v, true)
        box.addView(v, LinearLayout.LayoutParams(-1, -2))
    }

    private fun row(title: String, summary: () -> String, action: () -> Unit) {
        val tvT = TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 17f
        }
        val tvS = TextView(this).apply {
            setTextColor(Ui.TEXT2)
            textSize = 14f
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            isFocusable = true
            Ui.ripple(this@SettingsActivity, this, false)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            addView(tvT)
            addView(tvS)
            setOnClickListener { action() }
        }
        summaries.add(Pair(tvS, summary))
        box.addView(col, LinearLayout.LayoutParams(-1, -2))
    }

    private fun refreshAll() {
        for (p in summaries) {
            val t = p.second()
            p.first.text = t
            p.first.visibility = if (t.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    private fun choose(title: String, labels: List<String>, current: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(labels.toTypedArray(), current) { d, which ->
                d.dismiss()
                onPick(which)
                refreshAll()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun buildRows() {
        header("پخش‌کننده")
        row("صدای فیلم", { Math.round(Prefs.movieVolume(this) * 100).toString() + " درصد" }) {
            choose("صدای فیلم", percents.map { "$it درصد" },
                nearest(percents, Math.round(Prefs.movieVolume(this) * 100))) { i ->
                Prefs.setMovieVolume(this, percents[i] / 100f)
            }
        }
        row("مدت پرش", { Prefs.skipSeconds(this).toString() + " ثانیه" }) {
            choose("مدت پرش", skips.map { "$it ثانیه" }, nearest(skips, Prefs.skipSeconds(this))) { i ->
                Prefs.setSkipSeconds(this, skips[i])
            }
        }
        row("مدت نمایش دکمه‌ها", { Prefs.hideSeconds(this).toString() + " ثانیه" }) {
            choose("مدت نمایش دکمه‌ها", hides.map { "$it ثانیه" }, nearest(hides, Prefs.hideSeconds(this))) { i ->
                Prefs.setHideSeconds(this, hides[i])
            }
        }

        header("گفتار (خواندن زیرنویس)")
        row("موتور گفتار", { engineSummary() }) { chooseEngine() }
        row("سرعت خواندن", { "%.1f".format(Prefs.rate(this)) }) {
            choose("سرعت خواندن", rates.map { "%.1f".format(it) }, nearestRate(Prefs.rate(this))) { i ->
                Prefs.setRate(this, rates[i])
                tts?.setSpeechRate(rates[i])
                speakTest("این سرعت خواندن است")
            }
        }
        row("صدای خواندن", { Math.round(Prefs.volume(this) * 100).toString() + " درصد" }) {
            choose("صدای خواندن", speechPercents.map { "$it درصد" },
                nearest(speechPercents, Math.round(Prefs.volume(this) * 100))) { i ->
                Prefs.setVolume(this, speechPercents[i] / 100f)
                speakTest("این صدای خواندن است")
            }
        }
        row("آزمایش صدا", { "" }) {
            speakTest("سلام. این یک آزمایش صدای فارسی است.")
        }
        row("نصب یا به‌روزرسانی صدای موتور", { "" }) { installVoice() }
        row("تنظیمات گفتار گوشی", { "" }) { openSystemTts() }

        header("زیرنویس")
        row("تأخیر زیرنویس", { "%+.1f".format(Prefs.syncOffset(this) / 1000.0) + " ثانیه" }) {
            Ui.syncMenu(this) { refreshAll() }
        }
        row("ناحیه‌ی خواندن زیرنویس چسبیده به تصویر", { Prefs.hardsubBand(this).toString() + " درصد پایین تصویر" }) {
            choose("ناحیه‌ی خواندن", bands.map { "$it درصد پایین تصویر" }, nearest(bands, Prefs.hardsubBand(this))) { i ->
                Prefs.setHardsubBand(this, bands[i])
            }
        }
        row("فاصله‌ی نمونه‌برداری", { Prefs.hardsubStep(this).toString() + " ثانیه" }) {
            choose("فاصله‌ی نمونه‌برداری", steps.map { "$it ثانیه" }, nearest(steps, Prefs.hardsubStep(this))) { i ->
                Prefs.setHardsubStep(this, steps[i])
            }
        }
        row("زبان تشخیص متن", { ocrLangSummary() }) { chooseOcrLang() }
        row("مدل تشخیص متن", { if (Prefs.ocrModel(this) == "best") "دقیق (کندتر)" else "سریع" }) {
            val values = listOf("best", "fast")
            choose("مدل تشخیص متن", listOf("دقیق (کندتر)", "سریع"),
                values.indexOf(Prefs.ocrModel(this)).coerceAtLeast(0)) { i ->
                Prefs.setOcrModel(this, values[i])
            }
        }
        row("افزودن فایل زبان OCR", { ocrSummary() }) { pickOcrData.launch(arrayOf("*/*")) }
        row("موتور تشخیص آفلاین", { if (Prefs.ocrEngine(this) == "paddle") "PaddleOCR" else "Tesseract" }) {
            val values = listOf("tesseract", "paddle")
            choose("موتور تشخیص آفلاین", listOf("Tesseract", "PaddleOCR (فارسی)"),
                values.indexOf(Prefs.ocrEngine(this)).coerceAtLeast(0)) { i ->
                Prefs.setOcrEngine(this, values[i])
                ocr.reset()
                if (i == 1 && !ocr.paddleReady()) tell("ابتدا مدل PaddleOCR را دانلود کنید")
            }
        }
        row("مدل PaddleOCR فارسی", {
            if (ocr.paddleReady()) "دانلود شده، آفلاین کار می‌کند"
            else "دانلود نشده (حدود ۹ مگابایت، فقط یک بار اینترنت لازم است)"
        }) { downloadPaddle() }
        row("تشخیص آنلاین متن", { onlineSummary() }) { chooseOnline() }
        row("سرویس آنلاین اصلی", { if (Prefs.ocrProvider(this) == "vision") "Google Cloud Vision" else "Gemini (Google AI Studio)" }) {
            val values = listOf("gemini", "vision")
            choose("سرویس آنلاین اصلی", listOf("Gemini (Google AI Studio)", "Google Cloud Vision"),
                values.indexOf(Prefs.ocrProvider(this)).coerceAtLeast(0)) { i ->
                Prefs.setOcrProvider(this, values[i])
            }
        }
        row("کلید Gemini (Google AI Studio)", { keySummary(Prefs.geminiKey(this)) }) {
            editText("کلید Gemini", "در aistudio.google.com یک کلید API بسازید و اینجا بچسبانید.",
                "کلید API (AIza...)", Prefs.geminiKey(this)) { Prefs.setGeminiKey(this, it) }
        }
        row("مدل Gemini", { Prefs.geminiModel(this) }) {
            editText("مدل Gemini", "نام مدل، مثلاً gemini-2.5-flash یا gemini-2.5-flash-lite",
                "gemini-2.5-flash", Prefs.geminiModel(this)) { Prefs.setGeminiModel(this, it.ifBlank { "gemini-2.5-flash" }) }
        }
        row("کلید Google Cloud Vision", { keySummary(Prefs.ocrKey(this)) }) {
            editText("کلید Google Cloud Vision", "در Google Cloud یک کلید برای Cloud Vision API بسازید و اینجا بچسبانید.",
                "کلید API (AIza...)", Prefs.ocrKey(this)) { Prefs.setOcrKey(this, it) }
        }
    }

    private fun downloadPaddle() {
        if (ocr.paddleReady()) { tell("مدل آماده است"); return }
        tell("در حال دانلود مدل. لطفاً صبر کنید")
        val app = applicationContext
        Thread {
            val err = PaddleOcr.download(app)
            runOnUiThread {
                if (isFinishing) return@runOnUiThread
                if (err == null) { ocr.reset(); tell("مدل دانلود شد") } else tell("دانلود ناموفق بود: $err")
                refreshAll()
            }
        }.start()
    }

    private fun onlineSummary(): String {
        val state = when {
            !Prefs.ocrOnline(this) -> "خاموش (فقط آفلاین)"
            Prefs.ocrKey(this).isBlank() && Prefs.geminiKey(this).isBlank() -> "روشن، ولی هیچ کلیدی وارد نشده"
            else -> "روشن (دقت بالاتر، نیاز به اینترنت)"
        }
        return state + "\nتصویر زیرنویس برای گوگل فرستاده می‌شود. اگر سرویس اصلی خطا بدهد سرویس دیگر و بعد روش آفلاین امتحان می‌شود."
    }

    private fun keySummary(k: String): String =
        if (k.isBlank()) "وارد نشده" else "••••" + k.takeLast(4)

    private fun chooseOnline() {
        choose("تشخیص آنلاین متن", listOf("خاموش (آفلاین)", "روشن (آنلاین)"),
            if (Prefs.ocrOnline(this)) 1 else 0) { i ->
            Prefs.setOcrOnline(this, i == 1)
            if (i == 1 && Prefs.ocrKey(this).isBlank() && Prefs.geminiKey(this).isBlank()) {
                editText("کلید Gemini", "در aistudio.google.com یک کلید API بسازید و اینجا بچسبانید.",
                    "کلید API (AIza...)", "") { Prefs.setGeminiKey(this, it) }
            }
        }
    }

    private fun editText(title: String, message: String, hint: String, current: String, onSave: (String) -> Unit) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            setSingleLine(true)
            this.hint = hint
            setText(current)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setView(input)
            .setPositiveButton("ذخیره") { _, _ ->
                onSave(input.text.toString().trim())
                refreshAll()
            }
            .setNeutralButton("پاک کردن") { _, _ ->
                onSave("")
                refreshAll()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    // ---------- speech engine ----------

    private fun engineLabel(pkg: String?): String {
        if (pkg == null) return "پیش‌فرض گوشی"
        val e = tts?.engines?.firstOrNull { it.name == pkg }
        return e?.label?.toString() ?: pkg
    }

    private fun engineSummary(): String {
        val lang = when (persian) {
            true -> "دارد"
            false -> "موتور اجرا نشد"
            null -> if (ttsReady) "نامشخص" else "در حال بررسی"
        }
        return engineLabel(Prefs.engine(this)) + "\nصدای فارسی: " + lang
    }

    private fun chooseEngine() {
        val list = tts?.engines ?: emptyList()
        if (list.isEmpty()) {
            tell("موتور گفتاری پیدا نشد")
            return
        }
        val names = ArrayList<String?>()
        val labels = ArrayList<String>()
        names.add(null); labels.add("پیش‌فرض گوشی")
        for (e in list) { names.add(e.name); labels.add(e.label.toString()) }
        val current = names.indexOf(Prefs.engine(this)).coerceAtLeast(0)
        choose("موتور گفتار", labels, current) { i ->
            Prefs.setEngine(this, names[i])
            restartTts()
        }
    }

    private fun restartTts() {
        ttsReady = false
        persian = null
        tts?.shutdown()
        tts = TextToSpeech(this, this, Prefs.engine(this))
        refreshAll()
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            if (Prefs.engine(this) != null) {
                Prefs.setEngine(this, null)
                tell("این موتور گفتار اجرا نشد. موتور پیش‌فرض گوشی استفاده می‌شود")
                restartTts()
                return
            }
            ttsReady = false
            persian = false
            refreshAll()
            tell("موتور گفتار اجرا نشد")
            return
        }
        // Some engines (eSpeak for example) do not report Persian but still read it with the voice
        // set in their own settings, so "not reported" is not treated as an error.
        persian = if (TtsUtil.usePersian(t)) true else null
        t.setSpeechRate(Prefs.rate(this))
        ttsReady = true
        refreshAll()
    }

    private fun speakTest(msg: String) {
        val t = tts
        if (t == null || !ttsReady) {
            tell("موتور گفتار آماده نیست")
            return
        }
        t.setSpeechRate(Prefs.rate(this))
        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Prefs.volume(this@SettingsActivity))
        }
        t.speak(msg, TextToSpeech.QUEUE_FLUSH, params, "test")
    }

    private fun launch(i: Intent): Boolean = try { startActivity(i); true } catch (e: Exception) { false }

    private fun installVoice() {
        if (!launch(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)))
            tell("نصب صدا ممکن نیست")
    }

    private fun openSystemTts() {
        if (!launch(Intent("com.android.settings.TTS_SETTINGS")) && !launch(Intent(Settings.ACTION_SETTINGS)))
            tell("باز کردن تنظیمات گوشی ممکن نشد")
    }

    // ---------- OCR ----------

    private fun langName(code: String) = when (code) {
        "fas" -> "فارسی"
        "eng" -> "انگلیسی"
        "ara" -> "عربی"
        else -> code
    }

    private fun ocrSummary(): String {
        val l = ocr.installed()
        return if (l.isEmpty()) "هیچ فایل زبانی نصب نیست"
        else "نصب‌شده: " + l.joinToString("، ") { langName(it) }
    }

    private fun ocrLangSummary(): String {
        val p = Prefs.ocrLang(this)
        return if (p == "all") "همه‌ی نصب‌شده‌ها" else langName(p)
    }

    private fun chooseOcrLang() {
        val installed = ocr.installed()
        val values = ArrayList<String>()
        val labels = ArrayList<String>()
        values.add("all"); labels.add("همه‌ی نصب‌شده‌ها")
        for (l in installed) { values.add(l); labels.add(langName(l)) }
        choose("زبان تشخیص متن", labels, values.indexOf(Prefs.ocrLang(this)).coerceAtLeast(0)) { i ->
            Prefs.setOcrLang(this, values[i])
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        ocr.release()
        super.onDestroy()
    }
}
