package com.example.subtitlereader

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.media3.common.MimeTypes
import java.io.File

/** Turns whatever subtitle file(s) the user picked into something the player can use. */
object SubtitleImport {

    sealed class Result {
        class Srt(val file: File, val key: String) : Result()          // normalized UTF-8 srt
        class Native(val uri: Uri, val mime: String) : Result()        // player handles it itself (PGS .sup, TTML)
        class NeedOther(val message: String) : Result()                // idx without sub or the reverse
        class Fail(val message: String) : Result()
    }

    private fun name(ctx: Context, u: Uri): String {
        val n = try {
            ctx.contentResolver.query(u, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
            }
        } catch (ignored: Exception) { null }
        return n ?: u.lastPathSegment ?: ""
    }

    private fun readAll(ctx: Context, u: Uri): ByteArray =
        ctx.contentResolver.openInputStream(u)!!.use { it.readBytes() }

    private fun head(ctx: Context, u: Uri): ByteArray =
        ctx.contentResolver.openInputStream(u)!!.use { s ->
            val buf = ByteArray(4096)
            val n = s.read(buf)
            if (n > 0) buf.copyOf(n) else ByteArray(0)
        }

    fun prepare(ctx: Context, ocr: OcrHelper, uris: List<Uri>, say: (String) -> Unit, alive: () -> Boolean = { true }): Result {
        val dir = File(ctx.filesDir, "subs").apply { mkdirs() }
        var idxU: Uri? = null
        var subU: Uri? = null
        var otherU: Uri? = null
        for (u in uris) {
            val h = head(ctx, u)
            val nm = name(ctx, u).lowercase()
            val isVobData = h.size >= 4 && h[0] == 0.toByte() && h[1] == 0.toByte() &&
                h[2] == 1.toByte() && h[3] == 0xBA.toByte()
            if (isVobData) subU = u
            else if (nm.endsWith(".idx") || String(h, Charsets.ISO_8859_1).contains("VobSub", true)) idxU = u
            else otherU = u
        }

        val idxF = idxU
        val subF = subU
        if (idxF != null || subF != null) {
            if (idxF == null) return Result.NeedOther("این فایل sub است. فایل idx همراه آن را هم انتخاب کنید")
            if (subF == null) return Result.NeedOther("این فایل idx است. فایل sub همراه آن را هم انتخاب کنید")
            val sub = readAll(ctx, subF)
            val key = Integer.toHexString("${name(ctx, idxF)}|${name(ctx, subF)}|${sub.size}".hashCode())
            val out = File(dir, "vob_$key.srt")
            if (out.exists() && out.length() > 0) return Result.Srt(out, key)
            if (!ocr.hasData()) return Result.Fail("فایل زبان OCR اضافه نشده است")
            say("زیرنویس تصویری idx و sub پیدا شد. در حال تبدیل به متن. چند دقیقه صبر کنید")
            val idxText = SubtitleFormats.decode(readAll(ctx, idxF))
            val srt = VobSub.convert(idxText, sub, ocr, say, alive)
                ?: return Result.Fail("تبدیل زیرنویس ناموفق بود")
            out.writeText(srt)
            say("تبدیل تمام شد")
            return Result.Srt(out, key)
        }

        val u = otherU ?: return Result.Fail("فایلی انتخاب نشد")
        val bytes = readAll(ctx, u)
        if (bytes.size > 2 && bytes[0] == 'P'.code.toByte() && bytes[1] == 'G'.code.toByte())
            return Result.Native(u, MimeTypes.APPLICATION_PGS)
        val text = SubtitleFormats.decode(bytes)
        if (SubtitleFormats.isTtml(text)) return Result.Native(u, MimeTypes.APPLICATION_TTML)
        val cues = SubtitleFormats.parseAny(text) ?: return Result.Fail("فرمت این فایل زیرنویس شناخته نشد")
        val key = Integer.toHexString("${name(ctx, u)}|${bytes.size}|${bytes.contentHashCode()}".hashCode())
        val out = File(dir, "txt_$key.srt")
        out.writeText(SubtitleFormats.toSrt(cues))
        return Result.Srt(out, key)
    }
}
