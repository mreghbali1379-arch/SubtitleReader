package com.example.subtitlereader

import android.speech.tts.TextToSpeech
import java.util.Locale

object TtsUtil {
    // Different engines (eSpeak, Google, Samsung...) report Persian under different codes.
    private val tags = listOf("fa", "fa-IR", "fas", "per", "pes", "fa-AF")

    /**
     * Tries Persian under several codes. Returns true if the engine accepted one.
     * If none is accepted, the engine keeps its own language setting (for example the Persian voice
     * chosen in the engine's own settings), so the caller should still try to speak.
     */
    fun usePersian(t: TextToSpeech): Boolean {
        for (tag in tags) {
            val r = try {
                t.setLanguage(Locale.forLanguageTag(tag))
            } catch (e: Exception) {
                TextToSpeech.LANG_NOT_SUPPORTED
            }
            if (r >= TextToSpeech.LANG_AVAILABLE) return true
        }
        return false
    }
}
