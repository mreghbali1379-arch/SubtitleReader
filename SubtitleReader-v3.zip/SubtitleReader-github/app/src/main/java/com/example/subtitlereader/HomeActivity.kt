package com.example.subtitlereader

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat

/** First screen: only "add file" at the start, plus the list of recently opened films. */
class HomeActivity : AppCompatActivity() {

    private lateinit var listBox: LinearLayout
    private lateinit var emptyBox: LinearLayout
    private lateinit var fab: TextView

    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) play(u)
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "زیرنویس‌خوان"
            setTextColor(Color.WHITE)
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }
        ViewCompat.setAccessibilityHeading(title, true)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.BAR)
            val p = dp(8)
            setPadding(dp(16), p, p, p)
            addView(title, LinearLayout.LayoutParams(0, dp(48), 1f))
            addView(Ui.icon(this@HomeActivity, R.drawable.ic_more, "تنظیمات") {
                startActivity(Intent(this@HomeActivity, SettingsActivity::class.java))
            })
        }

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val emptyIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_video)
            setColorFilter(Ui.TEXT2)
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        val emptyText = TextView(this).apply {
            text = "فیلمی اضافه نشده است"
            setTextColor(Ui.TEXT2)
            textSize = 16f
            gravity = Gravity.CENTER
        }
        emptyBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(emptyIcon, LinearLayout.LayoutParams(dp(96), dp(96)))
            addView(emptyText, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) })
        }

        fab = TextView(this).apply {
            text = "افزودن فایل"
            contentDescription = "افزودن فایل"
            setTextColor(Color.WHITE)
            textSize = 18f
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            val ph = dp(28)
            val pv = dp(16)
            setPadding(ph, pv, ph, pv)
            background = GradientDrawable().apply {
                setColor(Ui.ACCENT)
                cornerRadius = dp(32).toFloat()
            }
            setOnClickListener { pick.launch(arrayOf("*/*")) }
        }

        val content = FrameLayout(this).apply {
            addView(ScrollView(this@HomeActivity).apply { addView(listBox) }, FrameLayout.LayoutParams(-1, -1))
            addView(emptyBox, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER).apply { bottomMargin = dp(60) })
            addView(fab, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(32)
            })
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            addView(bar, LinearLayout.LayoutParams(-1, -2))
            addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        listBox.removeAllViews()
        val items = Prefs.recents(this)
        emptyBox.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        if (items.isEmpty()) return
        val head = TextView(this).apply {
            text = "اخیر"
            setTextColor(Ui.ACCENT)
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(16), dp(16), dp(16), dp(4))
        }
        ViewCompat.setAccessibilityHeading(head, true)
        listBox.addView(head)
        for (item in items) {
            val uri = item.first
            val name = item.second
            val icon = ImageView(this).apply {
                setImageResource(R.drawable.ic_video)
                setColorFilter(Ui.ACCENT)
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            val label = TextView(this).apply {
                text = name
                setTextColor(Color.WHITE)
                textSize = 16f
                maxLines = 2
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true
                isFocusable = true
                Ui.ripple(this@HomeActivity, this, false)
                setPadding(dp(16), dp(12), dp(16), dp(12))
                contentDescription = name
                addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))
                addView(label, LinearLayout.LayoutParams(0, -2, 1f).apply {
                    marginStart = dp(16)
                    marginEnd = dp(8)
                })
                setOnClickListener { play(Uri.parse(uri)) }
                setOnLongClickListener {
                    Prefs.removeRecent(this@HomeActivity, uri)
                    Toast.makeText(this@HomeActivity, "از فهرست حذف شد", Toast.LENGTH_SHORT).show()
                    refresh()
                    true
                }
            }
            listBox.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun play(u: Uri) {
        try {
            contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (ignored: Exception) {
        }
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            action = Intent.ACTION_VIEW
            setDataAndType(u, "video/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        })
    }
}
