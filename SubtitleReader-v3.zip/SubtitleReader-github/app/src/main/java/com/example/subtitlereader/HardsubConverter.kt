package com.example.subtitlereader

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs

/**
 * Builds an SRT file for subtitles that are burned into the picture: reads a frame every few seconds,
 * keeps the bottom part, runs OCR and joins repeated lines into subtitle entries.
 */
class HardsubConverter(private val context: Context, private val ocr: OcrHelper) {

    private class Entry(val start: Long, var end: Long, var text: String, val cands: ArrayList<Pair<String, Int>>) {
        var acc: ByteArray? = null   // how many frames each pixel was text in
        var frames = 0
        var w = 0
        var h = 0
    }
    private class Sig(val cells: IntArray, val total: Int, val pixels: Int)

    @Volatile private var cancelled = false

    /** Why the last run produced nothing (spoken to the user). */
    @Volatile var reason: String = ""

    fun cancel() { cancelled = true }

    /** Runs on a background thread. [onProgress] and [onDone] are called from that thread; onDone is skipped after cancel. */
    fun start(video: Uri, bandPercent: Int, stepMs: Long, onProgress: (Int) -> Unit, onDone: (String?) -> Unit) {
        thread(name = "hardsub-convert") {
            val result = try {
                build(video, bandPercent, stepMs, onProgress)
            } catch (e: Exception) {
                reason = "خطا: " + (e.message ?: e.javaClass.simpleName)
                null
            }
            if (!cancelled) onDone(result)
        }
    }

    private fun build(video: Uri, bandPercent: Int, stepMs: Long, onProgress: (Int) -> Unit): String? {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(context, video)
            val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            var vw = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var vh = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = vw; vw = vh; vh = t }
            if (dur <= 0 || vw <= 0 || vh <= 0) { reason = "اطلاعات تصویر فیلم خوانده نشد"; return null }
            val dw = minOf(vw, 1920)
            val dh = vh * dw / vw

            val entries = ArrayList<Entry>()
            var open: Entry? = null
            var lastSeen = 0L
            var prev: Sig? = null
            var t = 0L
            var lastPct = 0
            var framesOk = 0
            var textsRead = 0

            while (t < dur) {
                if (cancelled) return null
                val frame = grab(r, t, dw, dh)
                if (frame == null) { t += stepMs; continue }
                framesOk++
                val fh = frame.height
                val bandH = if (fh <= 40) fh else (fh * bandPercent / 100).coerceIn(40, fh)
                val band = Bitmap.createBitmap(frame, 0, fh - bandH, frame.width, bandH)
                if (band !== frame) frame.recycle()

                val s = sig(band)
                val ratio = s.total.toDouble() / s.pixels
                var text = ""
                var fresh: List<Pair<String, Int>> = emptyList()
                var curMask: TextMask? = null
                var sameAsPrev = false
                val o0 = open
                if (ratio < 0.002 || ratio > 0.25) {
                    // almost nothing bright, or far too much: no subtitle in this frame
                    band.recycle()
                    prev = null
                } else {
                    val p = prev
                    val isSame = p != null && sameSig(s, p)
                    sameAsPrev = isSame
                    if (isSame && o0 == null) {
                        // same picture as before and it was not a subtitle (a logo, for example)
                        band.recycle()
                    } else if (isSame && o0 != null && o0.cands.size >= 4) {
                        // enough readings of this line already; keep the pixels for the combined reading
                        curMask = ocr.textMask(band)
                        text = o0.text
                    } else {
                        // new line: two readings with different brightness limits;
                        // same line seen again: one more reading, up to four in total
                        val biases = if (isSame && o0 != null) intArrayOf(if (o0.cands.size < 3) -18 else 0)
                                     else intArrayOf(0, 18)
                        val fr = ocr.readFrame(band, biases)
                        if (fr == null) { reason = "فایل زبان OCR پیدا نشد"; return null }
                        curMask = fr.mask
                        fresh = fr.reads.map { Pair(TextSim.clean(it.first), it.second) }.filter { it.first.isNotEmpty() }
                        if (fresh.isNotEmpty()) { textsRead++; text = TextSim.vote(fresh) }
                        prev = s
                    }
                }

                val o = open
                if (text.isNotEmpty()) {
                    if (o != null && TextSim.similar(text, o.text)) {
                        if (fresh.isNotEmpty()) { o.cands.addAll(fresh); o.text = TextSim.vote(o.cands) }
                        val cm = curMask
                        if (sameAsPrev && cm != null) addMask(o, cm)
                        lastSeen = t
                    } else {
                        if (o != null) { o.end = lastSeen + stepMs / 2; entries.add(finalizeEntry(o)) }
                        val ne = Entry(maxOf(0L, t - stepMs / 2), t + stepMs / 2, text, ArrayList(fresh))
                        val cm = curMask
                        if (cm != null) addMask(ne, cm)
                        open = ne
                        lastSeen = t
                    }
                } else if (o != null) {
                    o.end = lastSeen + stepMs / 2
                    entries.add(finalizeEntry(o))
                    open = null
                }

                val q = (t * 100 / dur).toInt() / 5 * 5
                if (q in 5..95 && q > lastPct) { lastPct = q; onProgress(q) }
                t += stepMs
            }
            open?.let { it.end = lastSeen + stepMs / 2; entries.add(finalizeEntry(it)) }

            if (entries.isEmpty()) {
                reason = when {
                    framesOk == 0 -> "هیچ تصویری از فیلم خوانده نشد"
                    textsRead == 0 -> "متنی روی تصویر تشخیص داده نشد"
                    else -> "متنی ساخته نشد"
                }
                return null
            }
            return buildSrt(entries)
        } finally {
            try { r.release() } catch (ignored: Exception) {}
        }
    }

    /** Adds the text pixels of one more frame of the same line. */
    private fun addMask(e: Entry, mk: TextMask) {
        var a = e.acc
        if (a == null || a.size != mk.m.size) {
            a = ByteArray(mk.m.size)
            e.acc = a
            e.frames = 0
            e.w = mk.w
            e.h = mk.h
        }
        for (i in mk.m.indices) if (mk.m[i] && a[i] < 120) a[i] = (a[i] + 1).toByte()
        e.frames++
    }

    /**
     * When a line was seen in several frames, keep only the pixels that are text in most of them
     * (noise and compression artifacts change from frame to frame, the letters do not), read that
     * cleaner picture once more and let it take part in the vote.
     */
    private fun finalizeEntry(e: Entry): Entry {
        val a = e.acc
        if (a != null && e.frames >= 2) {
            val need = e.frames / 2 + 1
            val m = BooleanArray(a.size) { a[it] >= need }
            val r = ocr.recognizeMask(m, e.w, e.h)
            if (r != null) {
                val t = TextSim.clean(r.first)
                if (t.isNotEmpty()) e.cands.add(Pair(t, minOf(100, r.second + 20)))
            }
            e.text = TextSim.vote(e.cands)
        }
        e.acc = null
        return e
    }

    private fun grab(r: MediaMetadataRetriever, tMs: Long, w: Int, h: Int): Bitmap? = try {
        if (Build.VERSION.SDK_INT >= 27) {
            r.getScaledFrameAtTime(tMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST, w, h)
        } else {
            val f = r.getFrameAtTime(tMs * 1000, MediaMetadataRetriever.OPTION_CLOSEST)
            if (f != null && f.width > w) {
                val sc = Bitmap.createScaledBitmap(f, w, h, true)
                if (sc !== f) f.recycle()
                sc
            } else f
        }
    } catch (e: Exception) {
        null
    }

    /** Coarse map of where the bright (text) pixels are, used to skip OCR when the picture did not change. */
    private fun sig(b: Bitmap): Sig {
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        val gx = 48
        val gy = 12
        val cells = IntArray(gx * gy)
        var total = 0
        for (y in 0 until h) {
            val row = (y * gy / h) * gx
            for (x in 0 until w) {
                val c = px[y * w + x]
                val lum = (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000
                if (lum >= 190) { cells[row + x * gx / w]++; total++ }
            }
        }
        return Sig(cells, total, w * h)
    }

    private fun sameSig(a: Sig, b: Sig): Boolean {
        var diff = 0
        for (i in a.cells.indices) diff += abs(a.cells[i] - b.cells[i])
        return diff * 100 <= maxOf(a.total, b.total) * 12
    }

    private fun buildSrt(entries: List<Entry>): String {
        val sb = StringBuilder()
        var n = 1
        for (e in entries) {
            val end = if (e.end <= e.start) e.start + 2000 else e.end
            sb.append(n++).append('\n')
                .append(ts(e.start)).append(" --> ").append(ts(end)).append('\n')
                .append(e.text).append("\n\n")
        }
        return sb.toString()
    }

    private fun ts(ms: Long): String = String.format(
        Locale.US, "%02d:%02d:%02d,%03d", ms / 3600000, ms / 60000 % 60, ms / 1000 % 60, ms % 1000)
}
