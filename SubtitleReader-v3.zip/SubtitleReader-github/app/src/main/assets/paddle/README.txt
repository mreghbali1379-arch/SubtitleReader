PaddleOCR Persian model (offline engine)

Put these two files in this folder to ship them inside the project:
  rec.onnx   https://huggingface.co/monkt/paddleocr-onnx/resolve/main/languages/arabic/rec.onnx
  dict.txt   https://huggingface.co/monkt/paddleocr-onnx/resolve/main/languages/arabic/dict.txt

If they are missing, the GitHub build (.github/workflows/build.yml) downloads them automatically.
