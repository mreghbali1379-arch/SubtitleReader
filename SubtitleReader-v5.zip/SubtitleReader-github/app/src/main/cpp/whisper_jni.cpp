#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <cstring>
#include <string>
#include <vector>
#include "whisper.h"

#define TAG "WhisperJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

static std::atomic<bool> g_abort(false);

static bool abort_cb(void *) { return g_abort.load(); }

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_example_subtitlereader_Whisper_nativeInit(JNIEnv *env, jobject, jstring path) {
    const char *p = env->GetStringUTFChars(path, nullptr);
    struct whisper_context_params cp = whisper_context_default_params();
    cp.use_gpu = false;
    struct whisper_context *ctx = whisper_init_from_file_with_params(p, cp);
    env->ReleaseStringUTFChars(path, p);
    return (jlong) ctx;
}

JNIEXPORT void JNICALL
Java_com_example_subtitlereader_Whisper_nativeFree(JNIEnv *, jobject, jlong ctx) {
    if (ctx != 0) whisper_free((struct whisper_context *) ctx);
}

JNIEXPORT void JNICALL
Java_com_example_subtitlereader_Whisper_nativeAbort(JNIEnv *, jobject, jboolean a) {
    g_abort.store(a == JNI_TRUE);
}

/** Returns the number of segments, or a negative number on failure. [lang] may be "auto". */
JNIEXPORT jint JNICALL
Java_com_example_subtitlereader_Whisper_nativeTranscribe(JNIEnv *env, jobject, jlong ctxPtr,
                                                       jfloatArray samples, jint n,
                                                       jstring lang, jint threads) {
    struct whisper_context *ctx = (struct whisper_context *) ctxPtr;
    if (ctx == nullptr) return -100;
    g_abort.store(false);

    jfloat *data = env->GetFloatArrayElements(samples, nullptr);
    const char *l = env->GetStringUTFChars(lang, nullptr);
    std::string language(l);
    env->ReleaseStringUTFChars(lang, l);

    struct whisper_full_params wp = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    wp.print_realtime = false;
    wp.print_progress = false;
    wp.print_timestamps = false;
    wp.print_special = false;
    wp.translate = false;
    wp.language = language.c_str();
    wp.detect_language = false;
    wp.n_threads = threads;
    wp.offset_ms = 0;
    wp.no_context = true;
    wp.single_segment = false;
    wp.abort_callback = abort_cb;
    wp.abort_callback_user_data = nullptr;

    int rc = whisper_full(ctx, wp, data, n);
    env->ReleaseFloatArrayElements(samples, data, JNI_ABORT);
    if (rc != 0) return -1;
    return whisper_full_n_segments(ctx);
}

JNIEXPORT jlong JNICALL
Java_com_example_subtitlereader_Whisper_nativeSegStart(JNIEnv *, jobject, jlong ctx, jint i) {
    return (jlong) whisper_full_get_segment_t0((struct whisper_context *) ctx, i);
}

JNIEXPORT jlong JNICALL
Java_com_example_subtitlereader_Whisper_nativeSegEnd(JNIEnv *, jobject, jlong ctx, jint i) {
    return (jlong) whisper_full_get_segment_t1((struct whisper_context *) ctx, i);
}

/** Returned as bytes: a segment can end in the middle of a UTF-8 character, which NewStringUTF would crash on. */
JNIEXPORT jbyteArray JNICALL
Java_com_example_subtitlereader_Whisper_nativeSegText(JNIEnv *env, jobject, jlong ctx, jint i) {
    const char *t = whisper_full_get_segment_text((struct whisper_context *) ctx, i);
    if (t == nullptr) t = "";
    jsize len = (jsize) strlen(t);
    jbyteArray arr = env->NewByteArray(len);
    env->SetByteArrayRegion(arr, 0, len, (const jbyte *) t);
    return arr;
}

JNIEXPORT jfloat JNICALL
Java_com_example_subtitlereader_Whisper_nativeSegNoSpeech(JNIEnv *, jobject, jlong ctx, jint i) {
    return whisper_full_get_segment_no_speech_prob((struct whisper_context *) ctx, i);
}

JNIEXPORT jstring JNICALL
Java_com_example_subtitlereader_Whisper_nativeLang(JNIEnv *env, jobject, jlong ctx) {
    int id = whisper_full_lang_id((struct whisper_context *) ctx);
    const char *s = whisper_lang_str(id);
    return env->NewStringUTF(s ? s : "en");
}

} // extern "C"
