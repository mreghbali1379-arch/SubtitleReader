More accurate (slower) OCR language files go here (fas.traineddata, eng.traineddata).
The GitHub build downloads them from tessdata_best automatically.
