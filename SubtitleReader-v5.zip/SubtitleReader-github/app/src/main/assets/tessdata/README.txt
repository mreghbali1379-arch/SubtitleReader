Optional: put fas.traineddata (and eng.traineddata) here before building.
Or skip this and use the "add OCR language file" button inside the app.
