package com.example.subtitlereader

import android.content.Context
import android.util.TypedValue
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

/** Colors and small view helpers shared by the screens (dark, MX Player style). */
object Ui {
    val BG = 0xFF121212.toInt()
    val BAR = 0xFF1F1F1F.toInt()
    val ACCENT = 0xFF2196F3.toInt()
    val TEXT2 = 0xFFB0B0B0.toInt()
    val DIVIDER = 0x22FFFFFF

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    private fun resolve(c: Context, attr: Int): Int {
        val tv = TypedValue()
        c.theme.resolveAttribute(attr, tv, true)
        return tv.resourceId
    }

    /** Ripple background for rows and round icon buttons. */
    fun ripple(c: Context, v: View, borderless: Boolean) {
        v.setBackgroundResource(resolve(c,
            if (borderless) android.R.attr.selectableItemBackgroundBorderless
            else android.R.attr.selectableItemBackground))
    }

    fun icon(c: Context, res: Int, desc: String, sizeDp: Int = 48, onClick: () -> Unit): ImageButton {
        val b = ImageButton(c)
        ripple(c, b, true)
        b.setImageResource(res)
        b.scaleType = ImageView.ScaleType.FIT_CENTER
        val p = dp(c, 10)
        b.setPadding(p, p, p, p)
        b.contentDescription = desc
        b.setOnClickListener { onClick() }
        b.layoutParams = LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp))
        return b
    }

    fun time(ms: Long): String {
        val s = (if (ms < 0) 0L else ms) / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%02d:%02d", m, sec)
    }

    /** Manual subtitle delay menu. It reopens after every choice so the delay can be adjusted repeatedly. */
    fun syncMenu(a: AppCompatActivity, onChanged: () -> Unit) {
        if (!Prefs.syncSupported(a)) {
            Toast.makeText(a, "این هماهنگی برای زیرنویس داخل فیلم ممکن نیست", Toast.LENGTH_LONG).show()
            return
        }
        val off = Prefs.syncOffset(a)
        val items = arrayOf("نیم ثانیه دیرتر", "نیم ثانیه زودتر", "پنج ثانیه دیرتر", "پنج ثانیه زودتر", "بازنشانی")
        AlertDialog.Builder(a)
            .setTitle("تأخیر زیرنویس: " + "%+.1f".format(off / 1000.0) + " ثانیه")
            .setItems(items) { _, which ->
                val cur = Prefs.syncOffset(a)
                val n = when (which) {
                    0 -> cur + 500
                    1 -> cur - 500
                    2 -> cur + 5000
                    3 -> cur - 5000
                    else -> 0L
                }
                Prefs.setSyncOffset(a, n)
                onChanged()
                syncMenu(a, onChanged)
            }
            .setNegativeButton("بستن", null)
            .show()
    }
}
