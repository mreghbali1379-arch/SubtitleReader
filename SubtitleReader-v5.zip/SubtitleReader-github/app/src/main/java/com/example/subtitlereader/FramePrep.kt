package com.example.subtitlereader

/** Finds subtitle (text) pixels in a video frame band. */
object FramePrep {
    fun lum(c: Int): Int =
        (((c shr 16) and 255) * 299 + ((c shr 8) and 255) * 587 + (c and 255) * 114) / 1000

    fun lumas(px: IntArray): IntArray = IntArray(px.size) { lum(px[it]) }

    /** Brightness limit chosen from the frame itself: subtitle text is the brightest part of the band. */
    fun threshold(l: IntArray): Int {
        if (l.isEmpty()) return 190
        val hist = IntArray(256)
        for (v in l) hist[v]++
        val target = l.size / 100
        var cum = 0
        var p99 = 255
        for (v in 255 downTo 0) {
            cum += hist[v]
            if (cum >= target) { p99 = v; break }
        }
        return (p99 * 0.85).toInt().coerceIn(150, 235)
    }

    /** Text pixels are bright and have something dark close by (the outline or a dark background). */
    fun mask(l: IntArray, w: Int, h: Int, t: Int): BooleanArray {
        val dark = t / 2
        val m = BooleanArray(l.size)
        val k = w / 1280f   // outline thickness grows with the picture size
        val offs = intArrayOf(maxOf(2, (3 * k).toInt()), maxOf(4, (6 * k).toInt()), maxOf(6, (10 * k).toInt()))
        for (y in 0 until h) {
            for (x in 0 until w) {
                val i = y * w + x
                if (l[i] < t) continue
                var ok = false
                for (d in offs) {
                    if ((x - d >= 0 && l[i - d] < dark) || (x + d < w && l[i + d] < dark) ||
                        (y - d >= 0 && l[i - d * w] < dark) || (y + d < h && l[i + d * w] < dark)) {
                        ok = true
                        break
                    }
                }
                m[i] = ok
            }
        }
        return m
    }

    /**
     * Finds the rows that hold text lines. Each result is [firstRow, lastRow]. Small gaps (the dots and
     * marks of Persian letters) do not split a line; specks much smaller than the tallest line are dropped.
     */
    fun lineSegments(m: BooleanArray, w: Int, h: Int): List<IntArray> {
        val rowMin = maxOf(2, w / 300)
        val raw = ArrayList<IntArray>()
        var start = -1
        for (y in 0 until h) {
            var c = 0
            for (x in 0 until w) if (m[y * w + x]) c++
            if (c >= rowMin) {
                if (start < 0) start = y
            } else if (start >= 0) {
                raw.add(intArrayOf(start, y - 1))
                start = -1
            }
        }
        if (start >= 0) raw.add(intArrayOf(start, h - 1))

        val merged = ArrayList<IntArray>()
        for (s in raw) {
            val last = if (merged.isEmpty()) null else merged[merged.size - 1]
            if (last != null) {
                val gap = s[0] - last[1] - 1
                val hh = maxOf(last[1] - last[0] + 1, s[1] - s[0] + 1)
                if (gap <= maxOf(2, hh / 8)) { last[1] = s[1]; continue }
            }
            merged.add(intArrayOf(s[0], s[1]))
        }
        var tallest = 0
        for (s in merged) tallest = maxOf(tallest, s[1] - s[0] + 1)
        val out = ArrayList<IntArray>()
        for (s in merged) if (s[1] - s[0] + 1 >= maxOf(6, tallest / 4)) out.add(s)
        return out
    }
}
