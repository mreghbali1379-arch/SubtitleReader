package com.example.subtitlereader

import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import java.util.concurrent.TimeUnit

/**
 * Translation with ML Kit. It works without internet once the language models are on the phone.
 * The models are only downloaded when the user presses the download button in the settings (never by themselves).
 */
object Translator {

    fun supported(code: String): Boolean = TranslateLanguage.fromLanguageTag(code) != null

    private fun model(code: String): TranslateRemoteModel =
        TranslateRemoteModel.Builder(TranslateLanguage.fromLanguageTag(code) ?: code).build()

    /** Blocks: call from a background thread. */
    fun isDownloaded(code: String): Boolean = try {
        if (!supported(code)) false
        else Tasks.await(RemoteModelManager.getInstance().isModelDownloaded(model(code)), 15, TimeUnit.SECONDS) == true
    } catch (e: Exception) { false }

    /** Blocks: translating from [src] to [target] needs these models (English is the bridge between other languages). */
    fun ready(src: String, target: String): Boolean {
        if (!supported(src) || !supported(target)) return false
        val need = linkedSetOf(src, target)
        if (src != "en" && target != "en") need.add("en")
        return need.all { isDownloaded(it) }
    }

    /** Starts a download in the background (needs internet once). [done] runs on the main thread. */
    fun download(code: String, done: (Boolean) -> Unit) {
        if (!supported(code)) { done(false); return }
        RemoteModelManager.getInstance().download(model(code), DownloadConditions.Builder().build())
            .addOnSuccessListener { done(true) }
            .addOnFailureListener { done(false) }
    }

    fun delete(code: String, done: (Boolean) -> Unit) {
        if (!supported(code)) { done(false); return }
        RemoteModelManager.getInstance().deleteDownloadedModel(model(code))
            .addOnSuccessListener { done(true) }
            .addOnFailureListener { done(false) }
    }

    /** One translator for one source language. Blocks on the network-free translation: use from a worker thread. */
    class Session(src: String, target: String) {
        private val tr = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(TranslateLanguage.fromLanguageTag(src) ?: TranslateLanguage.ENGLISH)
                .setTargetLanguage(TranslateLanguage.fromLanguageTag(target) ?: TranslateLanguage.PERSIAN)
                .build()
        )

        @Volatile var lastError: String? = null
        private var prepared = false

        /** Loads the (already downloaded) models into the translator. Needed before the first translate call. */
        private fun prepare(): Boolean = try {
            Tasks.await(tr.downloadModelIfNeeded(DownloadConditions.Builder().build()), 120, TimeUnit.SECONDS)
            prepared = true
            true
        } catch (e: Exception) {
            lastError = e.message ?: e.javaClass.simpleName
            false
        }

        /** [timeoutSec] is long when the whole subtitle is translated as one text. */
        fun translate(text: String, timeoutSec: Long = 60): String? {
            if (!prepared && !prepare()) return null
            return try {
                Tasks.await(tr.translate(text), timeoutSec, TimeUnit.SECONDS)
            } catch (e: Exception) {
                lastError = e.message ?: e.javaClass.simpleName
                null
            }
        }

        fun close() { try { tr.close() } catch (ignored: Exception) {} }
    }
}
