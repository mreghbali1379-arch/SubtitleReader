package com.example.subtitlereader

/** Cleans OCR output: unifies Arabic and Persian letters, removes junk characters, fixes punctuation. */
object TextFix {
    private val letters = mapOf(
        '\u064A' to '\u06CC', '\u0649' to '\u06CC', '\u06D0' to '\u06CC', '\u06CD' to '\u06CC',
        '\u06CE' to '\u06CC', '\u06D2' to '\u06CC',            // Arabic and other yeh forms -> Persian yeh
        '\u0643' to '\u06A9', '\u06AA' to '\u06A9',            // kaf forms -> Persian kaf
        '\u0629' to '\u0647',                                  // teh marbuta -> heh
        '\u0623' to '\u0627', '\u0625' to '\u0627', '\u0671' to '\u0627')  // hamza alef forms -> alef

    private const val REMOVED = "\u0640\u200E\u200F\u202A\u202B\u202C\u202D\u202E\u2066\u2067\u2068\u2069\u00AD\uFEFF|_~`^\\<>{}[]"

    private fun isArabicBlock(c: Char) = c in '\u0600'..'\u06FF'

    fun fix(raw: String): String {
        val sb = StringBuilder(raw.length)
        for (ch in raw) {
            if (REMOVED.indexOf(ch) >= 0) continue
            if (ch in '\u0660'..'\u0669') {
                sb.append(('\u06F0'.code + (ch.code - 0x660)).toChar())
            } else {
                sb.append(letters[ch] ?: ch)
            }
        }
        var t = sb.toString().replace(Regex("\\s+"), " ").trim()
        val letterCount = t.count { it.isLetter() }
        val persian = t.count { isArabicBlock(it) && it.isLetter() }
        if (letterCount > 0 && persian * 2 > letterCount) {
            t = t.replace('?', '\u061F').replace(',', '\u060C').replace(';', '\u061B')
            // single stray Latin letters inside a Persian line are noise
            t = t.split(' ').filter { !(it.length == 1 && (it[0] in 'a'..'z' || it[0] in 'A'..'Z')) }.joinToString(" ")
            t = t.replace(Regex("\\s+([\u060C\u061F\u061B!.:])"), "\$1")
        }
        return t.replace(Regex("\\s+"), " ").trim()
    }
}
