package com.example.subtitlereader

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

/** Runs the conversion in the foreground so it goes on when the screen is off or the app is in the background. */
class ConvertService : Service() {

    private var wake: PowerManager.WakeLock? = null
    private var lastNotify = 0L
    private var curUri = ""
    private var curName = ""

    companion object {
        private const val CHANNEL = "convert"
        private const val NOTE_ID = 7
        private const val ACTION_STOP = "stop"

        fun start(c: Context, uri: Uri, name: String, track: Int, durationMs: Long, fresh: Boolean) {
            val key = SpeechStore.key(uri.toString())
            Convert.running = true
            Convert.key = key
            Convert.name = name
            Convert.percent = 0
            Convert.durationMs = durationMs
            Convert.status = "در حال آماده‌سازی…"
            Convert.error = null
            Convert.finished = false
            Convert.stoppedByUser = false
            Convert.lang = ""
            Convert.lastOrig = ""
            Convert.orig = null
            val i = Intent(c, ConvertService::class.java)
            i.putExtra("uri", uri.toString())
            i.putExtra("name", name)
            i.putExtra("track", track)
            i.putExtra("duration", durationMs)
            i.putExtra("fresh", fresh)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }

        fun stop(c: Context) {
            Convert.stoppedByUser = true
            Convert.worker?.cancel()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        if (intent.action == ACTION_STOP) {
            stop(this)
            return START_NOT_STICKY
        }
        val uri = Uri.parse(intent.getStringExtra("uri") ?: "")
        val name = intent.getStringExtra("name") ?: ""
        val track = intent.getIntExtra("track", 0)
        val duration = intent.getLongExtra("duration", 0L)
        val fresh = intent.getBooleanExtra("fresh", false)
        val key = SpeechStore.key(uri.toString())
        curUri = uri.toString()
        curName = name

        createChannel()
        val n = notification(name, "در حال آماده‌سازی…", -1)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTE_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTE_ID, n)
        }

        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "subtitlereader:convert")
            wake?.acquire(12 * 60 * 60 * 1000L)
        } catch (ignored: Exception) {}

        val conv = SpeechConverter(this, uri, key, track, duration, fresh) { postProgress(name) }
        Convert.worker = conv
        Thread {
            try {
                conv.run()
            } finally {
                Convert.running = false
                Convert.worker = null
                try { wake?.release() } catch (ignored: Exception) {}
                finalNotification(name)
                stopForeground(false)
                stopSelf()
            }
        }.start()
        return START_NOT_STICKY
    }

    private fun postProgress(name: String) {
        val now = System.currentTimeMillis()
        if (now - lastNotify < 2000) return
        lastNotify = now
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTE_ID, notification(name, Convert.status, Convert.percent))
    }

    private fun finalNotification(name: String) {
        val text = when {
            Convert.error != null -> Convert.error ?: ""
            Convert.finished -> "ساخت زیرنویس تمام شد"
            else -> "متوقف شد؛ می‌توانید بعداً ادامه دهید"
        }
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val n = builder()
            .setContentTitle(name)
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_cc)
            .setContentIntent(openIntent())
            .setAutoCancel(true)
            .build()
        nm.notify(NOTE_ID + 1, n)
        nm.cancel(NOTE_ID)
    }

    private fun openIntent(): PendingIntent {
        // the first screen: open the film from the list again to see and hear the progress
        val i = Intent(this, HomeActivity::class.java)
        i.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun notification(name: String, text: String, percent: Int): Notification {
        val stopI = Intent(this, ConvertService::class.java).setAction(ACTION_STOP)
        val stopP = PendingIntent.getService(this, 1, stopI, PendingIntent.FLAG_IMMUTABLE)
        val b = builder()
            .setContentTitle(name)
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_cc)
            .setOngoing(true)
            .setContentIntent(openIntent())
            .addAction(Notification.Action.Builder(null, "توقف", stopP).build())
        if (percent >= 0) b.setProgress(100, percent, false) else b.setProgress(0, 0, true)
        return b.build()
    }

    @Suppress("DEPRECATION")
    private fun builder(): Notification.Builder =
        if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "ساخت زیرنویس", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onDestroy() {
        try { wake?.release() } catch (ignored: Exception) {}
        super.onDestroy()
    }
}
