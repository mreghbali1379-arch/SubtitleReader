package com.example.subtitlereader

import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.ColorStateList
import android.net.Uri
import android.graphics.Bitmap
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.TextUtils
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.TextureView
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityEvent
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.TextView
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.AccessibilityDelegateCompat
import androidx.core.view.ViewCompat
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.*
import androidx.media3.common.text.CueGroup
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.media3.ui.TrackSelectionDialogBuilder
import java.io.File
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread
import kotlin.math.abs

class PlayerActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    companion object { const val CONVERTED_LABEL = "converted"; const val EXTERNAL_LABEL = "external" }

    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var ocr: OcrHelper
    private var tts: TextToSpeech? = null

    private var videoUri: Uri? = null
    private var extSrt: File? = null
    private var extNative: SubtitleImport.Result.Native? = null
    private var extKey = ""
    private val subPicked = ArrayList<Uri>()
    private var subConfig: MediaItem.SubtitleConfiguration? = null
    private var convertedFile: File? = null
    private var converter: SubtitleConverter? = null
    private var converting = false
    // lines built so far by the running conversion (read while the film plays)
    private var live: LiveSubs? = null
    private var waitingForSubs = false
    private var liveKey = -1L
    private var lastWaitSpeak = 0L
    private var recentLive = ""
    private var vobToken = 0

    private var speechRate = 1.0f
    private var lastText = ""
    private var lastKey = 0
    private var noDataShown = false
    private val pending = AtomicInteger(0)
    private var id = 0
    private var loadId = 0
    private var analyzedLoad = -1
    private var ttsEngine: String? = null
    private var ttsRetried = false
    private var openedSettings = false
    private var speechVolume = 1.0f
    private var movieVolume = 1.0f
    private var appliedOffset = 0L
    private var quietLoadId = -1
    private lateinit var root: FrameLayout
    private lateinit var topBar: LinearLayout
    private lateinit var bottomBar: LinearLayout
    private lateinit var titleView: TextView
    private lateinit var seek: SeekBar
    private lateinit var posView: TextView
    private lateinit var durView: TextView
    private lateinit var playBtn: ImageButton
    private lateinit var unlockBtn: ImageButton
    private lateinit var hud: TextView
    private lateinit var gestureLayer: View
    private val uiHandler = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { showControls(false) }
    private val hudHide = Runnable { hud.visibility = View.GONE }
    private val unlockHide = Runnable { unlockBtn.visibility = View.GONE }
    private val tick = object : Runnable {
        override fun run() { updateProgress(); uiHandler.postDelayed(this, 500) }
    }
    private var locked = false
    private var controlsShown = true
    private var dragging = false
    private var aspectIndex = 0
    private var mode = 0          // 0 undecided, 1 swipe-seek, 2 brightness, 3 volume, 4 ignore, 5 two-finger seek
    private var downX = 0f
    private var downY = 0f
    private var startPos = 0L
    private var startVol = 1f
    private var startBright = 0.5f
    private var seekTarget = 0L
    private var pendingSeek = false
    private var hardConverter: HardsubConverter? = null
    private var mediaSession: MediaSession? = null
    private var twoTapStart = 0L
    private var hardsubOn = false
    private var hsBusy = false
    private var hsPrev = ""
    private var hsSpoken = ""
    private val hsTick = object : Runnable {
        override fun run() {
            if (!hardsubOn) return
            sampleHardsub()
            uiHandler.postDelayed(this, 700)
        }
    }

    private val saveSrt = registerForActivityResult(ActivityResultContracts.CreateDocument("application/x-subrip")) { uri ->
        if (uri != null) writeSrt(uri)
    }

    private val liveTick = object : Runnable {
        override fun run() {
            if (!converting || live == null) return
            liveStep()
            uiHandler.postDelayed(this, 250)
        }
    }

    private val pickSub = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { list ->
        if (!list.isNullOrEmpty()) {
            list.forEach { keep(it) }
            subPicked.addAll(list)
            handleSubtitleFiles(ArrayList(subPicked))
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speechRate = Prefs.rate(this)
        speechVolume = Prefs.volume(this)
        movieVolume = Prefs.movieVolume(this)
        startTts()
        ocr = OcrHelper(this)

        player = ExoPlayer.Builder(this).build()
        player.volume = movieVolume
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .setPreferredTextLanguage("fa")
            .setSelectUndeterminedTextLanguage(true)
            .build()
        player.addListener(object : Player.Listener {
            override fun onTracksChanged(tracks: Tracks) = analyze(tracks)
            override fun onCues(cueGroup: CueGroup) = handleCues(cueGroup)
            override fun onIsPlayingChanged(isPlaying: Boolean) = updatePlayIcon()
            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) = updatePlayIcon()
        })

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        buildUi()

        // Full screen: hide the status and navigation bars (a swipe from the edge shows them briefly).
        val bars = WindowCompat.getInsetsController(window, window.decorView)
        bars.hide(WindowInsetsCompat.Type.systemBars())
        bars.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE

        if (intent?.action != Intent.ACTION_VIEW || intent?.data == null) {
            finish()
            return
        }
        setupMediaSession()
        if (Prefs.hardsub(this)) setHardsub(true, false)
        handleIntent(intent)
    }

    // ---------- screen layout (MX Player style) ----------

    private fun buildUi() {
        val c = this
        playerView = (layoutInflater.inflate(R.layout.player_view, null) as PlayerView).apply {
            this.player = this@PlayerActivity.player
            useController = false
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS
        }

        gestureLayer = View(this).apply {
            isClickable = true
            setOnClickListener { onScreenTap() }
            setOnTouchListener { v, e -> onGesture(v, e) }
        }
        ViewCompat.setAccessibilityDelegate(gestureLayer, object : AccessibilityDelegateCompat() {
            override fun onInitializeAccessibilityNodeInfo(host: View, info: AccessibilityNodeInfoCompat) {
                super.onInitializeAccessibilityNodeInfo(host, info)
                info.isScrollable = true
                info.addAction(AccessibilityNodeInfoCompat.AccessibilityActionCompat.ACTION_SCROLL_FORWARD)
                info.addAction(AccessibilityNodeInfoCompat.AccessibilityActionCompat.ACTION_SCROLL_BACKWARD)
            }

            override fun performAccessibilityAction(host: View, action: Int, args: Bundle?): Boolean {
                return when (action) {
                    AccessibilityNodeInfoCompat.ACTION_SCROLL_FORWARD -> { seekBy(skipMs(), true); true }
                    AccessibilityNodeInfoCompat.ACTION_SCROLL_BACKWARD -> { seekBy(-skipMs(), true); true }
                    else -> super.performAccessibilityAction(host, action, args)
                }
            }
        })

        titleView = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_VERTICAL
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        }
        topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xCC000000.toInt(), 0))
            val p = Ui.dp(c, 8)
            setPadding(p, p, p, p)
            addView(Ui.icon(c, R.drawable.ic_back, "بازگشت") { finish() })
            addView(titleView, LinearLayout.LayoutParams(0, -2, 1f))
            addView(Ui.icon(c, R.drawable.ic_cc, "زیرنویس") { showSubtitleMenu() })
            addView(Ui.icon(c, R.drawable.ic_more, "گزینه‌ها") { showMoreMenu() })
        }

        posView = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; text = "00:00" }
        durView = TextView(this).apply { setTextColor(Color.WHITE); textSize = 14f; text = "00:00" }
        seek = SeekBar(this).apply {
            progressTintList = ColorStateList.valueOf(Ui.ACCENT)
            thumbTintList = ColorStateList.valueOf(Ui.ACCENT)
            contentDescription = "نوار پیشرفت فیلم"
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    posView.text = Ui.time(p.toLong())
                    if (!dragging) player.seekTo(p.toLong())   // screen-reader adjustment
                }
                override fun onStartTrackingTouch(s: SeekBar) {
                    dragging = true
                    uiHandler.removeCallbacks(hideRunnable)
                }
                override fun onStopTrackingTouch(s: SeekBar) {
                    dragging = false
                    player.seekTo(s.progress.toLong())
                    restartHide()
                }
            })
        }
        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(posView)
            addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
            addView(durView)
        }

        playBtn = Ui.icon(c, R.drawable.ic_pause, "پخش یا توقف", 64) { togglePlay() }
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(Ui.icon(c, R.drawable.ic_lock, "قفل کردن صفحه") { lockScreen() })
            addView(View(c), LinearLayout.LayoutParams(Ui.dp(c, 48), 1))
            addView(View(c), LinearLayout.LayoutParams(0, 1, 1f))
            addView(playBtn)
            addView(View(c), LinearLayout.LayoutParams(0, 1, 1f))
            addView(Ui.icon(c, R.drawable.ic_aspect, "تغییر اندازه تصویر") { cycleAspect() })
            addView(Ui.icon(c, R.drawable.ic_rotate, "چرخاندن صفحه") { rotateScreen() })
        }
        bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, intArrayOf(0xCC000000.toInt(), 0))
            val p = Ui.dp(c, 12)
            setPadding(p, p, p, p)
            addView(row1, LinearLayout.LayoutParams(-1, -2))
            addView(row2, LinearLayout.LayoutParams(-1, -2))
        }

        hud = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 28f
            gravity = Gravity.CENTER
            visibility = View.GONE
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            setPadding(Ui.dp(c, 24), Ui.dp(c, 12), Ui.dp(c, 24), Ui.dp(c, 12))
            background = GradientDrawable().apply {
                setColor(0xAA000000.toInt())
                cornerRadius = Ui.dp(c, 12).toFloat()
            }
        }

        unlockBtn = Ui.icon(c, R.drawable.ic_unlock, "باز کردن قفل صفحه", 64) {
            locked = false
            unlockBtn.visibility = View.GONE
            showControls(true)
            announce("قفل صفحه باز شد")
        }
        unlockBtn.visibility = View.GONE

        root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutDirection = View.LAYOUT_DIRECTION_LTR
            addView(playerView, FrameLayout.LayoutParams(-1, -1))
            addView(gestureLayer, FrameLayout.LayoutParams(-1, -1))
            addView(topBar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
            addView(bottomBar, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
            addView(hud, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
            addView(unlockBtn, FrameLayout.LayoutParams(Ui.dp(c, 64), Ui.dp(c, 64), Gravity.END or Gravity.CENTER_VERTICAL))
        }
        setContentView(root)

        keepAlive(topBar)
        keepAlive(bottomBar)
        showControls(true)
    }

    /** Keeps the buttons visible while a screen reader moves focus between them. */
    private fun keepAlive(vg: ViewGroup) {
        vg.accessibilityDelegate = object : View.AccessibilityDelegate() {
            override fun onRequestSendAccessibilityEvent(host: ViewGroup, child: View, event: AccessibilityEvent): Boolean {
                restartHide()
                return super.onRequestSendAccessibilityEvent(host, child, event)
            }
        }
    }

    private fun announce(msg: String) {
        if (::root.isInitialized) root.announceForAccessibility(msg)
    }

    // ---------- controls: show, hide, lock ----------

    private fun showControls(show: Boolean) {
        controlsShown = show
        val vis = if (show && !locked) View.VISIBLE else View.GONE
        topBar.visibility = vis
        bottomBar.visibility = vis
        uiHandler.removeCallbacks(hideRunnable)
        if (show && !locked) uiHandler.postDelayed(hideRunnable, Prefs.hideSeconds(this) * 1000L)
    }

    private fun restartHide() {
        if (!::topBar.isInitialized) return
        if (controlsShown && !locked && !dragging) {
            uiHandler.removeCallbacks(hideRunnable)
            uiHandler.postDelayed(hideRunnable, Prefs.hideSeconds(this) * 1000L)
        }
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        restartHide()
    }

    private fun onScreenTap() {
        if (locked) showUnlock() else showControls(!controlsShown)
    }

    private fun showUnlock() {
        unlockBtn.visibility = View.VISIBLE
        uiHandler.removeCallbacks(unlockHide)
        uiHandler.postDelayed(unlockHide, 3000)
    }

    private fun lockScreen() {
        locked = true
        showControls(false)
        showUnlock()
        announce("صفحه قفل شد")
    }

    // ---------- playback actions ----------

    private fun skipMs() = Prefs.skipSeconds(this) * 1000L

    private fun togglePlay() {
        waitingForSubs = false
        player.playWhenReady = !player.playWhenReady
        updatePlayIcon()
        showHud(if (player.playWhenReady) "پخش" else "توقف")
    }

    /**
     * Lets media buttons (headphones, and the screen reader's "two-finger tap = pause or resume")
     * pause and resume the film.
     */
    @Suppress("DEPRECATION")
    private fun setupMediaSession() {
        val ms = MediaSession(this, "SubtitleReader")
        ms.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS or MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS)
        ms.setCallback(object : MediaSession.Callback() {
            override fun onPlay() { runOnUiThread { setPlaying(true) } }
            override fun onPause() { runOnUiThread { setPlaying(false) } }
        })
        mediaSession = ms
        publishState(player.playWhenReady)
        ms.isActive = true
    }

    private fun publishState(playing: Boolean) {
        val st = PlaybackState.Builder()
            .setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE)
            .setState(if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED,
                player.currentPosition, 1f)
            .build()
        mediaSession?.setPlaybackState(st)
    }

    private fun setPlaying(on: Boolean) {
        waitingForSubs = false
        player.playWhenReady = on
        updatePlayIcon()
        showHud(if (on) "پخش" else "توقف")
    }

    private fun updatePlayIcon() {
        if (!::playBtn.isInitialized) return
        val playing = player.playWhenReady
        playBtn.setImageResource(if (playing) R.drawable.ic_pause else R.drawable.ic_play)
        playBtn.contentDescription = if (playing) "توقف" else "پخش"
        publishState(playing)
    }

    private fun clampPos(t: Long): Long {
        val d = player.duration
        val max = if (d == C.TIME_UNSET || d <= 0) Long.MAX_VALUE else d
        return t.coerceIn(0L, max)
    }

    private fun seekBy(ms: Long, say: Boolean = false) {
        player.seekTo(clampPos(player.currentPosition + ms))
        val txt = (if (ms >= 0) "+" else "-") + (abs(ms) / 1000) + " ثانیه"
        showHud(txt)
        if (say) announce(txt)
        updateProgress()
    }

    private fun updateProgress() {
        if (!::seek.isInitialized || dragging) return
        val d = player.duration
        val dur = if (d == C.TIME_UNSET || d < 0) 0L else d
        seek.max = dur.coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        seek.progress = player.currentPosition.coerceIn(0L, dur).toInt()
        seek.secondaryProgress = player.bufferedPosition.coerceIn(0L, dur).toInt()
        posView.text = Ui.time(player.currentPosition)
        durView.text = Ui.time(dur)
    }

    private fun cycleAspect() {
        val modes = intArrayOf(
            AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM,
            AspectRatioFrameLayout.RESIZE_MODE_FILL)
        val names = arrayOf("اندازه اصلی", "برش برای پر کردن صفحه", "کشیده")
        aspectIndex = (aspectIndex + 1) % modes.size
        playerView.resizeMode = modes[aspectIndex]
        showHud(names[aspectIndex])
        announce(names[aspectIndex])
    }

    private fun rotateScreen() {
        requestedOrientation =
            if (requestedOrientation == ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT)
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
    }

    // ---------- touch gestures ----------

    private val detector by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean { onScreenTap(); return true }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return true
                val w = gestureLayer.width.toFloat()
                when {
                    e.x < w / 3f -> seekBy(-skipMs())
                    e.x > w * 2f / 3f -> seekBy(skipMs())
                    else -> togglePlay()
                }
                return true
            }
        })
    }

    private fun seekText(delta: Long, target: Long): String =
        (if (delta >= 0) "+" else "-") + Ui.time(abs(delta)) + "  (" + Ui.time(target) + ")"

    private fun showHud(t: String) {
        hud.text = t
        hud.visibility = View.VISIBLE
        uiHandler.removeCallbacks(hudHide)
        uiHandler.postDelayed(hudHide, 900)
    }

    private fun currentBrightness(): Float {
        val b = window.attributes.screenBrightness
        return if (b < 0f) 0.5f else b
    }

    private fun applyMovieVolume(v: Float) {
        movieVolume = v
        Prefs.setMovieVolume(this, v)
        player.volume = if (pending.get() > 0) v * 0.3f else v
        showHud("صدای فیلم: " + Math.round(v * 100) + " درصد")
    }

    private fun onGesture(v: View, e: MotionEvent): Boolean {
        detector.onTouchEvent(e)
        if (locked) return true
        val w = v.width.toFloat().coerceAtLeast(1f)
        val h = v.height.toFloat().coerceAtLeast(1f)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y
                mode = 0; pendingSeek = false
                startPos = player.currentPosition; seekTarget = startPos
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (e.pointerCount == 2) {
                    // Two fingers: move left or right to go back or forward in the film.
                    mode = 5; pendingSeek = false
                    twoTapStart = e.eventTime
                    downX = (e.getX(0) + e.getX(1)) / 2f
                    startPos = player.currentPosition; seekTarget = startPos
                } else {
                    mode = 4
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (mode == 5 && e.pointerCount >= 2) {
                    val x = (e.getX(0) + e.getX(1)) / 2f
                    val slop = ViewConfiguration.get(this).scaledTouchSlop
                    if (pendingSeek || abs(x - downX) > slop) {
                        seekTarget = clampPos(startPos + ((x - downX) / w * 180_000f).toLong())
                        pendingSeek = true
                        showHud(seekText(seekTarget - startPos, seekTarget))
                    }
                } else if (mode in 0..3 && e.pointerCount == 1) {
                    val dx = e.x - downX
                    val dy = e.y - downY
                    if (mode == 0) {
                        val slop = ViewConfiguration.get(this).scaledTouchSlop
                        if (abs(dx) > slop || abs(dy) > slop) {
                            mode = if (abs(dx) > abs(dy)) 1 else if (downX < w / 2f) 2 else 3
                            startPos = player.currentPosition
                            startVol = movieVolume
                            startBright = currentBrightness()
                        }
                    }
                    when (mode) {
                        1 -> {
                            seekTarget = clampPos(startPos + (dx / w * 90_000f).toLong())
                            pendingSeek = true
                            showHud(seekText(seekTarget - startPos, seekTarget))
                        }
                        2 -> {
                            val b = (startBright - dy / h * 1.2f).coerceIn(0.02f, 1f)
                            val lp = window.attributes
                            lp.screenBrightness = b
                            window.attributes = lp
                            showHud("روشنایی: " + Math.round(b * 100) + " درصد")
                        }
                        3 -> {
                            val vol = Math.round((startVol - dy / h * 1.2f).coerceIn(0f, 1f) * 20f) / 20f
                            applyMovieVolume(vol)
                        }
                    }
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (mode == 5) {
                    if (pendingSeek) {
                        player.seekTo(seekTarget); pendingSeek = false
                    } else if (e.eventTime - twoTapStart < 400) {
                        togglePlay()   // a quick two-finger tap pauses or resumes
                    }
                }
                mode = 4
            }
            MotionEvent.ACTION_UP -> {
                if ((mode == 1 || mode == 5) && pendingSeek) player.seekTo(seekTarget)
                pendingSeek = false
                mode = 0
            }
            MotionEvent.ACTION_CANCEL -> { pendingSeek = false; mode = 0 }
        }
        return true
    }

    // ---------- menus ----------

    private fun showSubtitleMenu() {
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        labels.add("افزودن فایل زیرنویس"); actions.add { subPicked.clear(); pickSub.launch(arrayOf("*/*")) }
        labels.add("انتخاب زیرنویس داخل فیلم"); actions.add { chooseEmbedded() }
        labels.add("تأخیر زیرنویس"); actions.add { Ui.syncMenu(this) { applySync() } }
        labels.add("ساخت فایل زیرنویس از روی تصویر (هاردساب)"); actions.add { startHardsubConversion() }
        labels.add(if (hardsubOn) "خاموش کردن خواندن زنده زیرنویس چسبیده به تصویر" else "خواندن زنده زیرنویس چسبیده به تصویر")
        actions.add { setHardsub(!hardsubOn, true) }
        if (converting) { labels.add("توقف تبدیل (بعداً می‌توانید ادامه دهید)"); actions.add { cancelConversion() } }
        if (canSaveSrt()) {
            labels.add(if (converting) "ذخیره زیرنویس ساخته‌شده تا اینجا (فایل SRT)" else "ذخیره زیرنویس به صورت فایل SRT")
            actions.add { saveSrtFile() }
        }
        labels.add("تنظیمات"); actions.add { openSettings() }
        AlertDialog.Builder(this)
            .setTitle("زیرنویس")
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .show()
    }

    private fun showMoreMenu() {
        val labels = arrayOf("سرعت پخش فیلم", "تنظیمات")
        AlertDialog.Builder(this)
            .setItems(labels) { _, which ->
                if (which == 0) showSpeedMenu() else openSettings()
            }
            .show()
    }

    private fun showSpeedMenu() {
        val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val labels = arrayOf("0.5", "0.75", "1", "1.25", "1.5", "2")
        AlertDialog.Builder(this)
            .setTitle("سرعت پخش فیلم")
            .setItems(labels) { _, which ->
                player.setPlaybackSpeed(speeds[which])
                announce("سرعت پخش " + labels[which])
            }
            .show()
    }

    private fun applySync() {
        if (videoUri != null && !converting && Prefs.syncOffset(this) != appliedOffset) {
            refreshAndLoad(player.currentPosition, player.playWhenReady, true)
        }
    }

    // ---------- hard-coded subtitles (burned into the picture) ----------

    private fun setHardsub(on: Boolean, announceIt: Boolean) {
        if (on && !ocr.hasData()) {
            speak("فایل زبان OCR اضافه نشده است")
            return
        }
        hardsubOn = on
        Prefs.setHardsub(this, on)
        hsPrev = ""; hsSpoken = ""; hsBusy = false
        uiHandler.removeCallbacks(hsTick)
        if (on) uiHandler.post(hsTick)
        if (announceIt) speak(if (on)
            "خواندن زنده زیرنویس روشن شد"
        else "خواندن زنده زیرنویس خاموش شد")
    }

    /** Reads the whole film once, builds a subtitle file from the burned-in text; the film can be played meanwhile. */
    private fun startHardsubConversion() {
        val v = videoUri ?: return
        if (converting) { speak("یک تبدیل در حال انجام است"); return }
        if (!ocr.hasData()) {
            speak("فایل زبان OCR اضافه نشده است")
            return
        }
        val band = Prefs.hardsubBand(this)
        val step = Prefs.hardsubStepMs(this)
        // the key has two parts: the film, and the settings (area, step, engine) the subtitle was built with
        val baseKey = Integer.toHexString("hard|$v".hashCode())
        val engine = Prefs.ocrEngine(this) + (if (Prefs.ocrEngine(this) == "drive" && Prefs.driveAllFrames(this)) "+all" else "")
        val key = baseKey + "_" + Integer.toHexString("$band|$step|$engine".hashCode())
        val convDir = File(filesDir, "converted").apply { mkdirs() }
        val cache = File(convDir, "$key.srt")
        if (cache.exists() && cache.length() > 0) {
            speak("نسخه متنی زیرنویس آماده است")
            convertedFile = cache
            refreshAndLoad()
            return
        }
        if (hardsubOn) setHardsub(false, false)
        player.playWhenReady = false
        val startNew = {
            askResume(key, { player.playWhenReady = true }) { store, covered ->
                runHardsub(v, band, step, cache, store, covered)
            }
        }

        // the same film was converted (or partly converted) with other settings: ask before building again
        if (askOtherVersion(baseKey, key, "(فاصله‌ی نمونه‌برداری، ناحیه، موتور تشخیص متن یا ارسال فریم‌ها به گوگل)", startNew) { other ->
                runHardsub(v, band, step, cache, other, other.coveredUpTo)
            }) return
        startNew()
    }

    private fun runHardsub(v: Uri, band: Int, step: Int, cache: File, store: LiveSubs, from: Long) {
        beginLive(store)
        speak(if (from > 0) "ادامه ساخت زیرنویس. می‌توانید فیلم را پخش کنید؛ پخش تا جایی که زیرنویس ساخته شده پیش می‌رود"
              else "در حال ساخت زیرنویس. می‌توانید همین حالا فیلم را پخش کنید؛ پخش تا جایی که زیرنویس ساخته شده پیش می‌رود")
        hardConverter = HardsubConverter(this, ocr).also { c ->
            c.start(v, band, step.toLong(), store, from,
                onProgress = { p -> runOnUiThread { if (!player.isPlaying) speak("$p درصد") } },
                onDone = { srt ->
                    runOnUiThread {
                        hardConverter = null
                        if (srt == null) {
                            val wasWaiting = waitingForSubs
                            stopLive()
                            speak("ساخت زیرنویس ناموفق بود: " + c.reason)
                            if (wasWaiting) player.playWhenReady = true
                        } else {
                            conversionDone(cache, store, srt)
                        }
                    }
                })
        }
    }

    private fun grabBand(): Bitmap? {
        val tv = playerView.videoSurfaceView as? TextureView ?: return null
        if (!tv.isAvailable || tv.width <= 0 || tv.height <= 0) return null
        val w = minOf(tv.width, 1920)
        val h = tv.height * w / tv.width
        if (h < 60) return null
        val full: Bitmap = (try { tv.getBitmap(w, h) } catch (e: Exception) { null }) ?: return null
        val bandH = (h * Prefs.hardsubBand(this) / 100).coerceIn(40, h)
        val band = Bitmap.createBitmap(full, 0, h - bandH, w, bandH)
        if (band !== full) full.recycle()
        return band
    }

    private fun sampleHardsub() {
        if (hsBusy || converting || !player.isPlaying) return
        val band = grabBand() ?: return
        hsBusy = true
        ocr.recognizeFrame(band, liveDrive()) { t ->
            runOnUiThread {
                hsBusy = false
                if (t == null) {
                    if (!noDataShown) {
                        noDataShown = true
                        speak("فایل زبان OCR اضافه نشده است")
                    }
                } else {
                    onHardsubText(t)
                }
            }
        }
    }

    private fun onHardsubText(t: String) {
        if (!hardsubOn) return
        val n = t.replace(Regex("\\s+"), " ").trim()
        val nonSpace = n.count { !it.isWhitespace() }
        val letters = n.count { it.isLetter() }
        val good = nonSpace >= 3 && letters * 10 >= nonSpace * 6
        if (!good) {
            hsPrev = ""
            if (n.isEmpty()) hsSpoken = ""   // the line is gone: the same line may be read again later
            return
        }
        // Read a line only when it appears in two samples in a row, so scene noise is not spoken.
        if (similar(n, hsPrev) && !similar(n, hsSpoken)) {
            hsSpoken = n
            speak(n)
        }
        hsPrev = n
    }

    private fun lev(a: String, b: String): Int {
        val prev = IntArray(b.length + 1) { it }
        val cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            }
            System.arraycopy(cur, 0, prev, 0, cur.size)
        }
        return prev[b.length]
    }

    private fun similar(a: String, b: String): Boolean {
        val x = a.replace(" ", "")
        val y = b.replace(" ", "")
        if (x.isEmpty() || y.isEmpty()) return false
        if (x == y) return true
        val m = maxOf(x.length, y.length)
        if (abs(x.length - y.length) > m / 3) return false
        return lev(x, y) <= m / 4
    }

    private fun openSettings() {
        openedSettings = true
        startActivity(Intent(this, SettingsActivity::class.java))
    }


    private fun startTts() {
        ttsEngine = Prefs.engine(this)
        tts = TextToSpeech(this, this, ttsEngine)
    }

    override fun onResume() {
        super.onResume()
        restartHide()
        uiHandler.removeCallbacks(tick)
        uiHandler.post(tick)
        if (!openedSettings) return
        openedSettings = false
        ocr.reset()
        noDataShown = false
        speechRate = Prefs.rate(this)
        tts?.setSpeechRate(speechRate)
        speechVolume = Prefs.volume(this)
        movieVolume = Prefs.movieVolume(this)
        if (pending.get() <= 0) player.volume = movieVolume
        if (videoUri != null && !converting &&
            Prefs.syncOffset(this) != appliedOffset) {
            refreshAndLoad(player.currentPosition, player.playWhenReady, true)
        }
        if (Prefs.engine(this) != ttsEngine) {
            ttsRetried = false
            pending.set(0)
            tts?.shutdown()
            startTts()
        }
    }

    /** Opens a film picked inside the app or sent by another app ("Open with"). */
    private fun displayName(u: Uri): String {
        try {
            contentResolver.query(u, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) { val n = c.getString(0); if (!n.isNullOrBlank()) return n }
            }
        } catch (ignored: Exception) {
        }
        return u.lastPathSegment ?: "فیلم"
    }

    private fun openVideo(u: Uri) {
        keep(u)
        videoUri = u
        val name = displayName(u)
        titleView.text = name
        Prefs.addRecent(this, u.toString(), name)
        extSrt = null; extNative = null; extKey = ""
        subPicked.clear()
        Prefs.setSyncOffset(this, 0L)
        resetConversion()
        refreshAndLoad()
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action != Intent.ACTION_VIEW) return
        val data = i.data ?: return
        openVideo(data)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun keep(u: Uri) {
        try { contentResolver.takePersistableUriPermission(u, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (ignored: Exception) {}
    }

    private fun langName(code: String?): String {
        val c = (code ?: "").lowercase()
        return when {
            c.startsWith("fa") || c == "per" || c == "fas" -> "فارسی"
            c.startsWith("en") || c == "eng" -> "انگلیسی"
            c.startsWith("ar") || c == "ara" -> "عربی"
            c.startsWith("tr") || c == "tur" -> "ترکی"
            c.isEmpty() || c == "und" -> "زبان نامشخص"
            else -> c
        }
    }

    private fun isPersian(g: Tracks.Group): Boolean {
        val c = (g.getTrackFormat(0).language ?: "").lowercase()
        return c.startsWith("fa") || c == "per" || c == "fas"
    }

    private fun kindName(m: String?): String = when (m) {
        MimeTypes.APPLICATION_PGS -> "تصویری PGS"
        MimeTypes.APPLICATION_DVBSUBS -> "تصویری DVB"
        MimeTypes.APPLICATION_VOBSUB -> "تصویری VobSub"
        else -> "متنی"
    }

    private fun describe(g: Tracks.Group): String {
        val f = g.getTrackFormat(0)
        return langName(f.language) + "، " + kindName(f.sampleMimeType) + (if (g.isSupported) "" else " (پشتیبانی نمی‌شود)")
    }

    private fun isImage(m: String?) =
        m == MimeTypes.APPLICATION_PGS || m == MimeTypes.APPLICATION_DVBSUBS || m == MimeTypes.APPLICATION_VOBSUB

    private fun resetConversion() {
        converter?.cancel(); converter = null
        hardConverter?.cancel(); hardConverter = null
        vobToken++
        stopLive()
        live = null
        convertedFile = null
    }

    private fun refreshAndLoad(resume: Long = 0L, play: Boolean = true, quiet: Boolean = false) {
        if (videoUri == null) return
        load(resume, play)
        if (quiet) quietLoadId = loadId
    }

    private fun load(resume: Long = 0L, play: Boolean = true) {
        val v = videoUri ?: return
        loadId++
        lastText = ""; lastKey = 0
        val conv = convertedFile
        val eSrt = extSrt
        val eNat = extNative
        val off = Prefs.syncOffset(this)
        val base = conv ?: eSrt
        val synced = if (base != null) SubtitleSync.apply(this, base, off) else null
        appliedOffset = off
        Prefs.setSyncSupported(this, base != null)
        subConfig = when {
            conv != null -> MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(synced ?: conv))
                .setMimeType(MimeTypes.APPLICATION_SUBRIP)
                .setLanguage("fa")
                .setLabel(CONVERTED_LABEL)
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
            eSrt != null -> MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(synced ?: eSrt))
                .setMimeType(MimeTypes.APPLICATION_SUBRIP)
                .setLabel(EXTERNAL_LABEL)
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
            eNat != null -> MediaItem.SubtitleConfiguration.Builder(eNat.uri)
                .setMimeType(eNat.mime)
                .setLabel(EXTERNAL_LABEL)
                .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                .build()
            else -> null
        }
        val b = MediaItem.Builder().setUri(v)
        subConfig?.let { b.setSubtitleConfigurations(listOf(it)) }
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .clearOverridesOfType(C.TRACK_TYPE_TEXT).build()
        player.setMediaItem(b.build(), resume)
        player.prepare()
        player.playWhenReady = play
    }

    private fun select(g: Tracks.Group) {
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0)).build()
    }

    /** Looks at the subtitle tracks once per loaded film and tells the user what was found. */
    private fun say(m: String) { if (quietLoadId != loadId) speak(m) }

    private fun analyze(tracks: Tracks) {
        if (analyzedLoad == loadId || tracks.groups.isEmpty()) return
        analyzedLoad = loadId
        val textGroups = tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
        if (textGroups.isEmpty()) { say("در این فیلم زیرنویسی پیدا نشد"); return }
        val info = textGroups.mapIndexed { i, g -> "${i + 1}: " + describe(g) }.joinToString("؛ ")
        val usable = textGroups.filter { it.isSupported }
        if (usable.isEmpty()) {
            val vob = textGroups.any { it.getTrackFormat(0).sampleMimeType == MimeTypes.APPLICATION_VOBSUB }
            say(if (vob)
                "زیرنویس داخل فیلم از نوع VobSub است و باز نمی‌شود"
            else "زیرنویس پیدا شد ولی باز نمی‌شود: $info")
            return
        }
        val wanted = when {
            convertedFile != null -> CONVERTED_LABEL
            subConfig != null -> EXTERNAL_LABEL
            else -> null
        }
        val labeled = if (wanted != null) usable.firstOrNull { it.getTrackFormat(0).label == wanted } else null
        if (convertedFile != null) {
            select(labeled ?: usable.first())
            say("زیرنویس تبدیل‌شده فعال شد")
            return
        }
        val chosen = labeled ?: usable.firstOrNull { isPersian(it) } ?: usable.firstOrNull { it.isSelected } ?: usable.first()
        if (labeled == null) {
            say(if (textGroups.size > 1)
                "${textGroups.size} زیرنویس: $info. ${describe(chosen)} انتخاب شد"
            else "زیرنویس ${describe(chosen)} پیدا شد")
        }
        if (!isImage(chosen.getTrackFormat(0).sampleMimeType)) {
            select(chosen)
            if (labeled != null) say("فایل زیرنویس جداگانه فعال شد")
            return
        }
        select(chosen)
        startConversion(textGroups.indexOf(chosen))
    }

    private fun startConversion(textIndex: Int) {
        val v = videoUri ?: return
        val baseKey = Integer.toHexString("$v|$extKey|$textIndex".hashCode())
        val key = baseKey + "_" + Prefs.ocrEngine(this)
        val dir = File(filesDir, "converted").apply { mkdirs() }
        val cache = File(dir, "$key.srt")
        if (cache.exists() && cache.length() > 0) {
            speak("نسخه متنی زیرنویس آماده است")
            convertedFile = cache
            refreshAndLoad()
            return
        }
        if (!ocr.hasData()) {
            speak("فایل زبان OCR اضافه نشده است")
            return
        }
        player.playWhenReady = false
        val startNew = {
            askResume(key, { player.playWhenReady = true }) { store, covered ->
                runConversion(v, textIndex, cache, store, maxOf(0L, covered - 2000))
            }
        }
        if (askOtherVersion(baseKey, key, "(موتور تشخیص متن)", startNew) { other ->
                runConversion(v, textIndex, cache, other, maxOf(0L, other.coveredUpTo - 2000))
            }) return
        startNew()
    }

    private fun runConversion(v: Uri, textIndex: Int, cache: File, store: LiveSubs, from: Long) {
        beginLive(store)
        speak(if (from > 0) "ادامه تبدیل زیرنویس. می‌توانید فیلم را پخش کنید؛ پخش تا جایی که زیرنویس ساخته شده پیش می‌رود"
              else "زیرنویس تصویری پیدا شد. در حال تبدیل به متن. می‌توانید همین حالا فیلم را پخش کنید؛ پخش تا جایی که زیرنویس ساخته شده پیش می‌رود")
        converter = SubtitleConverter(this, ocr).also { c ->
            c.start(v, subConfig, textIndex, store, from,
                onProgress = { if (!player.isPlaying) speak("$it درصد") },
                onNoData = {
                    val wasWaiting = waitingForSubs
                    stopLive()
                    speak("فایل زبان تشخیص متن پیدا نشد")
                    if (wasWaiting) player.playWhenReady = true
                },
                onDone = { srt ->
                    converter = null
                    if (srt == null) {
                        val wasWaiting = waitingForSubs
                        stopLive()
                        speak("تبدیل ناموفق بود: " + c.reason + ". زیرنویس به صورت زنده خوانده می‌شود")
                        if (wasWaiting) player.playWhenReady = true
                    } else {
                        conversionDone(cache, store, srt)
                    }
                })
        }
    }

    // ---------- running conversion: continue, play meanwhile, save ----------

    private fun partialFiles(key: String): Pair<File, File> {
        val d = File(filesDir, "partial").apply { mkdirs() }
        return Pair(File(d, "$key.srt"), File(d, "$key.pos"))
    }

    /**
     * Looks for a result of the same conversion made with other settings (same [baseKey], other variant)
     * and asks what to do instead of silently building again. Returns true if a question was shown.
     * [what] names the settings that differ; [startNew] builds from zero with the current settings;
     * [continueWith] continues an unfinished copy made with the other settings.
     */
    private fun askOtherVersion(baseKey: String, key: String, what: String, startNew: () -> Unit,
                                continueWith: (LiveSubs) -> Unit): Boolean {
        val convDir = File(filesDir, "converted").apply { mkdirs() }
        val finished = convDir.listFiles { f -> f.name.startsWith(baseKey + "_") && f.name.endsWith(".srt") && f.length() > 0 }
            ?.maxByOrNull { it.lastModified() }
        if (finished != null) {
            AlertDialog.Builder(this)
                .setTitle("زیرنویسِ ساخته‌شده‌ی قبلی")
                .setMessage("برای این زیرنویس قبلاً با تنظیمات دیگری $what فایل متنی ساخته شده است. از همان زیرنویس استفاده شود یا با تنظیمات فعلی از اول ساخته شود؟")
                .setPositiveButton("استفاده از زیرنویس قبلی") { _, _ ->
                    convertedFile = finished
                    refreshAndLoad()
                }
                .setNegativeButton("ساخت از اول با تنظیمات فعلی") { _, _ -> startNew() }
                .setOnCancelListener { player.playWhenReady = true }
                .show()
            return true
        }
        val partialDir = File(filesDir, "partial")
        val other = partialDir.listFiles { f -> f.name.startsWith(baseKey + "_") && f.name.endsWith(".srt") && !f.name.startsWith("$key.") }
            ?.mapNotNull { f -> LiveSubs.load(f, File(partialDir, f.name.removeSuffix(".srt") + ".pos")) }
            ?.maxByOrNull { it.coveredUpTo }
        if (other != null) {
            val min = (other.coveredUpTo / 60000).toInt()
            AlertDialog.Builder(this)
                .setTitle("ادامه تبدیل زیرنویس")
                .setMessage("بخشی از این زیرنویس تا حدود دقیقه $min با تنظیمات دیگری $what ساخته شده است. از همان‌جا ادامه بدهم (بقیه با تنظیمات فعلی ساخته می‌شود) یا با تنظیمات فعلی از اول شروع شود؟")
                .setPositiveButton("ادامه از همان‌جا") { _, _ -> continueWith(other) }
                .setNegativeButton("شروع از صفر با تنظیمات فعلی") { _, _ -> startNew() }
                .setOnCancelListener { player.playWhenReady = true }
                .show()
            return true
        }
        return false
    }

    /**
     * If an unfinished copy of this conversion exists, asks whether to continue it or start from zero.
     * [go] gets the store to fill and the film time (ms) up to which the old copy is final (0 when starting over).
     */
    private fun askResume(key: String, onCancel: () -> Unit, go: (LiveSubs, Long) -> Unit) {
        val (f, m) = partialFiles(key)
        val old = LiveSubs.load(f, m)
        if (old == null) {
            f.delete(); m.delete()
            go(LiveSubs(f, m), 0L)
            return
        }
        val min = (old.coveredUpTo / 60000).toInt()
        val msg = "بخشی از این زیرنویس تا حدود دقیقه $min فیلم قبلاً ساخته شده است. می‌خواهید ادامه همان تبدیل قبلی انجام شود یا از صفر شروع شود؟"
        AlertDialog.Builder(this)
            .setTitle("ادامه تبدیل زیرنویس")
            .setMessage(msg)
            .setPositiveButton("ادامه از همان‌جا") { _, _ -> go(old, old.coveredUpTo) }
            .setNegativeButton("شروع از صفر") { _, _ ->
                old.discard()
                go(LiveSubs(f, m), 0L)
            }
            .setOnCancelListener { onCancel() }
            .show()
    }

    private fun beginLive(store: LiveSubs) {
        live = store
        converting = true
        // with a long lead the film starts by itself once that much subtitle is ready
        waitingForSubs = Prefs.leadSeconds(this) > 15
        // the first progress message comes about 15 seconds later, after the "converting" message
        lastWaitSpeak = System.currentTimeMillis() - 45000
        liveKey = -1L
        recentLive = ""
        uiHandler.removeCallbacks(liveTick)
        uiHandler.post(liveTick)
    }

    /** Ends the live reading (after a finish, a failure or a stop) and keeps the unfinished copy on disk. */
    private fun stopLive() {
        converting = false
        waitingForSubs = false
        uiHandler.removeCallbacks(liveTick)
        live?.save()
    }

    private fun norm(t: String) = t.replace(Regex("\\s+"), " ").trim()

    /** Runs every quarter second while converting: speaks the line that belongs to the film position and waits when the subtitle is behind. */
    private fun liveStep() {
        val l = live ?: return
        val off = Prefs.syncOffset(this)
        val pos = player.currentPosition - off
        val behind = !l.complete && pos + 300 >= l.coveredUpTo
        val lead = Prefs.leadSeconds(this) * 1000L
        if (player.playWhenReady && behind && player.playbackState != Player.STATE_ENDED) {
            player.playWhenReady = false
            waitingForSubs = true
            updatePlayIcon()
            val now = System.currentTimeMillis()
            if (now - lastWaitSpeak > 60000) {
                lastWaitSpeak = now
                speak("پخش متوقف شد تا زیرنویس ساخته شود")
            }
        } else if (waitingForSubs && (l.complete || l.coveredUpTo >= pos + lead)) {
            waitingForSubs = false
            player.playWhenReady = true
            updatePlayIcon()
        } else if (waitingForSubs && lead > 15000L) {
            val now = System.currentTimeMillis()
            if (now - lastWaitSpeak > 60000) {
                lastWaitSpeak = now
                speak("زیرنویس تا دقیقه ${l.coveredUpTo / 60000} ساخته شده است. پخش وقتی شروع می‌شود که زیرنویس تا دقیقه ${(pos + lead) / 60000} آماده باشد")
            }
        }
        if (player.isPlaying) {
            val c = l.at(pos)
            if (c == null) {
                liveKey = -1L
            } else if (c.start != liveKey) {
                liveKey = c.start
                recentLive = norm(c.text)
                speak(c.text)
            }
        }
    }

    private fun conversionDone(cache: File, store: LiveSubs, srt: String) {
        val playAfter = player.playWhenReady || waitingForSubs
        val pos = player.currentPosition
        cache.writeText(srt)
        stopLive()
        store.discard()
        live = null
        convertedFile = cache
        speak("تبدیل زیرنویس تمام شد. برای ذخیره فایل SRT از منوی زیرنویس استفاده کنید")
        refreshAndLoad(pos, playAfter, true)
    }

    /** idx/sub image subtitle: converted on a background thread; the film can be played meanwhile. */
    private fun startVobConversion(r: SubtitleImport.Result.Vob) {
        if (r.existing) {
            AlertDialog.Builder(this)
                .setTitle("زیرنویسِ ساخته‌شده‌ی قبلی")
                .setMessage("برای این زیرنویس قبلاً با موتور تشخیص متنِ دیگری فایل متنی ساخته شده است. از همان زیرنویس استفاده شود یا با موتور فعلی از اول ساخته شود؟")
                .setPositiveButton("استفاده از زیرنویس قبلی") { _, _ ->
                    applyImport(SubtitleImport.Result.Srt(r.out, r.key))
                }
                .setNegativeButton("ساخت از اول با موتور فعلی") { _, _ -> proceedVob(r) }
                .show()
            return
        }
        proceedVob(r)
    }

    private fun proceedVob(r: SubtitleImport.Result.Vob) {
        if (!ocr.hasData()) { speak("فایل زبان OCR اضافه نشده است"); return }
        player.playWhenReady = false
        askResume("vob_" + r.key, { speak("تبدیل انجام نشد") }) { store, covered ->
            val my = ++vobToken
            beginLive(store)
            speak(if (covered > 0) "ادامه تبدیل زیرنویس. می‌توانید فیلم را پخش کنید؛ پخش تا جایی که زیرنویس ساخته شده پیش می‌رود"
                  else "زیرنویس تصویری idx و sub پیدا شد. در حال تبدیل به متن. می‌توانید همین حالا فیلم را پخش کنید؛ پخش تا جایی که زیرنویس ساخته شده پیش می‌رود")
            thread(name = "vob-convert") {
                val srt = try {
                    VobSub.convert(r.idxText, r.sub, ocr, store, covered,
                        { p -> runOnUiThread { if (vobToken == my && !player.isPlaying) speak("$p درصد") } },
                        { vobToken == my })
                } catch (e: Exception) {
                    null
                }
                runOnUiThread {
                    if (vobToken != my) {
                        store.save()
                    } else if (srt == null) {
                        val wasWaiting = waitingForSubs
                        stopLive()
                        speak("تبدیل زیرنویس ناموفق بود")
                        if (wasWaiting) player.playWhenReady = true
                    } else {
                        vobDone(r, store, srt)
                    }
                }
            }
        }
    }

    private fun vobDone(r: SubtitleImport.Result.Vob, store: LiveSubs, srt: String) {
        val playAfter = player.playWhenReady || waitingForSubs
        val pos = player.currentPosition
        r.out.writeText(srt)
        try { File(r.out.path.removeSuffix(".srt") + ".eng").writeText(Prefs.ocrEngine(this)) } catch (ignored: Exception) {}
        stopLive()
        store.discard()
        live = null
        extSrt = r.out; extNative = null; extKey = r.key
        if (videoUri == null) {
            speak("تبدیل زیرنویس تمام شد. حالا فیلم را انتخاب کنید")
        } else {
            speak("تبدیل زیرنویس تمام شد. برای ذخیره فایل SRT از منوی زیرنویس استفاده کنید")
            refreshAndLoad(pos, playAfter, true)
        }
    }

    private fun canSaveSrt(): Boolean {
        val l = live
        return (converting && l != null && l.count() > 0) || convertedFile != null || extSrt != null
    }

    private fun saveSrtFile() {
        if (!canSaveSrt()) { speak("زیرنویسی برای ذخیره وجود ندارد"); return }
        val v = videoUri
        var base = if (v != null) displayName(v) else "subtitle"
        val dot = base.lastIndexOf('.')
        if (dot > 0) base = base.substring(0, dot)
        saveSrt.launch("$base.srt")
    }

    private fun currentCues(): List<SubtitleFormats.Cue>? {
        val l = live
        if (converting && l != null && l.count() > 0) return l.snapshot()
        val f = convertedFile ?: extSrt ?: return null
        return SubtitleFormats.parseAny(SubtitleFormats.decode(f.readBytes()))
    }

    private fun writeSrt(uri: Uri) {
        try {
            val cues = currentCues()
            if (cues == null) { speak("زیرنویسی برای ذخیره وجود ندارد"); return }
            val off = Prefs.syncOffset(this)
            val out = if (off == 0L) cues else cues.map {
                SubtitleFormats.Cue(maxOf(0L, it.start + off), maxOf(0L, it.end + off), it.text)
            }
            val text = SubtitleFormats.toSrt(out)
            contentResolver.openOutputStream(uri)?.use { s ->
                s.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                s.write(text.toByteArray(Charsets.UTF_8))
            } ?: throw java.io.IOException("no stream")
            speak("فایل زیرنویس ذخیره شد")
        } catch (e: Exception) {
            speak("ذخیره فایل ناموفق بود")
        }
    }

    private fun handleSubtitleFiles(uris: List<Uri>) {
        resetConversion()
        speak("در حال بررسی فایل زیرنویس")
        thread(name = "subtitle-import") {
            val res = try {
                SubtitleImport.prepare(this, ocr, uris, { m -> runOnUiThread { speak(m) } })
            } catch (e: Exception) {
                SubtitleImport.Result.Fail("فایل زیرنویس باز نشد")
            }
            runOnUiThread { applyImport(res) }
        }
    }

    private fun applyImport(res: SubtitleImport.Result) {
        when (res) {
            is SubtitleImport.Result.Srt -> { extSrt = res.file; extNative = null; extKey = res.key; subPicked.clear() }
            is SubtitleImport.Result.Native -> { extNative = res; extSrt = null; extKey = res.uri.toString(); subPicked.clear() }
            is SubtitleImport.Result.Vob -> {
                extSrt = null; extNative = null; extKey = ""
                subPicked.clear()
                Prefs.setSyncOffset(this, 0L)
                startVobConversion(res)
                return
            }
            is SubtitleImport.Result.NeedOther -> { speak(res.message); pickSub.launch(arrayOf("*/*")); return }
            is SubtitleImport.Result.Fail -> { speak(res.message); subPicked.clear(); return }
        }
        Prefs.setSyncOffset(this, 0L)
        if (videoUri == null) speak("زیرنویس آماده است. حالا فیلم را انتخاب کنید") else refreshAndLoad()
    }

    private fun cancelConversion() {
        if (!converting) return
        val hard = hardConverter != null
        converter?.cancel(); converter = null
        hardConverter?.cancel(); hardConverter = null
        val wasWaiting = waitingForSubs
        stopLive()
        speak(if (hard) "ساخت زیرنویس متوقف شد. بعداً می‌توانید از همان‌جا ادامه دهید"
              else "تبدیل متوقف شد. بعداً می‌توانید از همان‌جا ادامه دهید. زیرنویس به صورت زنده خوانده می‌شود")
        if (wasWaiting) player.playWhenReady = true
    }

    private fun handleCues(cueGroup: CueGroup) {
        if (converting) return
        val cues = cueGroup.cues
        val text = cues.joinToString(" ") { it.text?.toString() ?: "" }.trim()
        if (text.isNotEmpty()) {
            lastKey = 0
            if (text != lastText) {
                lastText = text
                if (recentLive.isEmpty() || norm(text) != recentLive) speak(text)
                recentLive = ""
            }
            return
        }
        val bitmaps = cues.mapNotNull { it.bitmap }
        if (bitmaps.isEmpty()) { lastText = ""; lastKey = 0; return }
        // Image subtitle shown live (fallback): read it with OCR.
        val key = bitmaps.fold(1) { a, b -> 31 * a + System.identityHashCode(b) }
        if (key == lastKey) return
        lastKey = key
        bitmaps.forEach { bmp ->
            ocr.recognize(bmp,
                onText = { t -> runOnUiThread { speak(t) } },
                onNoData = { runOnUiThread {
                    if (!noDataShown) {
                        noDataShown = true
                        speak("فایل زبان OCR اضافه نشده است")
                    }
                } },
                online = liveDrive())
        }
    }

    /** Live reading goes through Google Drive only when the Drive engine and its live option are both on. */
    private fun liveDrive(): Boolean = Prefs.ocrEngine(this) == "drive" && Prefs.driveLive(this)

    private fun chooseEmbedded() {
        val groups = player.currentTracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
        if (groups.isEmpty()) {
            Toast.makeText(this, "زیرنویسی در فیلم پیدا نشد", Toast.LENGTH_SHORT).show(); return
        }
        val labels = groups.mapIndexed { i, g -> "${i + 1}. " + describe(g) }
        AlertDialog.Builder(this)
            .setTitle("زیرنویس داخل فیلم")
            .setItems(labels.toTypedArray()) { _, which ->
                val g = groups[which]
                if (!g.isSupported) {
                    speak("این نوع زیرنویس پشتیبانی نمی‌شود")
                } else if (isImage(g.getTrackFormat(0).sampleMimeType)) {
                    converter?.cancel(); converter = null
                    hardConverter?.cancel(); hardConverter = null
                    stopLive()
                    select(g)
                    startConversion(which)
                } else {
                    select(g)
                    speak("زیرنویس " + describe(g) + " فعال شد")
                }
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            if (ttsEngine != null && !ttsRetried) {
                ttsRetried = true
                Prefs.setEngine(this, null)
                Toast.makeText(this, "موتور انتخاب‌شده اجرا نشد. موتور پیش‌فرض گوشی استفاده می‌شود", Toast.LENGTH_LONG).show()
                t.shutdown()
                startTts()
            } else {
                Toast.makeText(this, "موتور گفتار اجرا نشد", Toast.LENGTH_LONG).show()
            }
            return
        }
        TtsUtil.usePersian(t)
        t.setSpeechRate(speechRate)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(u: String?) = runOnUiThread { player.volume = movieVolume * 0.3f }
            override fun onDone(u: String?) = finished()
            @Deprecated("") override fun onError(u: String?) = finished()
            fun finished() { if (pending.decrementAndGet() <= 0) { pending.set(0); runOnUiThread { player.volume = movieVolume } } }
        })
    }

    private fun speak(text: String) {
        val t = tts ?: return
        // If speech falls far behind, drop the backlog so it stays in sync.
        val mode = if (pending.get() > 3) { pending.set(0); TextToSpeech.QUEUE_FLUSH } else TextToSpeech.QUEUE_ADD
        pending.incrementAndGet()
        val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, speechVolume) }
        t.speak(text, mode, params, "s${id++}")
    }

    override fun onDestroy() {
        uiHandler.removeCallbacksAndMessages(null)
        mediaSession?.release()
        live?.save()
        hardConverter?.cancel()
        converter?.cancel()
        player.release(); tts?.shutdown(); ocr.release(); super.onDestroy()
    }
}
