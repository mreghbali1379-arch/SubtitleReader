package com.example.subtitlereader

import android.content.Context
import java.io.File

/** Shifts the timing of an SRT file so it matches the film. */
object SubtitleSync {

    private fun readCues(file: File): List<SubtitleFormats.Cue>? =
        SubtitleFormats.parseAny(SubtitleFormats.decode(file.readBytes()))

    /** Writes a copy with every time moved by [offsetMs] and returns it; returns [base] if nothing changes. */
    fun apply(ctx: Context, base: File, offsetMs: Long): File {
        if (offsetMs == 0L) return base
        val cues = readCues(base) ?: return base
        val moved = cues.map { c ->
            SubtitleFormats.Cue(maxOf(0L, c.start + offsetMs), maxOf(0L, c.end + offsetMs), c.text)
        }
        val dir = File(ctx.filesDir, "synced").apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        val out = File(dir, "sync_" + System.currentTimeMillis() + ".srt")
        out.writeText(SubtitleFormats.toSrt(moved))
        return out
    }
}
