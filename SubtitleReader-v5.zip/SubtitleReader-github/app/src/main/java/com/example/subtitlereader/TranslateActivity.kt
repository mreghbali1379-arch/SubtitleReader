package com.example.subtitlereader

import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat

/** A separate section: pick a subtitle file, translate all of it, save the result as an SRT file. */
class TranslateActivity : AppCompatActivity() {

    private var cues: List<SubtitleFormats.Cue>? = null
    private var fileName = ""
    private var result: List<SubtitleFormats.Cue>? = null
    private var resultTarget = "fa"
    private var worker: SubtitleTranslator? = null
    private var running = false

    private val summaries = ArrayList<Pair<TextView, () -> String>>()
    private lateinit var box: LinearLayout
    private lateinit var statusView: TextView
    private lateinit var progress: ProgressBar
    private lateinit var startBtn: TextView
    private lateinit var saveBtn: TextView

    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) loadFile(u)
    }
    private val save = registerForActivityResult(ActivityResultContracts.CreateDocument("application/x-subrip")) { u ->
        if (u != null) writeResult(u)
    }

    companion object {
        const val EXTRA_FILE = "cue_file"
        const val EXTRA_NAME = "cue_name"
        const val EXTRA_VIDEO = "video_key"
    }

    /** The film this screen was opened from (player); a translation of its subtitle can be saved from the player. */
    private var videoKey: String? = null

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun tell(m: String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val title = TextView(this).apply {
            text = "ترجمه‌ی زیرنویس"
            setTextColor(Color.WHITE)
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }
        ViewCompat.setAccessibilityHeading(title, true)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.BAR)
            val p = dp(8)
            setPadding(p, p, p, p)
            addView(Ui.icon(this@TranslateActivity, R.drawable.ic_back, "بازگشت") { finish() })
            addView(title, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
        }

        row("فایل زیرنویس", { if (cues == null) "انتخاب نشده؛ برای انتخاب بزنید" else "$fileName (${cues!!.size} خط)" }) { pick.launch(arrayOf("*/*")) }
        row("زبان زیرنویس", { langLabel(Prefs.translateFrom(this)) }) { chooseFrom() }
        row("ترجمه به", { Langs.name(Prefs.targetLang(this)) }) { chooseTarget() }
        row("روش ترجمه", { modeLabel(Prefs.translateMode(this)) }) { chooseMode() }
        row("تنظیمات و مدل‌های ترجمه", { "کلید Gemini، دانلود مدل‌های آفلاین" }) {
            startActivity(android.content.Intent(this, SettingsActivity::class.java))
        }

        startBtn = button("شروع ترجمه", true) { start() }
        saveBtn = button("ذخیره‌ی زیرنویس ترجمه‌شده (SRT)", false) { saveResult() }
        saveBtn.visibility = View.GONE
        statusView = TextView(this).apply {
            setTextColor(Ui.TEXT2)
            textSize = 15f
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
            setPadding(dp(16), dp(8), dp(16), 0)
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        box.addView(statusView, LinearLayout.LayoutParams(-1, -2))
        box.addView(progress, LinearLayout.LayoutParams(-1, -2).apply { marginStart = dp(16); marginEnd = dp(16); topMargin = dp(8) })

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Ui.BG)
            addView(bar, LinearLayout.LayoutParams(-1, -2))
            addView(ScrollView(this@TranslateActivity).apply { addView(box) }, LinearLayout.LayoutParams(-1, 0, 1f))
        })
        refreshAll()
        videoKey = intent.getStringExtra(EXTRA_VIDEO)
        val given = intent.getStringExtra(EXTRA_FILE)
        if (given != null && savedInstanceState == null) loadLocal(java.io.File(given), intent.getStringExtra(EXTRA_NAME) ?: "subtitle.srt")
    }

    /** Subtitle handed over by the player (the one already loaded or built for the film). */
    private fun loadLocal(f: java.io.File, name: String) {
        say("در حال خواندن زیرنویس فیلم…")
        Thread {
            val parsed = try { SubtitleFormats.parseAny(SubtitleFormats.decode(f.readBytes())) } catch (e: Exception) { null }
            runOnUiThread {
                if (parsed == null || parsed.isEmpty()) {
                    say("زیرنویس فیلم خوانده نشد. یک فایل زیرنویس انتخاب کنید")
                } else {
                    cues = parsed.sortedBy { it.start }
                    fileName = name
                    result = null
                    saveBtn.visibility = View.GONE
                    say("زیرنویس فیلم آماده است: ${parsed.size} خط. حالا «شروع ترجمه» را بزنید")
                }
                refreshAll()
            }
        }.start()
    }

    override fun onResume() {
        super.onResume()
        refreshAll()
    }

    override fun onDestroy() {
        worker?.cancel()
        super.onDestroy()
    }

    // ---------- rows ----------

    private fun row(titleText: String, summary: () -> String, action: () -> Unit) {
        val tvT = TextView(this).apply { text = titleText; setTextColor(Color.WHITE); textSize = 17f }
        val tvS = TextView(this).apply { setTextColor(Ui.TEXT2); textSize = 14f }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            isFocusable = true
            Ui.ripple(this@TranslateActivity, this, false)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            addView(tvT)
            addView(tvS)
            setOnClickListener { if (!running) action() else tell("ترجمه در حال انجام است") }
        }
        summaries.add(Pair(tvS, summary))
        box.addView(col, LinearLayout.LayoutParams(-1, -2))
    }

    private fun button(text: String, primary: Boolean, onClick: () -> Unit): TextView {
        val b = TextView(this).apply {
            this.text = text
            contentDescription = text
            setTextColor(Color.WHITE)
            textSize = 17f
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            setPadding(dp(24), dp(14), dp(24), dp(14))
            background = GradientDrawable().apply {
                setColor(if (primary) Ui.ACCENT else Ui.BAR)
                cornerRadius = dp(28).toFloat()
            }
            setOnClickListener { onClick() }
        }
        box.addView(b, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16); marginStart = dp(16); marginEnd = dp(16) })
        return b
    }

    private fun refreshAll() {
        for (p in summaries) p.first.text = p.second()
    }

    private fun langLabel(code: String) = if (code == "auto") "تشخیص خودکار (فقط با روش آنلاین و Gemini)" else Langs.name(code)

    private fun modeLabel(m: String) = when (m) {
        "online" -> "آنلاین گوگل (اگر خطا داد، آفلاین)"
        "gemini" -> "Gemini با کلید شما (اگر خطا داد، آفلاین)"
        else -> "آفلاین (روی گوشی)"
    }

    private fun choose(titleText: String, labels: List<String>, current: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(titleText)
            .setSingleChoiceItems(labels.toTypedArray(), current) { d, i -> d.dismiss(); onPick(i); refreshAll() }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun chooseFrom() {
        val codes = listOf("auto") + Langs.list.map { it.first }
        val labels = listOf("تشخیص خودکار") + Langs.list.map { it.second }
        choose("زبان زیرنویس", labels, codes.indexOf(Prefs.translateFrom(this)).coerceAtLeast(0)) { Prefs.setTranslateFrom(this, codes[it]) }
    }

    private fun chooseTarget() {
        val l = Langs.list.filter { Translator.supported(it.first) }
        choose("ترجمه به کدام زبان؟", l.map { it.second }, l.indexOfFirst { it.first == Prefs.targetLang(this) }.coerceAtLeast(0)) {
            Prefs.setTargetLang(this, l[it].first)
        }
    }

    private fun chooseMode() {
        val modes = listOf("offline", "online", "gemini")
        val labels = listOf(
            "آفلاین: روی گوشی و بدون اینترنت؛ کیفیت ساده‌تر. مدل‌ها باید دانلود شده باشند",
            "آنلاین گوگل: بدون کلید؛ متن زیرنویس به سرور گوگل فرستاده می‌شود. اگر خطا داد آفلاین می‌شود",
            "Gemini: بهترین کیفیت؛ نیاز به کلید API خودتان. متن زیرنویس به گوگل فرستاده می‌شود. اگر خطا داد آفلاین می‌شود"
        )
        choose("روش ترجمه", labels, modes.indexOf(Prefs.translateMode(this)).coerceAtLeast(0)) {
            Prefs.setTranslateMode(this, modes[it])
            if (modes[it] == "gemini" && Prefs.geminiKey(this).isBlank()) tell("کلید Gemini را در تنظیمات، بخش «ترجمه‌ی زیرنویس» وارد کنید")
        }
    }

    // ---------- work ----------

    private fun say(m: String) { statusView.text = m }

    private fun loadFile(u: Uri) {
        try { contentResolver.takePersistableUriPermission(u, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (ignored: Exception) {}
        val name = SpeechStore.displayName(this, u)
        say("در حال خواندن فایل…")
        Thread {
            val parsed = try {
                val bytes = contentResolver.openInputStream(u)?.use { it.readBytes() }
                if (bytes == null) null else SubtitleFormats.parseAny(SubtitleFormats.decode(bytes))
            } catch (e: Exception) { null }
            runOnUiThread {
                if (parsed == null || parsed.isEmpty()) {
                    say("این فایل به عنوان زیرنویس خوانده نشد. فایل باید متنی باشد (مثل srt، vtt یا ass)")
                } else {
                    cues = parsed.sortedBy { it.start }
                    fileName = name
                    videoKey = null   // another file was picked, so it is no longer the film's own subtitle
                    result = null
                    saveBtn.visibility = View.GONE
                    say("فایل خوانده شد: ${parsed.size} خط. حالا «شروع ترجمه» را بزنید")
                }
                refreshAll()
            }
        }.start()
    }

    private fun start() {
        if (running) return
        val c = cues
        if (c == null) { say("اول یک فایل زیرنویس انتخاب کنید"); return }
        val from = Prefs.translateFrom(this)
        val to = Prefs.targetLang(this)
        val mode = Prefs.translateMode(this)
        if (from == to) { say("زبان زیرنویس و زبان ترجمه یکی است"); return }
        if (mode == "offline" && from == "auto") { say("برای ترجمه‌ی آفلاین زبان زیرنویس را انتخاب کنید"); return }
        if (mode == "gemini" && Prefs.geminiKey(this).isBlank()) { say("کلید Gemini وارد نشده است. از «تنظیمات و مدل‌های ترجمه» وارد کنید"); return }
        val w = SubtitleTranslator(this, c, from, to, mode)
        worker = w
        running = true
        result = null
        saveBtn.visibility = View.GONE
        startBtn.text = "توقف ترجمه"
        startBtn.setOnClickListener { w.cancel(); say("در حال توقف…") }
        progress.visibility = View.VISIBLE
        progress.progress = 0
        say("در حال ترجمه…")
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        var lastPct = -10
        Thread {
            val out = w.run { pct, msg ->
                runOnUiThread {
                    progress.progress = pct
                    if (msg.isNotEmpty()) say(msg)
                    else if (pct >= lastPct + 10) { lastPct = pct; say("$pct درصد ترجمه شد") }
                }
            }
            runOnUiThread {
                running = false
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                startBtn.text = "شروع ترجمه"
                startBtn.setOnClickListener { start() }
                progress.visibility = View.GONE
                if (out != null) {
                    result = out
                    resultTarget = to
                    TranslatedStore.set(out, to, videoKey)
                    saveBtn.visibility = View.VISIBLE
                    say("ترجمه تمام شد." + (if (w.untranslated > 0) " ${w.untranslated} خط ترجمه نشد و به زبان اصلی ماند." else "") +
                        (if (videoKey != null) " برای ذخیره‌ی فایل، «ذخیره‌ی زیرنویس ترجمه‌شده» را همین‌جا بزنید، یا در پلیر از منوی زیرنویس، «ذخیره زیرنویس»"
                        else " برای ذخیره‌ی فایل، «ذخیره‌ی زیرنویس ترجمه‌شده» را بزنید"))
                } else {
                    say(w.error ?: "ترجمه متوقف شد")
                }
            }
        }.start()
    }

    private fun saveResult() {
        if (result == null) { say("ترجمه‌ای برای ذخیره نیست"); return }
        save.launch(fileName.substringBeforeLast('.') + ".$resultTarget.srt")
    }

    private fun writeResult(u: Uri) {
        val r = result ?: return
        try {
            contentResolver.openOutputStream(u)?.use { s ->
                s.write(byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte()))
                s.write(SubtitleFormats.toSrt(r).toByteArray(Charsets.UTF_8))
            } ?: throw java.io.IOException("no stream")
            say("فایل زیرنویس ذخیره شد")
        } catch (e: Exception) {
            say("ذخیره‌ی فایل ناموفق بود")
        }
    }
}
