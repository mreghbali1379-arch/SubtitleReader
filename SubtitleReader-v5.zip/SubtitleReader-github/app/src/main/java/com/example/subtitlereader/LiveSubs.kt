package com.example.subtitlereader

import java.io.File

/**
 * Subtitle lines built so far by a converter. The player reads from it while the conversion is still
 * running, and it is saved to disk now and then so an unfinished conversion can be continued later.
 */
class LiveSubs(private val partial: File?, private val meta: File?) {

    private val items = ArrayList<SubtitleFormats.Cue>()
    private var lastSave = 0L

    /** Everything before this time (ms, film time) is final. */
    @Volatile var coveredUpTo = 0L
        private set

    /** True once the converter reached the end of the film. */
    @Volatile var complete = false
        private set

    @Synchronized fun count(): Int = items.size

    @Synchronized fun snapshot(): List<SubtitleFormats.Cue> = ArrayList(items)

    /** Adds one finished line. A line that does not start after the previous one (seen again after a restart) is ignored. */
    @Synchronized fun add(start: Long, end: Long, text: String) {
        val last = items.lastOrNull()
        if (last != null && start <= last.start) return
        val e = if (end <= start) start + 2000 else end
        items.add(SubtitleFormats.Cue(start, e, text))
        saveThrottled()
    }

    fun covered(t: Long) {
        if (t > coveredUpTo) coveredUpTo = t
    }

    fun finish() {
        complete = true
        coveredUpTo = Long.MAX_VALUE
    }

    /** The line shown at film time [pos], or null. */
    @Synchronized fun at(pos: Long): SubtitleFormats.Cue? {
        var i = items.size - 1
        while (i >= 0) {
            val c = items[i]
            if (c.start <= pos) return if (pos < c.end) c else null
            i--
        }
        return null
    }

    @Synchronized fun toSrt(): String = SubtitleFormats.toSrt(items)

    private fun saveThrottled() {
        val now = System.currentTimeMillis()
        if (now - lastSave >= 5000) save()
    }

    /** Writes the lines and the covered time to disk (does nothing when this store has no files). */
    @Synchronized fun save() {
        lastSave = System.currentTimeMillis()
        val p = partial ?: return
        val m = meta ?: return
        try {
            if (coveredUpTo == Long.MAX_VALUE) return
            p.writeText(SubtitleFormats.toSrt(items))
            m.writeText(coveredUpTo.toString())
        } catch (ignored: Exception) {
        }
    }

    /** Removes the unfinished copy from disk (after a finished conversion or when starting over). */
    fun discard() {
        try { partial?.delete() } catch (ignored: Exception) {}
        try { meta?.delete() } catch (ignored: Exception) {}
    }

    companion object {
        /** Loads an unfinished conversion, or null if there is none worth continuing. */
        fun load(partial: File, meta: File): LiveSubs? {
            return try {
                if (!partial.exists() || !meta.exists()) return null
                val covered = meta.readText().trim().toLongOrNull() ?: return null
                if (covered <= 0) return null
                val cues = SubtitleFormats.parseAny(SubtitleFormats.decode(partial.readBytes())) ?: ArrayList()
                val l = LiveSubs(partial, meta)
                // keep every line that started before the saved point; the rest is read again
                cues.filter { it.start < covered }.forEach { l.items.add(it) }
                l.coveredUpTo = covered
                l
            } catch (e: Exception) {
                null
            }
        }
    }
}
