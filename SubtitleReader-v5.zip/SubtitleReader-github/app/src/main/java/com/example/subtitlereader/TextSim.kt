package com.example.subtitlereader

import kotlin.math.abs

/** Small text helpers for comparing and cleaning OCR results. */
object TextSim {
    private fun lev(a: String, b: String): Int {
        val prev = IntArray(b.length + 1) { it }
        val cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            }
            System.arraycopy(cur, 0, prev, 0, cur.size)
        }
        return prev[b.length]
    }

    /** True if two OCR results are (almost) the same line. */
    fun similar(a: String, b: String): Boolean {
        val x = a.replace(" ", "")
        val y = b.replace(" ", "")
        if (x.isEmpty() || y.isEmpty()) return false
        if (x == y) return true
        val m = maxOf(x.length, y.length)
        if (abs(x.length - y.length) > m / 3) return false
        return lev(x, y) <= m / 4
    }

    /** Collapses spaces and returns "" if the text looks like noise instead of a subtitle line. */
    fun clean(raw: String): String {
        val n = raw.replace(Regex("\\s+"), " ").trim()
        val nonSpace = n.count { !it.isWhitespace() }
        val letters = n.count { it.isLetter() }
        return if (nonSpace >= 3 && letters * 10 >= nonSpace * 6) n else ""
    }

    /** 1.0 for identical lines, down to 0.0 for completely different ones. */
    fun ratio(a: String, b: String): Double {
        val x = a.replace(" ", "")
        val y = b.replace(" ", "")
        val m = maxOf(x.length, y.length)
        if (m == 0) return 1.0
        return 1.0 - lev(x, y).toDouble() / m
    }

    /** Picks the reading that agrees most with the others, weighting each by its OCR confidence. */
    fun vote(c: List<Pair<String, Int>>): String {
        if (c.isEmpty()) return ""
        if (c.size == 1) return c[0].first
        var best = c[0].first
        var bestScore = -1.0
        for (i in c.indices) {
            var score = 0.0
            for (j in c.indices) score += ratio(c[i].first, c[j].first) * (c[j].second + 1)
            if (score > bestScore) { bestScore = score; best = c[i].first }
        }
        return best
    }
}
