package com.example.subtitlereader

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

/** Reads text subtitle formats (SRT, VTT, ASS/SSA, SAMI, MicroDVD, MPL2) and writes clean UTF-8 SRT. */
object SubtitleFormats {

    class Cue(val start: Long, val end: Long, val text: String)

    /** Detects UTF-8 / UTF-16 / Windows-1256 (Persian, Arabic) / Windows-1252 and decodes. */
    fun decode(b: ByteArray): String {
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte())
            return String(b, 3, b.size - 3, Charsets.UTF_8)
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        try {
            return Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(b)).toString()
        } catch (ignored: CharacterCodingException) {}
        var high = 0
        var letters = 0
        for (x in b) {
            val v = x.toInt() and 0xFF
            if (v >= 0x80) high++ else if (v in 65..90 || v in 97..122) letters++
        }
        val name = if (high * 10 > (high + letters) * 3) "windows-1256" else "windows-1252"
        return String(b, Charset.forName(name))
    }

    fun isTtml(t: String) = Regex("<tt[\\s>]").containsMatchIn(t) || t.contains("ttml", true)

    fun parseAny(text: String): List<Cue>? {
        val t = text.trimStart('\uFEFF')
        val list = try {
            when {
                t.contains("<sync", true) -> parseSami(t)
                t.contains("[Events]", true) -> parseAss(t)
                Regex("^\\{\\d+\\}\\{\\d+\\}", RegexOption.MULTILINE).containsMatchIn(t) -> parseMicroDvd(t)
                Regex("^\\[\\d+\\]\\[\\d+\\]", RegexOption.MULTILINE).containsMatchIn(t) -> parseMpl2(t)
                t.contains("-->") -> parseSrtVtt(t)
                else -> null
            }
        } catch (ignored: Exception) { null }
        return if (list.isNullOrEmpty()) null else list
    }

    fun toSrt(cues: List<Cue>): String {
        val sorted = cues.sortedBy { it.start }
        val sb = StringBuilder()
        for ((i, c) in sorted.withIndex()) {
            var end = if (c.end <= c.start) c.start + 2000 else c.end
            val next = sorted.getOrNull(i + 1)
            if (next != null && end > next.start && next.start > c.start) end = next.start
            sb.append(i + 1).append('\n')
                .append(ts(c.start)).append(" --> ").append(ts(end)).append('\n')
                .append(c.text).append("\n\n")
        }
        return sb.toString()
    }

    private fun ts(ms: Long): String = String.format(
        java.util.Locale.US, "%02d:%02d:%02d,%03d", ms / 3600000, ms / 60000 % 60, ms / 1000 % 60, ms % 1000)

    // ---------- helpers ----------

    private val tagRe = Regex("<[^>]*>")
    private val braceRe = Regex("\\{[^}]*\\}")
    private val spaceRe = Regex("\\s+")

    private fun clean(s: String): String = s
        .replace(tagRe, " ").replace(braceRe, " ")
        .replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">")
        .replace("&quot;", "\"").replace("&amp;", "&")
        .replace(spaceRe, " ").trim()

    private fun frac(f: String): Long = (f + "00").take(3).toLong()

    // ---------- SRT / VTT ----------

    private val timeRe = Regex(
        "(?:(\\d{1,2}):)?(\\d{1,2}):(\\d{2})[.,](\\d{1,3})\\s*-->\\s*(?:(\\d{1,2}):)?(\\d{1,2}):(\\d{2})[.,](\\d{1,3})")

    private fun parseSrtVtt(t: String): List<Cue> {
        val lines = t.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val out = ArrayList<Cue>()
        var i = 0
        while (i < lines.size) {
            val m = timeRe.find(lines[i])
            if (m == null) { i++; continue }
            val g = m.groupValues
            val start = (g[1].toLongOrNull() ?: 0) * 3600000 + g[2].toLong() * 60000 + g[3].toLong() * 1000 + frac(g[4])
            val end = (g[5].toLongOrNull() ?: 0) * 3600000 + g[6].toLong() * 60000 + g[7].toLong() * 1000 + frac(g[8])
            val sb = StringBuilder()
            i++
            while (i < lines.size && lines[i].isNotBlank()) { sb.append(' ').append(lines[i]); i++ }
            val text = clean(sb.toString())
            if (text.isNotEmpty()) out.add(Cue(start, end, text))
        }
        return out
    }

    // ---------- ASS / SSA ----------

    private fun assTime(t: String): Long {
        val p = t.trim().split(':')
        if (p.size != 3) return 0
        val sec = p[2].split('.')
        return p[0].toLong() * 3600000 + p[1].toLong() * 60000 + sec[0].toLong() * 1000 +
            frac(sec.getOrNull(1) ?: "0")
    }

    private fun parseAss(t: String): List<Cue> {
        var inEvents = false
        var fmt: List<String>? = null
        val out = ArrayList<Cue>()
        for (raw in t.replace("\r\n", "\n").replace('\r', '\n').split('\n')) {
            val line = raw.trim()
            if (line.startsWith("[")) { inEvents = line.equals("[Events]", true); continue }
            if (!inEvents) continue
            if (line.startsWith("Format:", true)) {
                fmt = line.substringAfter(':').split(',').map { it.trim().lowercase() }
            } else if (line.startsWith("Dialogue:", true) && fmt != null) {
                val parts = line.substringAfter(':').trimStart().split(",", limit = fmt.size)
                val si = fmt.indexOf("start"); val ei = fmt.indexOf("end"); val ti = fmt.indexOf("text")
                if (si < 0 || ei < 0 || ti < 0 || parts.size <= ti) continue
                val text = clean(parts[ti].replace("\\N", " ").replace("\\n", " ").replace("\\h", " "))
                if (text.isNotEmpty()) out.add(Cue(assTime(parts[si]), assTime(parts[ei]), text))
            }
        }
        return out
    }

    // ---------- SAMI (.smi) ----------

    private fun parseSami(t: String): List<Cue> {
        val re = Regex("<sync\\s+start\\s*=\\s*[\"']?(\\d+)[\"']?[^>]*>", RegexOption.IGNORE_CASE)
        val ms = re.findAll(t).toList()
        val out = ArrayList<Cue>()
        for ((k, m) in ms.withIndex()) {
            val start = m.groupValues[1].toLong()
            val nextM = ms.getOrNull(k + 1)
            val raw = t.substring(m.range.last + 1, nextM?.range?.first ?: t.length)
            val text = clean(raw.replace(Regex("<br\\s*/?>", RegexOption.IGNORE_CASE), " "))
            if (text.isNotEmpty()) out.add(Cue(start, nextM?.groupValues?.get(1)?.toLong() ?: (start + 3000), text))
        }
        return out
    }

    // ---------- MicroDVD (.sub text) and MPL2 ----------

    private fun parseMicroDvd(t: String): List<Cue> {
        val re = Regex("^\\{(\\d+)\\}\\{(\\d+)\\}(.*)$")
        var fps = 23.976
        val out = ArrayList<Cue>()
        for (raw in t.replace("\r\n", "\n").replace('\r', '\n').split('\n')) {
            val m = re.find(raw.trim()) ?: continue
            val s = m.groupValues[1].toLong(); val e = m.groupValues[2].toLong()
            val body = m.groupValues[3]
            if (s == 1L && e == 1L) {
                val f = body.trim().toDoubleOrNull()
                if (f != null) { if (f > 1) fps = f; continue }
            }
            val text = clean(body.replace('|', ' '))
            if (text.isNotEmpty()) out.add(Cue((s * 1000 / fps).toLong(), (e * 1000 / fps).toLong(), text))
        }
        return out
    }

    private fun parseMpl2(t: String): List<Cue> {
        val re = Regex("^\\[(\\d+)\\]\\[(\\d+)\\](.*)$")
        val out = ArrayList<Cue>()
        for (raw in t.replace("\r\n", "\n").replace('\r', '\n').split('\n')) {
            val m = re.find(raw.trim()) ?: continue
            val text = clean(m.groupValues[3].replace('|', ' ').trimStart('/'))
            if (text.isNotEmpty()) out.add(Cue(m.groupValues[1].toLong() * 100, m.groupValues[2].toLong() * 100, text))
        }
        return out
    }
}
