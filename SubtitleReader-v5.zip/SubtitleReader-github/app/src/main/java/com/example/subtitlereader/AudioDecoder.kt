package com.example.subtitlereader

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder

/** Reads the sound of a film and hands it over as 16 kHz mono samples, piece by piece (never the whole film at once). */
class AudioDecoder(private val context: Context, private val uri: Uri) {

    class TrackInfo(val index: Int, val label: String)

    companion object {
        const val RATE = 16000

        /** The audio tracks of the film and the film length in ms (0 if unknown). */
        fun listTracks(context: Context, uri: Uri): Pair<List<TrackInfo>, Long> {
            val ex = MediaExtractor()
            try {
                ex.setDataSource(context, uri, null)
                val out = ArrayList<TrackInfo>()
                var dur = 0L
                var n = 0
                for (i in 0 until ex.trackCount) {
                    val f = ex.getTrackFormat(i)
                    val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
                    if (f.containsKey(MediaFormat.KEY_DURATION)) dur = maxOf(dur, f.getLong(MediaFormat.KEY_DURATION) / 1000)
                    if (!mime.startsWith("audio/")) continue
                    n++
                    val lang = if (f.containsKey(MediaFormat.KEY_LANGUAGE)) f.getString(MediaFormat.KEY_LANGUAGE) else null
                    val ch = if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) f.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 0
                    val label = "صدای $n" +
                        (if (!lang.isNullOrBlank() && lang != "und") " ($lang)" else "") +
                        " - " + mime.removePrefix("audio/") +
                        (if (ch > 0) " - $ch کانال" else "")
                    out.add(TrackInfo(i, label))
                }
                return Pair(out, dur)
            } finally {
                try { ex.release() } catch (ignored: Exception) {}
            }
        }
    }

    /** Box-filter resampler to 16 kHz. Output is collected in [out] (first [n] values) and drained by the caller. */
    private class Resampler(inRate: Int) {
        private val ratio = inRate / RATE.toDouble()
        private var acc = 0.0
        private var w = 0.0
        var out = FloatArray(1 shl 16)
        var n = 0

        fun push(x: Float) {
            if (ratio == 1.0) { put(x); return }
            var left = 1.0
            while (left > 1e-9) {
                val take = minOf(left, ratio - w)
                acc += x * take
                w += take
                left -= take
                if (w >= ratio - 1e-9) {
                    put((acc / ratio).toFloat())
                    acc = 0.0
                    w = 0.0
                }
            }
        }

        private fun put(v: Float) {
            if (n == out.size) out = out.copyOf(n * 2)
            out[n++] = v
        }
    }

    /**
     * Decodes one audio track starting at [fromMs]. [onStart] receives the film time (ms) of the first sample that
     * [sink] gets. Returns null when it ran to the end (or [stop] became true), otherwise a message describing the failure.
     */
    fun decode(
        trackIndex: Int,
        fromMs: Long,
        stop: () -> Boolean,
        onStart: (Long) -> Unit,
        sink: (FloatArray, Int) -> Unit
    ): String? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(context, uri, null)
            ex.selectTrack(trackIndex)
            val fmt = ex.getTrackFormat(trackIndex)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return "نوع صدای فیلم مشخص نیست"
            if (fromMs > 1000) ex.seekTo((fromMs - 1000) * 1000, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            val dec: MediaCodec = try {
                MediaCodec.createDecoderByType(mime)
            } catch (e: Exception) {
                return "این گوشی صدای فیلم ($mime) را رمزگشایی نمی‌کند. اگر فیلم صدای دیگری دارد آن را انتخاب کنید"
            }
            codec = dec
            dec.configure(fmt, null, null, 0)
            dec.start()

            var rate = if (fmt.containsKey(MediaFormat.KEY_SAMPLE_RATE)) fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 48000
            var ch = if (fmt.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var isFloat = false
            var res = Resampler(rate)

            val info = MediaCodec.BufferInfo()
            val wantUs = fromMs * 1000
            var started = false
            var skipFrames = 0
            var inDone = false
            var outDone = false

            while (!outDone && !stop()) {
                if (!inDone) {
                    val ii = dec.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val buf = dec.getInputBuffer(ii)
                        val n = if (buf == null) -1 else ex.readSampleData(buf, 0)
                        if (n < 0) {
                            dec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            dec.queueInputBuffer(ii, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }

                val oi = dec.dequeueOutputBuffer(info, 10000)
                if (oi >= 0) {
                    val ob = dec.getOutputBuffer(oi)
                    if (ob != null && info.size > 0) {
                        ob.position(info.offset)
                        ob.limit(info.offset + info.size)
                        ob.order(ByteOrder.nativeOrder())
                        val bytesPerSample = if (isFloat) 4 else 2
                        val frames = info.size / (bytesPerSample * ch)
                        val pts = info.presentationTimeUs
                        var first = 0
                        var use = true
                        if (!started) {
                            val bufUs = frames * 1_000_000L / rate
                            if (pts + bufUs <= wantUs) {
                                use = false
                            } else {
                                started = true
                                if (pts < wantUs) skipFrames = ((wantUs - pts) * rate / 1_000_000L).toInt()
                                onStart(maxOf(pts, wantUs) / 1000)
                            }
                        }
                        if (use) {
                            if (skipFrames > 0) {
                                first = minOf(skipFrames, frames)
                                skipFrames -= first
                            }
                            if (isFloat) {
                                val fb = ob.asFloatBuffer()
                                for (f in first until frames) {
                                    var s = 0f
                                    for (c in 0 until ch) s += fb.get(f * ch + c)
                                    res.push(s / ch)
                                }
                            } else {
                                val sb = ob.asShortBuffer()
                                for (f in first until frames) {
                                    var s = 0f
                                    for (c in 0 until ch) s += sb.get(f * ch + c)
                                    res.push(s / ch / 32768f)
                                }
                            }
                            if (res.n > 0) {
                                sink(res.out, res.n)
                                res.n = 0
                            }
                        }
                    }
                    dec.releaseOutputBuffer(oi, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = dec.outputFormat
                    if (nf.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (nf.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    isFloat = nf.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                        nf.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    res = Resampler(rate)
                }
            }
            return null
        } catch (e: Exception) {
            return "خواندن صدای فیلم ناموفق بود: " + (e.message ?: e.javaClass.simpleName)
        } finally {
            try { codec?.stop() } catch (ignored: Exception) {}
            try { codec?.release() } catch (ignored: Exception) {}
            try { ex.release() } catch (ignored: Exception) {}
        }
    }
}
