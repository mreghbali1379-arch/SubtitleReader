package com.example.subtitlereader

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat

private const val HELP =
    "۱. روی «افزودن فایل» بزنید و یک فیلم انتخاب کنید. فیلم‌های اخیر در فهرست می‌مانند؛ برای برداشتن یکی از فهرست، روی آن لمس طولانی کنید.\n\n" +
    "۲. هنگام پخش: دکمه‌ی پخش و توقف، نوار پیشرفت، قفل کردن صفحه، تغییر اندازه‌ی تصویر و چرخاندن صفحه را دارید. دو بار لمس سمت چپ صفحه به عقب می‌رود، سمت راست به جلو (به اندازه‌ی «مدت پرش» در تنظیمات) و وسط صفحه پخش و توقف می‌کند.\n\n" +
    "۳. دکمه‌ی «زیرنویس» بالای صفحه: افزودن فایل زیرنویس، انتخاب زیرنویس داخل فیلم، تأخیر زیرنویس، ساخت فایل زیرنویس از روی تصویر، خواندن زنده‌ی زیرنویس چسبیده به تصویر و ذخیره‌ی زیرنویس به صورت SRT. زیرنویس‌ها با موتور گفتار گوشی خوانده می‌شوند.\n\n" +
    "۴. زیرنویس چسبیده به تصویر دو راه دارد: خواندن زنده هنگام پخش (ساده‌تر، ولی با کمی تأخیر و احتمال خطا)، یا «ساخت فایل زیرنویس از روی تصویر» (دقیق‌تر). هنگام ساخت، فیلم تا جایی که زیرنویس آماده شده پخش می‌شود و بعد از پایان، فایل ذخیره می‌شود و دفعه‌ی بعد بدون ساخت دوباره استفاده می‌شود.\n\n" +
    "۵. زیرنویس تصویری داخل فیلم و فایل‌های idx و sub هم با تشخیص متن به متن تبدیل و خوانده می‌شوند.\n\n" +
    "۶. در «تنظیمات»: صدای فیلم، مدت پرش، موتور و سرعت و صدای خواندن، ناحیه‌ی خواندن زیرنویس چسبیده به تصویر، فاصله‌ی نمونه‌برداری، مقدار زیرنویسِ آماده پیش از شروع پخش، و موتور و زبان و مدل تشخیص متن هست. فایل زبان تشخیص متن (فارسی و انگلیسی) همراه برنامه است و می‌توانید فایل دیگری هم اضافه کنید.\n\n" +
    "۷. اختیاری: «موتور تشخیص متن» را روی «آفلاین + گوگل‌درایو» بگذارید تا خواندن تصویرها دقیق‌تر شود. این حالت اینترنت و ورود با حساب گوگل می‌خواهد و ساخت زیرنویس را کندتر می‌کند.\n\n" +
    "۸. فیلمی که اصلاً زیرنویس ندارد: از منوی زیرنویس «ساخت زیرنویس از صدای فیلم (تشخیص گفتار)» را بزنید. صدای فیلم روی خود گوشی به متن تبدیل می‌شود. قبل از اولین بار در تنظیمات، بخش «ساخت زیرنویس از صدای فیلم»، یک مدل Whisper دانلود کنید. ساخت در پس‌زمینه ادامه دارد (با اعلان و دکمه‌ی توقف)، فیلم تا جایی که زیرنویس ساخته شده پخش می‌شود و بعد از پایان، زیرنویس برای دفعه‌ی بعد ذخیره می‌ماند. فایل SRT هم از منوی زیرنویس ذخیره می‌شود.\n\n" +
    "۹. ترجمه‌ی زیرنویس: از منوی صفحه‌ی اول «ترجمه‌ی زیرنویس» را باز کنید، یک فایل زیرنویس انتخاب کنید، زبان‌ها و روش ترجمه (آفلاین، آنلاین گوگل یا Gemini) را بگذارید و ترجمه را شروع کنید. نتیجه را به صورت فایل SRT ذخیره کنید. کلید Gemini و مدل‌های آفلاین در تنظیمات، بخش «ترجمه‌ی زیرنویس» است."

/** First screen: only "add file" at the start, plus the list of recently opened films. */
class HomeActivity : AppCompatActivity() {

    private lateinit var listBox: LinearLayout
    private lateinit var emptyBox: LinearLayout
    private lateinit var fab: TextView

    private val pick = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) play(u)
    }

    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val title = TextView(this).apply {
            text = "زیرنویس‌خوان"
            setTextColor(Color.WHITE)
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }
        ViewCompat.setAccessibilityHeading(title, true)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.BAR)
            val p = dp(8)
            setPadding(dp(16), p, p, p)
            addView(title, LinearLayout.LayoutParams(0, dp(48), 1f))
            addView(Ui.icon(this@HomeActivity, R.drawable.ic_more, "منو") { showMenu() })
        }

        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val emptyIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_video)
            setColorFilter(Ui.TEXT2)
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        }
        val emptyText = TextView(this).apply {
            text = "فیلمی اضافه نشده است"
            setTextColor(Ui.TEXT2)
            textSize = 16f
            gravity = Gravity.CENTER
        }
        emptyBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(emptyIcon, LinearLayout.LayoutParams(dp(96), dp(96)))
            addView(emptyText, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(12) })
        }

        fab = TextView(this).apply {
            text = "افزودن فایل"
            contentDescription = "افزودن فایل"
            setTextColor(Color.WHITE)
            textSize = 18f
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            val ph = dp(28)
            val pv = dp(16)
            setPadding(ph, pv, ph, pv)
            background = GradientDrawable().apply {
                setColor(Ui.ACCENT)
                cornerRadius = dp(32).toFloat()
            }
            setOnClickListener { pick.launch(arrayOf("*/*")) }
        }

        val content = FrameLayout(this).apply {
            addView(ScrollView(this@HomeActivity).apply { addView(listBox) }, FrameLayout.LayoutParams(-1, -1))
            addView(emptyBox, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER).apply { bottomMargin = dp(60) })
            addView(fab, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(32)
            })
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.BG)
            addView(bar, LinearLayout.LayoutParams(-1, -2))
            addView(content, LinearLayout.LayoutParams(-1, 0, 1f))
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        listBox.removeAllViews()
        val items = Prefs.recents(this)
        emptyBox.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        if (items.isEmpty()) return
        val head = TextView(this).apply {
            text = "اخیر"
            setTextColor(Ui.ACCENT)
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(16), dp(16), dp(16), dp(4))
        }
        ViewCompat.setAccessibilityHeading(head, true)
        listBox.addView(head)
        for (item in items) {
            val uri = item.first
            val name = item.second
            val icon = ImageView(this).apply {
                setImageResource(R.drawable.ic_video)
                setColorFilter(Ui.ACCENT)
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
            val label = TextView(this).apply {
                text = name
                setTextColor(Color.WHITE)
                textSize = 16f
                maxLines = 2
                textDirection = View.TEXT_DIRECTION_FIRST_STRONG
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true
                isFocusable = true
                Ui.ripple(this@HomeActivity, this, false)
                setPadding(dp(16), dp(12), dp(16), dp(12))
                contentDescription = name
                addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))
                addView(label, LinearLayout.LayoutParams(0, -2, 1f).apply {
                    marginStart = dp(16)
                    marginEnd = dp(8)
                })
                setOnClickListener { play(Uri.parse(uri)) }
                setOnLongClickListener {
                    Prefs.removeRecent(this@HomeActivity, uri)
                    Toast.makeText(this@HomeActivity, "از فهرست حذف شد", Toast.LENGTH_SHORT).show()
                    refresh()
                    true
                }
            }
            listBox.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
    }

    private fun showMenu() {
        val labels = arrayOf("ترجمه‌ی زیرنویس", "تنظیمات", "نحوه‌ی استفاده از برنامه", "درباره‌ی برنامه")
        AlertDialog.Builder(this)
            .setTitle("منو")
            .setItems(labels) { _, which ->
                when (which) {
                    0 -> startActivity(Intent(this, TranslateActivity::class.java))
                    1 -> startActivity(Intent(this, SettingsActivity::class.java))
                    2 -> showText("نحوه‌ی استفاده از برنامه", HELP)
                    else -> showText("درباره‌ی برنامه", about())
                }
            }
            .show()
    }

    private fun showText(title: String, text: String) {
        AlertDialog.Builder(this).setTitle(title).setMessage(text).setPositiveButton("بستن", null).show()
    }

    private fun about(): String {
        val v = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "" }
        return "زیرنویس‌خوان، پخش‌کننده‌ی فیلم است که زیرنویس را با صدا می‌خواند. " +
            "فایل زیرنویس، زیرنویس داخل فیلم، زیرنویس تصویری (idx و sub) و زیرنویس چسبیده به تصویر را پشتیبانی می‌کند. برای فیلم بدون زیرنویس هم می‌تواند از روی صدای فیلم زیرنویس بسازد (تشخیص گفتار Whisper).\n\n" +
            "گفتار و تشخیص متن (OCR) به صورت پیش‌فرض روی خود گوشی و بدون اینترنت انجام می‌شود. " +
            "گوگل‌درایو فقط در صورتی استفاده می‌شود که خودتان در تنظیمات، موتور تشخیص متن را روی «آفلاین + گوگل‌درایو» بگذارید.\n\n" +
            "نسخه: $v"
    }

    private fun play(u: Uri) {
        try {
            contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (ignored: Exception) {
        }
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            action = Intent.ACTION_VIEW
            setDataAndType(u, "video/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        })
    }
}
