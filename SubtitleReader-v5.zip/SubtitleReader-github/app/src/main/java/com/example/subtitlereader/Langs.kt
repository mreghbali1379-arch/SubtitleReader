package com.example.subtitlereader

/** Languages offered for the speech in the film and for translation (codes are the same for Whisper and ML Kit). */
object Langs {
    val list = listOf(
        "en" to "انگلیسی", "ar" to "عربی", "tr" to "ترکی", "de" to "آلمانی", "fr" to "فرانسوی",
        "es" to "اسپانیایی", "ru" to "روسی", "ko" to "کره‌ای", "ja" to "ژاپنی", "zh" to "چینی",
        "it" to "ایتالیایی", "hi" to "هندی", "ur" to "اردو", "pt" to "پرتغالی", "nl" to "هلندی",
        "pl" to "لهستانی", "uk" to "اوکراینی", "sv" to "سوئدی", "he" to "عبری", "th" to "تایلندی",
        "vi" to "ویتنامی", "id" to "اندونزیایی", "el" to "یونانی", "cs" to "چکی", "ro" to "رومانیایی",
        "fa" to "فارسی"
    )

    private val en = mapOf(
        "en" to "English", "ar" to "Arabic", "tr" to "Turkish", "de" to "German", "fr" to "French",
        "es" to "Spanish", "ru" to "Russian", "ko" to "Korean", "ja" to "Japanese", "zh" to "Chinese",
        "it" to "Italian", "hi" to "Hindi", "ur" to "Urdu", "pt" to "Portuguese", "nl" to "Dutch",
        "pl" to "Polish", "uk" to "Ukrainian", "sv" to "Swedish", "he" to "Hebrew", "th" to "Thai",
        "vi" to "Vietnamese", "id" to "Indonesian", "el" to "Greek", "cs" to "Czech", "ro" to "Romanian",
        "fa" to "Persian (Farsi)"
    )

    fun englishName(code: String): String = en[code] ?: code

    fun name(code: String): String = list.firstOrNull { it.first == code }?.second ?: code
}
