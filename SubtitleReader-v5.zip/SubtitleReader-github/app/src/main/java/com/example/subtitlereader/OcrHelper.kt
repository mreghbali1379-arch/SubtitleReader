package com.example.subtitlereader

import android.content.Context
import android.graphics.*
import android.net.Uri
import android.provider.OpenableColumns
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File
import java.util.concurrent.Executors

class OcrHelper(private val context: Context) {
    private val executor = Executors.newSingleThreadExecutor()
    private val lock = Any()
    private val fastDir = File(context.filesDir, "tessdata").apply { mkdirs() }
    private val bestDir = File(File(context.filesDir, "best"), "tessdata").apply { mkdirs() }
    private var api: TessBaseAPI? = null
    private var apiKey = ""
    @Volatile private var copied = false

    private fun filesIn(d: File): List<String> =
        d.listFiles { f -> f.name.endsWith(".traineddata") }
            ?.map { it.name.removeSuffix(".traineddata") }
            ?.sortedBy { if (it == "fas") 0 else 1 } ?: emptyList()

    /** The folder of the chosen model ("best" is slower and more accurate); falls back to the fast one. */
    private fun currentDir(): File =
        if (Prefs.ocrModel(context) == "best" && filesIn(bestDir).isNotEmpty()) bestDir else fastDir

    private fun copyDir(assetDir: String, target: File, stamp: String) {
        val marker = File(target, ".stamp")
        val force = !marker.exists() || marker.readText() != stamp
        context.assets.list(assetDir)?.filter { it.endsWith(".traineddata") }?.forEach { n ->
            val f = File(target, n)
            if (force || !f.exists()) context.assets.open("$assetDir/$n").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        }
        if (force) marker.writeText(stamp)
    }

    private fun copyAssets() {
        if (copied) return
        try {
            // After an app update the bundled language files replace the old copies.
            val stamp = try {
                context.packageManager.getPackageInfo(context.packageName, 0).lastUpdateTime.toString()
            } catch (e: Exception) { "" }
            copyDir("tessdata", fastDir, stamp)
            copyDir("tessdata_best", bestDir, stamp)
            copied = true
        } catch (ignored: Exception) {}
    }

    private fun languages(): List<String> = filesIn(currentDir())

    /** True if at least one OCR language file is installed. */
    fun hasData(): Boolean { copyAssets(); return languages().isNotEmpty() }

    /** Codes of the installed OCR languages (for example fas, eng). */
    fun installed(): List<String> { copyAssets(); return languages() }

    /** Drops the loaded engine so newly added language files are picked up. */
    fun reset() {
        try { executor.execute { synchronized(lock) { api?.recycle(); api = null } } } catch (ignored: Exception) {}
    }

    /** Copies a picked *.traineddata file into the app. Returns false if the file is not valid. */
    fun importData(uri: Uri): Boolean {
        val name = context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(c.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
        } ?: return false
        if (!name.endsWith(".traineddata")) return false
        context.contentResolver.openInputStream(uri)?.use { i ->
            File(currentDir(), name).outputStream().use { o -> i.copyTo(o) }
        } ?: return false
        executor.execute { synchronized(lock) { api?.recycle(); api = null } }
        return true
    }

    private fun ensureApi(): TessBaseAPI? {
        copyAssets()
        val dir = currentDir()
        val langs = filesIn(dir)
        if (langs.isEmpty()) return null
        val pref = Prefs.ocrLang(context)
        val use = if (pref != "all" && langs.contains(pref)) listOf(pref) else langs
        val key = dir.absolutePath + "|" + use.joinToString("+")
        val cur = api
        if (cur != null && key == apiKey) return cur
        cur?.recycle()
        api = null
        val a = TessBaseAPI()
        // the data path is the folder that contains the "tessdata" folder
        if (!a.init(dir.parentFile!!.absolutePath, use.joinToString("+"))) { a.recycle(); return null }
        a.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK)
        api = a
        apiKey = key
        return a
    }

    /** Subtitle bitmaps are light text on transparent: put on black, enlarge, invert to dark-on-light. */
    private fun prepare(src: Bitmap): Bitmap {
        val s = if (src.height < 150) 3 else 2
        val w = src.width * s
        val h = src.height * s
        val pad = 24
        val tmp = Bitmap.createBitmap(w + 2 * pad, h + 2 * pad, Bitmap.Config.ARGB_8888)
        Canvas(tmp).apply {
            drawColor(Color.BLACK)
            drawBitmap(src, null, Rect(pad, pad, pad + w, pad + h), Paint(Paint.FILTER_BITMAP_FLAG))
        }
        val inv = Paint().apply {
            colorFilter = ColorMatrixColorFilter(ColorMatrix(floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f)))
        }
        val out = Bitmap.createBitmap(tmp.width, tmp.height, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(tmp, 0f, 0f, inv)
        tmp.recycle()
        return out
    }

    private fun maskOf(src: Bitmap, bias: Int): TextMask {
        val w = src.width
        val h = src.height
        val px = IntArray(w * h)
        src.getPixels(px, 0, w, 0, 0, w, h)
        val l = FramePrep.lumas(px)
        return TextMask(FramePrep.mask(l, w, h, (FramePrep.threshold(l) + bias).coerceIn(120, 245)), w, h)
    }

    /** Hard black / white edges after enlarging, so letters stay crisp. */
    private fun crisp(b: Bitmap): Bitmap {
        val w = b.width
        val h = b.height
        val px = IntArray(w * h)
        b.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) px[i] = if (FramePrep.lum(px[i]) < 128) Color.BLACK else Color.WHITE
        val out = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
        b.recycle()
        return out
    }

    /** Cuts one text line out of the mask: black on white, tight box, enlarged so the line is about 60 px tall. */
    private fun lineBitmap(m: BooleanArray, w: Int, top: Int, bottom: Int): Bitmap? {
        var left = w
        var right = -1
        for (y in top..bottom) for (x in 0 until w) if (m[y * w + x]) { if (x < left) left = x; if (x > right) right = x }
        if (right < left) return null
        val bw = right - left + 1
        val bh = bottom - top + 1
        val pad = 16
        val buf = IntArray(bw * bh)
        for (y in 0 until bh) for (x in 0 until bw) {
            buf[y * bw + x] = if (m[(top + y) * w + left + x]) Color.BLACK else Color.WHITE
        }
        val out = Bitmap.createBitmap(bw + 2 * pad, bh + 2 * pad, Bitmap.Config.ARGB_8888)
        out.eraseColor(Color.WHITE)
        out.setPixels(buf, 0, bw, pad, pad, bw, bh)
        val scale = (60f / bh).coerceIn(1f, 4f)
        if (scale <= 1.05f) return out
        val big = Bitmap.createScaledBitmap(out, (out.width * scale).toInt(), (out.height * scale).toInt(), true)
        if (big !== out) out.recycle()
        return crisp(big)
    }

    /**
     * Reads the text pixels line by line (single-line mode). A line that is read with low confidence is
     * read again as a block, which also copes with two lines that touch. Null if no language file.
     */
    private fun readMask(m: BooleanArray, w: Int, h: Int): Pair<String, Int>? {
        val segs = FramePrep.lineSegments(m, w, h)
        if (segs.isEmpty()) return Pair("", 0)
        // many pieces look like noise rather than lines: read the whole area as one block
        val blockOnly = segs.size > 3
        val use: List<IntArray> = if (blockOnly) listOf(intArrayOf(segs[0][0], segs[segs.size - 1][1])) else segs
        val texts = ArrayList<String>()
        var confSum = 0
        var chars = 0
        for (s in use) {
            val img = lineBitmap(m, w, s[0], s[1]) ?: continue
            try {
                var best = runConf(img, if (blockOnly) TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK
                                        else TessBaseAPI.PageSegMode.PSM_SINGLE_LINE) ?: return null
                if (!blockOnly && best.second < 55) {
                    val alt = runConf(img, TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK)
                    if (alt != null && alt.second > best.second) best = alt
                }
                if (best.first.isNotEmpty()) {
                    texts.add(best.first)
                    confSum += best.second * best.first.length
                    chars += best.first.length
                }
            } finally {
                img.recycle()
            }
        }
        return Pair(texts.joinToString(" "), if (chars > 0) confSum / chars else 0)
    }

    /** Text-pixel map of a frame band (the band is recycled). */
    fun textMask(src: Bitmap): TextMask = try { maskOf(src, 0) } finally { src.recycle() }

    /** Reads an already prepared text-pixel map (for example several frames combined). Null if no language file. */
    fun recognizeMask(m: BooleanArray, w: Int, h: Int): Pair<String, Int>? {
        val r = readMask(m, w, h)
        if (Prefs.ocrEngine(context) != "drive") return r
        // Google Drive reading of the cleaned-up lines; the offline reading stays as a fallback
        val sheet = sheetOf(m, w, h) ?: return r
        val d = try { DriveOcr.read(context, sheet) } finally { sheet.recycle() }
        return if (!d.isNullOrBlank()) Pair(d, 100) else r
    }

    /** Black text on a white sheet, big enough for Google's OCR, built from a text-pixel map. */
    private fun sheetOf(m: BooleanArray, w: Int, h: Int): Bitmap? {
        val segs = FramePrep.lineSegments(m, w, h)
        if (segs.isEmpty()) return null
        val top = segs[0][0]
        val bottom = segs[segs.size - 1][1]
        var left = w
        var right = -1
        for (y in top..bottom) for (x in 0 until w) if (m[y * w + x]) { if (x < left) left = x; if (x > right) right = x }
        if (right < left) return null
        val bw = right - left + 1
        val bh = bottom - top + 1
        var tallest = 1
        for (s in segs) tallest = maxOf(tallest, s[1] - s[0] + 1)
        val buf = IntArray(bw * bh)
        for (y in 0 until bh) for (x in 0 until bw) {
            buf[y * bw + x] = if (m[(top + y) * w + left + x]) Color.BLACK else Color.WHITE
        }
        val small = Bitmap.createBitmap(buf, bw, bh, Bitmap.Config.ARGB_8888)
        val scale = (60f / tallest).coerceIn(1f, 4f)
        val tw = (bw * scale).toInt()
        val th = (bh * scale).toInt()
        val pad = 40
        val sheet = Bitmap.createBitmap(maxOf(tw + 2 * pad, 900), maxOf(th + 2 * pad, 240), Bitmap.Config.ARGB_8888)
        sheet.eraseColor(Color.WHITE)
        Canvas(sheet).drawBitmap(small, null, Rect(pad, pad, pad + tw, pad + th), Paint(Paint.FILTER_BITMAP_FLAG))
        small.recycle()
        return sheet
    }

    /** Readings of one frame band plus its text-pixel map. */
    class FrameRead(val reads: List<Pair<String, Int>>, val mask: TextMask)

    /**
     * Reads one frame band several times, each time with a slightly different brightness limit.
     * The band is recycled. Null if no language file is installed.
     */
    fun readFrame(src: Bitmap, biases: IntArray, drive: Boolean = false): FrameRead? {
        val out = ArrayList<Pair<String, Int>>()
        try {
            val base = maskOf(src, 0)
            for (b in biases) {
                val tm = if (b == 0) base else maskOf(src, b)
                val r = readMask(tm.m, tm.w, tm.h) ?: return null
                out.add(r)
            }
            if (drive) {
                // this frame is also read by Google Drive (cleaned lines on a white sheet)
                val sheet = sheetOf(base.m, base.w, base.h)
                if (sheet != null) {
                    val d = try { DriveOcr.read(context, sheet) } finally { sheet.recycle() }
                    if (!d.isNullOrBlank()) out.add(Pair(d, 100))
                }
            }
            return FrameRead(out, base)
        } finally {
            src.recycle()
        }
    }

    /** Reads hard-coded subtitles from a frame band. [done] gets the text ("" if none) or null if no language file. */
    fun recognizeFrame(src: Bitmap, drive: Boolean = false, done: (String?) -> Unit) {
        val tm = try { maskOf(src, 0) } finally { src.recycle() }
        try {
            executor.execute {
                var r: String? = try { readMask(tm.m, tm.w, tm.h)?.first } catch (e: Exception) { "" }
                if (drive) {
                    // [drive]: the offline reading stays as a fallback; Google's reading wins when it finds text
                    try {
                        val sheet = sheetOf(tm.m, tm.w, tm.h)
                        if (sheet != null) {
                            val d = try { DriveOcr.read(context, sheet) } finally { sheet.recycle() }
                            if (!d.isNullOrBlank()) r = d
                        }
                    } catch (e: Exception) { }
                }
                done(r)
            }
        } catch (e: Exception) {
            // the OCR thread is gone
        }
    }

    private fun runConf(img: Bitmap, psm: Int = TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK): Pair<String, Int>? = synchronized(lock) {
        val a = ensureApi() ?: return@synchronized null
        a.setPageSegMode(psm)
        a.setImage(img)
        val t = TextFix.fix(a.getUTF8Text() ?: "")
        Pair(t, a.meanConfidence())
    }

    private fun run(img: Bitmap): String? = runConf(img)?.first

    /** Blocking version, for use on a background thread (used when converting a whole track). */
    fun recognizeSync(src: Bitmap): String? {
        val img = prepare(src)
        return try {
            val t = run(img)
            val d = DriveOcr.read(context, img)
            if (!d.isNullOrBlank()) d else t
        } finally { img.recycle() }
    }

    /** Async version, for live reading of an image subtitle during playback. */
    fun recognize(src: Bitmap, onText: (String) -> Unit, onNoData: () -> Unit, online: Boolean = false) {
        val img = prepare(src)
        executor.execute {
            var t: String? = null
            try {
                t = run(img)
                // [online]: Google Drive reading, used only when a whole track is converted (too slow for live reading)
                if (online) {
                    val d = DriveOcr.read(context, img)
                    if (!d.isNullOrBlank()) t = d
                }
            } finally { img.recycle() }
            if (t == null) onNoData() else if (t.isNotEmpty()) onText(t)
        }
    }

    /** Runs a job on the OCR thread, so it executes after every recognition queued before it. */
    fun post(r: Runnable) { try { executor.execute(r) } catch (ignored: Exception) {} }

    fun release() { executor.execute { synchronized(lock) { api?.recycle(); api = null } }; executor.shutdown() }
}

/** Which pixels of a frame band belong to the subtitle text. */
class TextMask(val m: BooleanArray, val w: Int, val h: Int)
