package com.example.subtitlereader

import android.content.Context
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.*
import androidx.media3.common.text.CueGroup
import androidx.media3.exoplayer.ExoPlayer
import java.util.concurrent.atomic.AtomicInteger

/**
 * Scans an image-based subtitle track (PGS / DVB) with a hidden player at high speed,
 * runs OCR on every subtitle image and builds an SRT text file.
 */
class SubtitleConverter(private val context: Context, private val ocr: OcrHelper) {

    private class Entry(val start: Long, var end: Long, val text: String)

    private val handler = Handler(Looper.getMainLooper())
    private var player: ExoPlayer? = null
    private val pending = AtomicInteger(0)
    // open is touched only on the OCR thread; finished lines go to the shared LiveSubs
    private var live: LiveSubs? = null
    private var open: Entry? = null
    @Volatile private var started = false
    @Volatile private var finished = false
    @Volatile private var cuesSeen = 0
    @Volatile private var textsRead = 0
    private var errorText: String? = null

    /** Why the last conversion produced nothing (spoken to the user). */
    @Volatile var reason: String = ""
    private var lastPct = 0
    private val speed = 16f

    fun start(
        video: Uri,
        sub: MediaItem.SubtitleConfiguration?,
        textIndex: Int,
        store: LiveSubs,
        fromMs: Long,
        onProgress: (Int) -> Unit,
        onDone: (String?) -> Unit,
        onNoData: () -> Unit
    ) {
        live = store
        val pl = ExoPlayer.Builder(context).build()
        player = pl
        pl.trackSelectionParameters = pl.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
            .setTrackTypeDisabled(C.TRACK_TYPE_AUDIO, true)
            .build()

        fun finish(result: String?, noData: Boolean = false) {
            if (finished) return
            finished = true
            if (result == null) store.save()
            if (result == null && !noData) {
                reason = errorText ?: when {
                    cuesSeen == 0 -> "هیچ تصویر زیرنویسی از این مسیر خوانده نشد"
                    textsRead == 0 -> "تصویرها خوانده شدند اما متنی از آنها تشخیص داده نشد. فایل زبان OCR را بررسی کنید"
                    else -> "متنی ساخته نشد"
                }
            }
            handler.removeCallbacksAndMessages(null)
            player?.release(); player = null
            if (noData) onNoData() else onDone(result)
        }

        val progress = object : Runnable {
            override fun run() {
                val p = player ?: return
                val d = p.duration
                if (d > 0 && d != C.TIME_UNSET) {
                    val pct = (p.currentPosition * 100 / d).toInt() / 5 * 5
                    if (pct in 5..95 && pct > lastPct) { lastPct = pct; onProgress(pct) }
                }
                handler.postDelayed(this, 2000)
            }
        }

        fun done() {
            if (pending.decrementAndGet() <= 0) {
                handler.post { if (!finished && started) player?.playWhenReady = true }
            }
        }

        pl.addListener(object : Player.Listener {
            override fun onTracksChanged(tracks: Tracks) {
                if (started || finished || tracks.groups.isEmpty()) return
                val g = tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }.getOrNull(textIndex)
                if (g == null) { errorText = "مسیر زیرنویس پیدا نشد"; handler.post { finish(null) }; return }
                started = true
                pl.trackSelectionParameters = pl.trackSelectionParameters.buildUpon()
                    .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, 0)).build()
                pl.playbackParameters = PlaybackParameters(speed)
                if (fromMs > 0) pl.seekTo(fromMs)
                pl.playWhenReady = true
                handler.postDelayed(progress, 2000)
            }

            override fun onCues(cueGroup: CueGroup) {
                if (!started || finished) return
                val t = (if (cueGroup.presentationTimeUs == C.TIME_UNSET) pl.currentPosition * 1000
                         else cueGroup.presentationTimeUs) / 1000
                // whatever was showing ends now
                pending.incrementAndGet()
                ocr.post {
                    open?.let { store.add(it.start, t, it.text) }
                    open = null
                    store.covered(t)
                    done()
                }

                val bitmaps = cueGroup.cues.mapNotNull { it.bitmap }
                val text = cueGroup.cues.joinToString(" ") { it.text?.toString() ?: "" }.trim()
                if (bitmaps.isEmpty() && text.isEmpty()) return
                if (bitmaps.isNotEmpty()) cuesSeen++

                // new subtitle: pause until its OCR is finished (keeps memory small and order exact)
                pl.playWhenReady = false
                val sb = StringBuilder(text)
                bitmaps.forEach { bmp ->
                    ocr.recognize(bmp,
                        onText = { sb.append(' ').append(it); textsRead++ },
                        onNoData = { handler.post { finish(null, true) } },
                        online = true)
                }
                pending.incrementAndGet()
                ocr.post {
                    val s = sb.toString().trim()
                    if (s.isNotEmpty()) open = Entry(t, t, s)
                    done()
                }
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED && started && !finished) {
                    val dur = if (pl.duration == C.TIME_UNSET) 0L else pl.duration
                    ocr.post {
                        open?.let { store.add(it.start, dur, it.text) }
                        open = null
                        val empty = store.count() == 0
                        store.finish()
                        val srt = store.toSrt()
                        handler.post { finish(if (empty) null else srt) }
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                errorText = "خطای پخش: " + error.errorCodeName
                handler.post { finish(null) }
            }
        })

        val item = MediaItem.Builder().setUri(video).apply {
            if (sub != null) setSubtitleConfigurations(listOf(sub))
        }.build()
        pl.setMediaItem(item)
        pl.prepare()
        pl.playWhenReady = false
    }

    fun cancel() {
        live?.save()
        finished = true
        handler.removeCallbacksAndMessages(null)
        player?.release(); player = null
    }
}
