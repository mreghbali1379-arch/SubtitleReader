package com.example.subtitlereader

import android.content.Context
import android.net.Uri
import java.io.File
import java.security.MessageDigest

/** Where the subtitle files made from the sound of each film are kept (inside the app's private storage). */
object SpeechStore {

    fun key(uri: String): String {
        val d = MessageDigest.getInstance("SHA-1").digest(uri.toByteArray())
        return d.take(8).joinToString("") { "%02x".format(it) }
    }

    private fun dir(c: Context, key: String): File = File(c.filesDir, "speech/$key").also { it.mkdirs() }

    /** Subtitle made from the sound, in the language of the film. */
    fun orig(c: Context, key: String) = File(dir(c, key), "orig.srt")

    fun origPart(c: Context, key: String) = File(dir(c, key), "orig.part.srt")
    fun origMeta(c: Context, key: String) = File(dir(c, key), "orig.part.meta")
    private fun langFile(c: Context, key: String) = File(dir(c, key), "lang.txt")

    fun hasFinal(c: Context, key: String): Boolean = orig(c, key).exists()

    fun best(c: Context, key: String): File? = if (hasFinal(c, key)) orig(c, key) else null

    /** Film time (ms) up to which an unfinished conversion got, or 0. */
    fun partialCovered(c: Context, key: String): Long {
        if (hasFinal(c, key)) return 0L
        return try {
            if (!origPart(c, key).exists()) 0L else origMeta(c, key).readText().trim().toLongOrNull() ?: 0L
        } catch (e: Exception) { 0L }
    }

    fun setLang(c: Context, key: String, lang: String) {
        try { langFile(c, key).writeText(lang) } catch (ignored: Exception) {}
    }

    fun lang(c: Context, key: String): String? = try {
        val f = langFile(c, key)
        if (f.exists()) f.readText().trim().ifEmpty { null } else null
    } catch (e: Exception) { null }

    fun deletePartial(c: Context, key: String) {
        for (f in listOf(origPart(c, key), origMeta(c, key))) {
            try { f.delete() } catch (ignored: Exception) {}
        }
    }

    fun deleteAll(c: Context, key: String) {
        try { dir(c, key).deleteRecursively() } catch (ignored: Exception) {}
    }

    fun displayName(c: Context, uri: Uri): String {
        try {
            c.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) {
                    val n = it.getString(0)
                    if (!n.isNullOrBlank()) return n
                }
            }
        } catch (ignored: Exception) {}
        return uri.lastPathSegment ?: "film"
    }
}
