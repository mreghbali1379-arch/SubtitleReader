package com.example.subtitlereader

/** The last finished translation, remembered so the player's "save subtitle" item can save it. Tied to the film it was made for. */
object TranslatedStore {
    @Volatile var cues: List<SubtitleFormats.Cue>? = null
        private set
    @Volatile var lang: String = ""
        private set
    @Volatile var video: String? = null
        private set

    fun set(c: List<SubtitleFormats.Cue>, language: String, videoKey: String?) {
        cues = c
        lang = language
        video = videoKey
    }

    /** Called when a newer subtitle is made or loaded for the film: the translation is then no longer the latest. */
    fun clear() {
        cues = null
        video = null
    }

    fun forVideo(videoKey: String?): List<SubtitleFormats.Cue>? {
        val c = cues
        return if (c != null && c.isNotEmpty() && videoKey != null && videoKey == video) c else null
    }
}
