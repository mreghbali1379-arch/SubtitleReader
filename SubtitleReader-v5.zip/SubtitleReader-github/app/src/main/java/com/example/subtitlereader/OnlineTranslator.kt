package com.example.subtitlereader

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Online translation through Google Translate's public web endpoint (no key needed).
 * It is not an official API, so it can be slowed down or stopped by Google at any time;
 * the converter then falls back to the offline ML Kit models.
 */
object OnlineTranslator {

    @Volatile var lastError: String? = null

    private fun code(lang: String): String = when (lang) {
        "he" -> "iw"
        "jv" -> "jw"
        "zh" -> "zh-CN"
        else -> lang
    }

    /** Blocks (network): call from a worker thread. Returns null on any failure and sets [lastError]. */
    fun translate(text: String, src: String, target: String): String? {
        if (text.isBlank()) return text
        var attempt = 0
        while (attempt < 2) {
            attempt++
            var conn: HttpURLConnection? = null
            try {
                val u = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=" + code(src) +
                    "&tl=" + code(target) + "&dt=t&q=" + URLEncoder.encode(text, "UTF-8")
                conn = URL(u).openConnection() as HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 15000
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) SubtitleReader")
                val c = conn.responseCode
                if (c == 429 || c == 403) { lastError = "گوگل درخواست‌ها را محدود کرد (کد $c)"; return null }
                if (c != 200) { lastError = "پاسخ نامعتبر از سرور (کد $c)"; continue }
                val body = conn.inputStream.use { it.readBytes() }.toString(Charsets.UTF_8)
                val parts = JSONArray(body).getJSONArray(0)
                val sb = StringBuilder()
                for (i in 0 until parts.length()) {
                    val seg = parts.optJSONArray(i) ?: continue
                    sb.append(seg.optString(0, ""))
                }
                val out = sb.toString().trim()
                if (out.isEmpty()) { lastError = "ترجمه‌ی خالی برگشت"; return null }
                return out
            } catch (e: Exception) {
                lastError = e.message ?: e.javaClass.simpleName
            } finally {
                try { conn?.disconnect() } catch (ignored: Exception) {}
            }
        }
        return null
    }
}
