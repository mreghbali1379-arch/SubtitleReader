package com.example.subtitlereader

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Online translation through Google Translate's public web endpoint (no key needed).
 * It is not an official API, so it can be slowed down or stopped by Google at any time;
 * the converter then falls back to the offline ML Kit models.
 */
object OnlineTranslator {

    @Volatile var lastError: String? = null

    @Volatile private var current: HttpURLConnection? = null

    /** Cuts a request that is waiting for the answer (used when the person stops the translation). */
    fun abort() { try { current?.disconnect() } catch (ignored: Exception) {} }

    private fun code(lang: String): String = when (lang) {
        "he" -> "iw"
        "jv" -> "jw"
        "zh" -> "zh-CN"
        else -> lang
    }

    /**
     * Blocks (network): call from a worker thread. Sends [text] (many lines, one per line) as ONE request and returns the whole
     * translated text. [Bulk.fatal] is true when Google is limiting us (nothing more should be sent); otherwise a null text means
     * "this much text did not work", and the caller may try less.
     */
    fun translateBlock(text: String, src: String, target: String): Bulk {
        var conn: HttpURLConnection? = null
        try {
            val u = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=" + code(src) + "&tl=" + code(target) + "&dt=t"
            conn = URL(u).openConnection() as HttpURLConnection
            current = conn
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 15000
            conn.readTimeout = 180000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) SubtitleReader")
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=utf-8")
            conn.outputStream.use { it.write(("q=" + URLEncoder.encode(text, "UTF-8")).toByteArray(Charsets.UTF_8)) }
            val c = conn.responseCode
            if (c == 429 || c == 403) { lastError = "گوگل درخواست‌ها را محدود کرد (کد $c)"; return Bulk(null, true) }
            if (c != 200) { lastError = "پاسخ نامعتبر از سرور (کد $c)"; return Bulk(null, false) }
            val body = conn.inputStream.use { it.readBytes() }.toString(Charsets.UTF_8)
            val parts = JSONArray(body).getJSONArray(0)
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val seg = parts.optJSONArray(i) ?: continue
                sb.append(seg.optString(0, ""))
            }
            val out = sb.toString()
            if (out.isBlank()) { lastError = "ترجمه‌ی خالی برگشت"; return Bulk(null, false) }
            return Bulk(out, false)
        } catch (e: Exception) {
            lastError = e.message ?: e.javaClass.simpleName
            // no connection at all: sending less will not help
            return Bulk(null, e is java.net.UnknownHostException || e is java.net.ConnectException)
        } finally {
            current = null
            try { conn?.disconnect() } catch (ignored: Exception) {}
        }
    }

    /** Blocks (network): call from a worker thread. Returns null on any failure and sets [lastError]. */
    fun translate(text: String, src: String, target: String): String? {
        if (text.isBlank()) return text
        var attempt = 0
        while (attempt < 2) {
            attempt++
            var conn: HttpURLConnection? = null
            try {
                val u = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=" + code(src) +
                    "&tl=" + code(target) + "&dt=t&q=" + URLEncoder.encode(text, "UTF-8")
                conn = URL(u).openConnection() as HttpURLConnection
                conn.connectTimeout = 10000
                conn.readTimeout = 15000
                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) SubtitleReader")
                val c = conn.responseCode
                if (c == 429 || c == 403) { lastError = "گوگل درخواست‌ها را محدود کرد (کد $c)"; return null }
                if (c != 200) { lastError = "پاسخ نامعتبر از سرور (کد $c)"; continue }
                val body = conn.inputStream.use { it.readBytes() }.toString(Charsets.UTF_8)
                val parts = JSONArray(body).getJSONArray(0)
                val sb = StringBuilder()
                for (i in 0 until parts.length()) {
                    val seg = parts.optJSONArray(i) ?: continue
                    sb.append(seg.optString(0, ""))
                }
                val out = sb.toString().trim()
                if (out.isEmpty()) { lastError = "ترجمه‌ی خالی برگشت"; return null }
                return out
            } catch (e: Exception) {
                lastError = e.message ?: e.javaClass.simpleName
            } finally {
                try { conn?.disconnect() } catch (ignored: Exception) {}
            }
        }
        return null
    }
}
