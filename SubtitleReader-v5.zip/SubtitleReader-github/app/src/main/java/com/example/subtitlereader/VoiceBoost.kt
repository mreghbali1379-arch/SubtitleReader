package com.example.subtitlereader

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.tanh

/**
 * Makes weak voices easier for the speech model (16 kHz mono samples, one window at a time):
 * removes low rumble, lifts quiet speech towards a steady level without lifting noise-only parts, and keeps peaks from clipping.
 * [level]: 0 off, 1 mild, 2 strong, 3 very strong (for very faint voices).
 */
object VoiceBoost {
    private const val RATE = AudioDecoder.RATE

    private fun targetDb(level: Int) = when (level) { 1 -> -22.0; 2 -> -20.0; else -> -18.0 }
    private fun maxGainDb(level: Int) = when (level) { 1 -> 12.0; 2 -> 24.0; else -> 34.0 }

    fun process(x: FloatArray, n: Int, level: Int) {
        if (level <= 0 || n < RATE / 5) return
        highPass(x, n)

        val frame = RATE / 50 // 20 ms
        val count = n / frame
        if (count < 10) return
        val db = DoubleArray(count)
        for (f in 0 until count) {
            var e = 0.0
            val o = f * frame
            for (i in 0 until frame) { val v = x[o + i].toDouble(); e += v * v }
            db[f] = 10 * log10(e / frame + 1e-12)
        }
        val sorted = db.sortedArray()
        val noise = sorted[count / 10]
        val typical = sorted[count * 8 / 10]
        val maxG = maxGainDb(level)
        val target = targetDb(level)

        // gain in dB per frame: falls fast when something loud comes, rises slowly, and never rises on noise-only frames
        var g = (target - typical).coerceIn(0.0, maxG)
        val lin = DoubleArray(count)
        for (f in 0 until count) {
            var want = (target - db[f]).coerceIn(0.0, maxG)
            if (db[f] < noise + 5.0 && want > g) want = g
            g += (want - g) * (if (want < g) 0.5 else 0.04)
            lin[f] = 10.0.pow(g / 20.0)
        }

        for (i in 0 until n) {
            val p = (i - frame / 2.0) / frame
            val gain = when {
                p <= 0.0 -> lin[0]
                p >= count - 1 -> lin[count - 1]
                else -> {
                    val f0 = floor(p).toInt()
                    val t = p - f0
                    lin[f0] * (1 - t) + lin[f0 + 1] * t
                }
            }
            var y = (x[i] * gain).toFloat()
            val a = abs(y)
            if (a > 0.9f) {
                val s = 0.9f + 0.1f * tanh(((a - 0.9f) / 0.1f).toDouble()).toFloat()
                y = if (y < 0) -s else s
            }
            x[i] = y
        }
    }

    /** Second-order high-pass at 100 Hz: removes rumble and hum that only waste the model's attention. */
    private fun highPass(x: FloatArray, n: Int) {
        val w0 = 2 * PI * 100.0 / RATE
        val alpha = sin(w0) / (2 * 0.7071)
        val c = cos(w0)
        val a0 = 1 + alpha
        val b0 = (1 + c) / 2 / a0
        val b1 = -(1 + c) / a0
        val b2 = b0
        val a1 = -2 * c / a0
        val a2 = (1 - alpha) / a0
        var x1 = 0.0; var x2 = 0.0; var y1 = 0.0; var y2 = 0.0
        for (i in 0 until n) {
            val xi = x[i].toDouble()
            val y = b0 * xi + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2 = x1; x1 = xi
            y2 = y1; y1 = y
            x[i] = y.toFloat()
        }
    }
}
