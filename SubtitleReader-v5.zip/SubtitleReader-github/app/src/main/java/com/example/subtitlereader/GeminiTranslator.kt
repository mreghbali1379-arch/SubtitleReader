package com.example.subtitlereader

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Translation with Google Gemini (the user's own API key from Google AI Studio).
 * Several subtitle lines are sent in one request, so the free quota lasts much longer
 * and the lines are translated with their context.
 */
object GeminiTranslator {

    const val DEFAULT_MODEL = "gemini-flash-latest"

    @Volatile var lastError: String? = null

    /** Blocks (network): call from a worker thread. Returns the translated lines (same count), or null on failure. */
    fun translate(lines: List<String>, src: String, target: String, key: String, model: String): List<String>? {
        if (lines.isEmpty()) return emptyList()
        if (key.isBlank()) { lastError = "کلید Gemini وارد نشده است"; return null }
        val m = model.trim().ifEmpty { DEFAULT_MODEL }
        var conn: HttpURLConnection? = null
        try {
            val prompt = "You translate movie subtitles. Translate each line below" +
                (if (src == "auto") "" else " from " + Langs.englishName(src)) +
                " to " + Langs.englishName(target) + ". Use natural, spoken language that fits a movie. " +
                "Keep names and numbers. Do not merge or split lines and do not add notes. " +
                "Return ONLY a JSON array of exactly " + lines.size + " strings, in the same order.\n\n" +
                JSONArray(lines).toString()
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", JSONObject().put("temperature", 0.2).put("responseMimeType", "application/json"))
                .toString()
            conn = URL("https://generativelanguage.googleapis.com/v1beta/models/" + m + ":generateContent")
                .openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 90000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("x-goog-api-key", key.trim())
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code != 200) {
                val err = try { conn.errorStream?.use { it.readBytes() }?.toString(Charsets.UTF_8) ?: "" } catch (e: Exception) { "" }
                lastError = when (code) {
                    400 -> if (err.contains("API key", true)) "کلید Gemini معتبر نیست" else "درخواست نامعتبر (کد 400)"
                    401, 403 -> "کلید Gemini پذیرفته نشد (کد $code)"
                    404 -> "مدل «$m» پیدا نشد؛ اسم مدل را در تنظیمات بررسی کنید"
                    429 -> "سهمیه‌ی Gemini تمام شده یا درخواست‌ها زیاد است (کد 429)"
                    else -> "خطای سرور Gemini (کد $code)"
                }
                return null
            }
            val resp = conn.inputStream.use { it.readBytes() }.toString(Charsets.UTF_8)
            val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
            var text = sb.toString().trim()
            if (text.startsWith("```")) text = text.substringAfter('\n').substringBeforeLast("```").trim()
            val arr = JSONArray(text)
            if (arr.length() != lines.size) { lastError = "تعداد خط‌های ترجمه‌شده با اصل یکی نبود"; return null }
            val out = ArrayList<String>()
            for (i in 0 until arr.length()) out.add(arr.optString(i, "").trim())
            if (out.any { it.isEmpty() }) { lastError = "بعضی خط‌ها خالی ترجمه شدند"; return null }
            return out
        } catch (e: Exception) {
            lastError = e.message ?: e.javaClass.simpleName
            return null
        } finally {
            try { conn?.disconnect() } catch (ignored: Exception) {}
        }
    }
}
