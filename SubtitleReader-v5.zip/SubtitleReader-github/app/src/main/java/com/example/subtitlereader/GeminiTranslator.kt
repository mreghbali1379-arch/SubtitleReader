package com.example.subtitlereader

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Translation with Google Gemini (the user's own API key from Google AI Studio).
 * The whole subtitle goes in ONE request and the whole translation comes back once ([translateAll]), so the model sees the
 * entire film (consistent names and tone) and there are no piece-by-piece requests that can fail half way.
 */
object GeminiTranslator {

    const val DEFAULT_MODEL = "gemini-flash-latest"

    @Volatile var lastError: String? = null

    @Volatile private var current: HttpURLConnection? = null

    /** Cuts a request that is waiting for the answer (used when the person stops the translation). */
    fun abort() { try { current?.disconnect() } catch (ignored: Exception) {} }

    private class Reply(val code: Int, val body: String)

    private fun post(body: String, key: String, m: String): Reply {
        var conn: HttpURLConnection? = null
        try {
            conn = URL("https://generativelanguage.googleapis.com/v1beta/models/" + m + ":generateContent")
                .openConnection() as HttpURLConnection
            current = conn
            conn.requestMethod = "POST"
            conn.connectTimeout = 20000
            conn.readTimeout = 600000   // a whole film is translated in one go: allow up to 10 minutes
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("x-goog-api-key", key.trim())
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val text = if (code == 200) conn.inputStream.use { it.readBytes() }.toString(Charsets.UTF_8)
                else try { conn.errorStream?.use { it.readBytes() }?.toString(Charsets.UTF_8) ?: "" } catch (e: Exception) { "" }
            return Reply(code, text)
        } catch (e: Exception) {
            return Reply(-1, e.message ?: e.javaClass.simpleName)
        } finally {
            current = null
            try { conn?.disconnect() } catch (ignored: Exception) {}
        }
    }

    private fun errorFor(code: Int, err: String, m: String): String = when (code) {
        -1 -> "ارتباط با Gemini برقرار نشد یا جواب دیر رسید ($err)"
        400 -> if (err.contains("API key", true)) "کلید Gemini معتبر نیست" else "درخواست نامعتبر (کد 400)"
        401, 403 -> "کلید Gemini پذیرفته نشد (کد $code)"
        404 -> "مدل «$m» پیدا نشد؛ اسم مدل را در تنظیمات بررسی کنید"
        429 -> "سهمیه‌ی Gemini تمام شده یا درخواست‌ها زیاد است (کد 429)"
        else -> "خطای سرور Gemini (کد $code)"
    }

    private val objRe = Regex("\\{[^{}]*\\}")

    /** Reads the answer: a JSON array of {id, text}. A cut-off answer still gives every complete object before the cut. */
    private fun parseItems(raw: String): Map<Int, String> {
        var text = raw.trim()
        if (text.startsWith("```")) text = text.substringAfter('\n').substringBeforeLast("```").trim()
        val out = HashMap<Int, String>()
        try {
            val arr = JSONArray(text)
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val t = o.optString("text", "").trim()
                if (o.has("id") && t.isNotEmpty()) out[o.optInt("id", -1)] = t
            }
            if (out.isNotEmpty()) return out
        } catch (ignored: Exception) {}
        for (m in objRe.findAll(text)) {
            try {
                val o = JSONObject(m.value)
                val t = o.optString("text", "").trim()
                if (o.has("id") && t.isNotEmpty()) out[o.optInt("id", -1)] = t
            } catch (ignored: Exception) {}
        }
        return out
    }

    /**
     * Blocks (network): call from a worker thread. Sends ALL [items] (id to text) in one request and returns id to translation for
     * the lines that came back (fewer than sent if the answer was cut short), or null when nothing usable came back ([lastError] says why).
     * Short outages (busy server, a dropped connection) are retried a couple of times.
     */
    fun translateAll(
        items: List<Pair<Int, String>>, src: String, target: String, key: String, model: String,
        isCancelled: () -> Boolean
    ): Map<Int, String>? {
        if (items.isEmpty()) return emptyMap()
        if (key.isBlank()) { lastError = "کلید Gemini وارد نشده است"; return null }
        val m = model.trim().ifEmpty { DEFAULT_MODEL }
        val arr = JSONArray()
        for ((id, t) in items) arr.put(JSONObject().put("id", id).put("text", t))
        val prompt = "You translate the complete subtitles of a movie. The JSON array below holds ALL the lines, in order. " +
            "Translate every line" + (if (src == "auto") "" else " from " + Langs.englishName(src)) +
            " to " + Langs.englishName(target) + ". Use natural, spoken language that fits a movie, and use the whole story as context " +
            "so names, terms and tone stay consistent. Keep names and numbers. Do not merge, split, skip or reorder lines and do not add notes. " +
            "Return ONLY a JSON array of objects {\"id\": number, \"text\": string}: one object for every input line, with the same id.\n\n" +
            arr.toString()
        val safety = JSONArray()
        for (c in listOf("HARM_CATEGORY_HARASSMENT", "HARM_CATEGORY_HATE_SPEECH", "HARM_CATEGORY_SEXUALLY_EXPLICIT", "HARM_CATEGORY_DANGEROUS_CONTENT"))
            safety.put(JSONObject().put("category", c).put("threshold", "BLOCK_NONE"))   // film dialogue has rough words; do not refuse it
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("temperature", 0.2).put("responseMimeType", "application/json"))
            .put("safetySettings", safety)
            .toString()

        var attempt = 0
        while (true) {
            attempt++
            val r = post(body, key, m)
            if (isCancelled()) { lastError = "متوقف شد"; return null }
            if (r.code == 200) {
                try {
                    val root = JSONObject(r.body)
                    val cands = root.optJSONArray("candidates")
                    if (cands == null || cands.length() == 0) {
                        val why = root.optJSONObject("promptFeedback")?.optString("blockReason", "") ?: ""
                        lastError = if (why.isNotEmpty()) "Gemini ترجمه را رد کرد ($why)" else "Gemini جوابی نداد"
                        return null
                    }
                    val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
                    val sb = StringBuilder()
                    if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
                    val got = parseItems(sb.toString())
                    if (got.isEmpty()) { lastError = "جواب Gemini خوانده نشد"; return null }
                    return got
                } catch (e: Exception) {
                    lastError = "جواب Gemini خوانده نشد: " + (e.message ?: e.javaClass.simpleName)
                    return null
                }
            }
            lastError = errorFor(r.code, r.body, m)
            val retry = r.code == -1 || r.code == 429 || r.code == 500 || r.code == 502 || r.code == 503 || r.code == 504
            if (!retry || attempt >= 3) return null
            var waitMs = if (attempt == 1) 5000 else 15000
            while (waitMs > 0 && !isCancelled()) { try { Thread.sleep(500) } catch (e: InterruptedException) { break }; waitMs -= 500 }
            if (isCancelled()) { lastError = "متوقف شد"; return null }
        }
    }

    /** Blocks (network): call from a worker thread. Returns the translated lines (same count), or null on failure. */
    fun translate(lines: List<String>, src: String, target: String, key: String, model: String): List<String>? {
        if (lines.isEmpty()) return emptyList()
        if (key.isBlank()) { lastError = "کلید Gemini وارد نشده است"; return null }
        val m = model.trim().ifEmpty { DEFAULT_MODEL }
        var conn: HttpURLConnection? = null
        try {
            val prompt = "You translate movie subtitles. Translate each line below" +
                (if (src == "auto") "" else " from " + Langs.englishName(src)) +
                " to " + Langs.englishName(target) + ". Use natural, spoken language that fits a movie. " +
                "Keep names and numbers. Do not merge or split lines and do not add notes. " +
                "Return ONLY a JSON array of exactly " + lines.size + " strings, in the same order.\n\n" +
                JSONArray(lines).toString()
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", JSONObject().put("temperature", 0.2).put("responseMimeType", "application/json"))
                .toString()
            conn = URL("https://generativelanguage.googleapis.com/v1beta/models/" + m + ":generateContent")
                .openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 90000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("x-goog-api-key", key.trim())
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            if (code != 200) {
                val err = try { conn.errorStream?.use { it.readBytes() }?.toString(Charsets.UTF_8) ?: "" } catch (e: Exception) { "" }
                lastError = when (code) {
                    400 -> if (err.contains("API key", true)) "کلید Gemini معتبر نیست" else "درخواست نامعتبر (کد 400)"
                    401, 403 -> "کلید Gemini پذیرفته نشد (کد $code)"
                    404 -> "مدل «$m» پیدا نشد؛ اسم مدل را در تنظیمات بررسی کنید"
                    429 -> "سهمیه‌ی Gemini تمام شده یا درخواست‌ها زیاد است (کد 429)"
                    else -> "خطای سرور Gemini (کد $code)"
                }
                return null
            }
            val resp = conn.inputStream.use { it.readBytes() }.toString(Charsets.UTF_8)
            val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
            var text = sb.toString().trim()
            if (text.startsWith("```")) text = text.substringAfter('\n').substringBeforeLast("```").trim()
            val arr = JSONArray(text)
            if (arr.length() != lines.size) { lastError = "تعداد خط‌های ترجمه‌شده با اصل یکی نبود"; return null }
            val out = ArrayList<String>()
            for (i in 0 until arr.length()) out.add(arr.optString(i, "").trim())
            if (out.any { it.isEmpty() }) { lastError = "بعضی خط‌ها خالی ترجمه شدند"; return null }
            return out
        } catch (e: Exception) {
            lastError = e.message ?: e.javaClass.simpleName
            return null
        } finally {
            try { conn?.disconnect() } catch (ignored: Exception) {}
        }
    }
}
