package com.example.subtitlereader

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import com.google.android.gms.auth.api.identity.Identity
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

private const val MODEL_HELP =
    "مدل‌ها را از «دانلود مدل» در همین بخش بگیرید؛ نیازی به دانلود دستی نیست (اینترنت لازم است).\n\n" +
    "• Base (حدود ۶۰ مگابایت): سریع، دقت کم‌تر. برای گوشی‌های ضعیف.\n" +
    "• Small (حدود ۱۹۰ مگابایت): تعادل خوب. پیشنهاد برای شروع.\n" +
    "• Medium (حدود ۵۴۰ مگابایت): دقیق ولی کندتر.\n" +
    "• Large v3 Turbo (حدود ۵۷۵ مگابایت): بهترین دقت؛ روی گوشی قوی.\n\n" +
    "اگر خودتان فایل ggml را از جای دیگر گرفته‌اید، با «افزودن فایل مدل» آن را اضافه کنید. مدل‌هایی که اسمشان en دارد فقط انگلیسی می‌فهمند."

/** Settings in the style of MX Player: grouped rows with a title and a summary. */
class SettingsActivity : AppCompatActivity(), TextToSpeech.OnInitListener {

    private lateinit var ocr: OcrHelper
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var persian: Boolean? = null   // null = unknown (the engine may still read Persian)

    private val summaries = ArrayList<Pair<TextView, () -> String>>()
    private lateinit var box: LinearLayout

    private val pickOcrData = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val ok = ocr.importData(uri)
            tell(if (ok) "فایل زبان اضافه شد" else "فایل باید با پسوند traineddata باشد")
            refreshAll()
        }
    }

    private val pickModel = registerForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) importModel(u)
    }

    private val authLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        var ok = false
        try {
            val data = r.data
            if (data != null) ok = Identity.getAuthorizationClient(this).getAuthorizationResultFromIntent(data).accessToken != null
        } catch (e: Exception) { }
        if (ok) { Prefs.setOcrEngine(this, "drive"); DriveOcr.resetRun() }
        tell(if (ok) "ورود به گوگل‌درایو انجام شد" else "ورود به گوگل‌درایو انجام نشد")
        refreshAll()
    }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun tell(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    private val percents = (0..10).map { it * 10 }
    private val speechPercents = (1..10).map { it * 10 }
    private val rates = listOf(0.6f, 0.8f, 1.0f, 1.2f, 1.4f, 1.6f, 1.8f, 2.0f, 2.5f, 3.0f)
    private val skips = listOf(5, 10, 15, 30, 60)
    private val hides = listOf(3, 5, 10, 15)
    private val bands = listOf(20, 30, 40, 50, 100)
    private val steps = listOf(250, 500, 1000, 2000, 3000, 5000)   // milliseconds
    private val leads = listOf(15, 60, 120, 240, 480, 900, 1800, 2700, 3600)   // seconds

    private fun leadLabel(s: Int): String =
        if (s <= 15) "$s ثانیه (پیش‌فرض: پخش بدون انتظار طولانی)"
        else (if (s >= 3600) "${s / 3600} ساعت" else "${s / 60} دقیقه") + " (پخش خودکار شروع می‌شود وقتی این مقدار زیرنویس ساخته شده باشد)"

    private fun stepLabel(ms: Int): String =
        if (ms % 1000 == 0) "${ms / 1000} ثانیه"
        else "%.2f ثانیه".format(ms / 1000.0) + (if (ms <= 500) " (فریم‌های بیشتر، کندتر)" else "")

    private fun nearest(list: List<Int>, v: Int): Int {
        var best = 0
        for (i in list.indices) if (abs(list[i] - v) < abs(list[best] - v)) best = i
        return best
    }

    private fun nearestRate(v: Float): Int {
        var best = 0
        for (i in rates.indices) if (abs(rates[i] - v) < abs(rates[best] - v)) best = i
        return best
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ocr = OcrHelper(this)
        tts = TextToSpeech(this, this, Prefs.engine(this))

        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        buildRows()

        val title = TextView(this).apply {
            text = "تنظیمات"
            setTextColor(Color.WHITE)
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER_VERTICAL
        }
        ViewCompat.setAccessibilityHeading(title, true)
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Ui.BAR)
            val p = dp(8)
            setPadding(p, p, p, p)
            addView(Ui.icon(this@SettingsActivity, R.drawable.ic_back, "بازگشت") { finish() })
            addView(title, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) })
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Ui.BG)
            addView(bar, LinearLayout.LayoutParams(-1, -2))
            addView(ScrollView(this@SettingsActivity).apply { addView(box) }, LinearLayout.LayoutParams(-1, 0, 1f))
        })
        refreshAll()
    }

    // ---------- row building ----------

    private fun header(t: String) {
        val v = TextView(this).apply {
            text = t
            setTextColor(Ui.ACCENT)
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(16), dp(24), dp(16), dp(4))
        }
        ViewCompat.setAccessibilityHeading(v, true)
        box.addView(v, LinearLayout.LayoutParams(-1, -2))
    }

    private fun row(title: String, summary: () -> String, action: () -> Unit) {
        val tvT = TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 17f
        }
        val tvS = TextView(this).apply {
            setTextColor(Ui.TEXT2)
            textSize = 14f
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            isFocusable = true
            Ui.ripple(this@SettingsActivity, this, false)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            addView(tvT)
            addView(tvS)
            setOnClickListener { action() }
        }
        summaries.add(Pair(tvS, summary))
        box.addView(col, LinearLayout.LayoutParams(-1, -2))
    }

    /** An on/off option shown as a real check box (TalkBack reads "checked" / "not checked"). */
    private fun checkRow(title: String, note: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        val cb = android.widget.CheckBox(this).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 17f
            isChecked = get()
            setOnCheckedChangeListener { _, b -> set(b) }
        }
        val tvN = TextView(this).apply {
            text = note
            setTextColor(Ui.TEXT2)
            textSize = 14f
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            addView(cb)
            addView(tvN)
        }
        box.addView(col, LinearLayout.LayoutParams(-1, -2))
    }

    private fun refreshAll() {
        for (p in summaries) {
            val t = p.second()
            p.first.text = t
            p.first.visibility = if (t.isEmpty()) View.GONE else View.VISIBLE
        }
    }

    private fun choose(title: String, labels: List<String>, current: Int, onPick: (Int) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(labels.toTypedArray(), current) { d, which ->
                d.dismiss()
                onPick(which)
                refreshAll()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun buildRows() {
        header("پخش‌کننده")
        row("صدای فیلم", { Math.round(Prefs.movieVolume(this) * 100).toString() + " درصد" }) {
            choose("صدای فیلم", percents.map { "$it درصد" },
                nearest(percents, Math.round(Prefs.movieVolume(this) * 100))) { i ->
                Prefs.setMovieVolume(this, percents[i] / 100f)
            }
        }
        row("مدت پرش", { Prefs.skipSeconds(this).toString() + " ثانیه" }) {
            choose("مدت پرش", skips.map { "$it ثانیه" }, nearest(skips, Prefs.skipSeconds(this))) { i ->
                Prefs.setSkipSeconds(this, skips[i])
            }
        }
        row("مدت نمایش دکمه‌ها", { Prefs.hideSeconds(this).toString() + " ثانیه" }) {
            choose("مدت نمایش دکمه‌ها", hides.map { "$it ثانیه" }, nearest(hides, Prefs.hideSeconds(this))) { i ->
                Prefs.setHideSeconds(this, hides[i])
            }
        }

        header("گفتار (خواندن زیرنویس)")
        row("موتور گفتار", { engineSummary() }) { chooseEngine() }
        row("سرعت خواندن", { "%.1f".format(Prefs.rate(this)) }) {
            choose("سرعت خواندن", rates.map { "%.1f".format(it) }, nearestRate(Prefs.rate(this))) { i ->
                Prefs.setRate(this, rates[i])
                tts?.setSpeechRate(rates[i])
                speakTest("این سرعت خواندن است")
            }
        }
        row("صدای خواندن", { Math.round(Prefs.volume(this) * 100).toString() + " درصد" }) {
            choose("صدای خواندن", speechPercents.map { "$it درصد" },
                nearest(speechPercents, Math.round(Prefs.volume(this) * 100))) { i ->
                Prefs.setVolume(this, speechPercents[i] / 100f)
                speakTest("این صدای خواندن است")
            }
        }
        row("آزمایش صدا", { "" }) {
            speakTest("سلام. این یک آزمایش صدای فارسی است.")
        }
        row("نصب یا به‌روزرسانی صدای موتور", { "" }) { installVoice() }
        row("تنظیمات گفتار گوشی", { "" }) { openSystemTts() }

        header("زیرنویس")
        row("تأخیر زیرنویس", { "%+.1f".format(Prefs.syncOffset(this) / 1000.0) + " ثانیه" }) {
            Ui.syncMenu(this) { refreshAll() }
        }
        row("ناحیه‌ی خواندن زیرنویس چسبیده به تصویر", { Prefs.hardsubBand(this).toString() + " درصد پایین تصویر" }) {
            choose("ناحیه‌ی خواندن", bands.map { "$it درصد پایین تصویر" }, nearest(bands, Prefs.hardsubBand(this))) { i ->
                Prefs.setHardsubBand(this, bands[i])
            }
        }
        row("فاصله‌ی نمونه‌برداری", { stepLabel(Prefs.hardsubStepMs(this)) }) {
            choose("فاصله‌ی نمونه‌برداری", steps.map { stepLabel(it) }, nearest(steps, Prefs.hardsubStepMs(this))) { i ->
                Prefs.setHardsubStepMs(this, steps[i])
            }
        }
        row("زیرنویسِ آماده‌شده پیش از شروع پخش", { leadLabel(Prefs.leadSeconds(this)) }) {
            choose("زیرنویسِ آماده‌شده پیش از شروع پخش", leads.map { leadLabel(it) }, nearest(leads, Prefs.leadSeconds(this))) { i ->
                Prefs.setLeadSeconds(this, leads[i])
            }
        }
        row("موتور تشخیص متن", { ocrEngineSummary() }) { chooseOcrEngine() }
        checkRow("ارسال همه‌ی فریم‌های دارای زیرنویس به گوگل",
            "اگر تیک نخورده باشد، فقط خطوط تمیزشده‌ی هر زیرنویس (پس از خوانش آفلاین) به گوگل می‌رود. با تیک، تک‌تک فریم‌ها هم می‌روند؛ دقیق‌تر ولی خیلی کندتر. فقط با موتور گوگل‌درایو اثر دارد.",
            { Prefs.driveAllFrames(this) }, { Prefs.setDriveAllFrames(this, it) })
        checkRow("استفاده از گوگل‌درایو هنگام خواندن زنده‌ی زیرنویس",
            "با تیک، زیرنویس چسبیده به تصویر و زیرنویس تصویری هنگام پخش هم با گوگل خوانده می‌شود؛ هر خط چند ثانیه دیرتر خوانده می‌شود و ممکن است زیرنویس‌های کوتاه از دست بروند. بدون تیک، خواندن زنده آفلاین می‌ماند. فقط با موتور گوگل‌درایو اثر دارد.",
            { Prefs.driveLive(this) }, { Prefs.setDriveLive(this, it); if (it) DriveOcr.resetRun() })
        row("زبان تشخیص متن", { ocrLangSummary() }) { chooseOcrLang() }
        row("مدل تشخیص متن", { if (Prefs.ocrModel(this) == "best") "دقیق (کندتر)" else "سریع" }) {
            val values = listOf("best", "fast")
            choose("مدل تشخیص متن", listOf("دقیق (کندتر)", "سریع"),
                values.indexOf(Prefs.ocrModel(this)).coerceAtLeast(0)) { i ->
                Prefs.setOcrModel(this, values[i])
            }
        }
        row("افزودن فایل زبان OCR", { ocrSummary() }) { pickOcrData.launch(arrayOf("*/*")) }

        buildSpeechRows()
        buildTranslateRows()
    }


    // ---------- subtitle from the film's sound (Whisper) ----------

    private val threadsList = (1..8).toList()

    private fun buildSpeechRows() {
        header("ساخت زیرنویس از صدای فیلم (Whisper)")
        row("مدل فعال", { modelSummary() }) { chooseModel() }
        row("دانلود مدل", { "دانلود مستقیم مدل Whisper (نیاز به اینترنت)" }) { downloadModels() }
        row("افزودن فایل مدل", { "فایل ggml را از حافظه‌ی گوشی انتخاب کنید" }) { pickModel.launch(arrayOf("*/*")) }
        row("حذف یک مدل", { "پاک کردن مدل‌های اضافه‌شده" }) { deleteModel() }
        row("راهنمای دریافت مدل", { "کدام مدل را بگیرم" }) {
            AlertDialog.Builder(this).setTitle("دریافت مدل").setMessage(MODEL_HELP).setPositiveButton("بستن", null).show()
        }
        row("زبان گفتار فیلم", { speechLangSummary() }) { chooseSpeechLang() }
        row("تعداد هسته‌های پردازنده", { Prefs.threads(this).toString() + " (بیشتر = سریع‌تر ولی گوشی داغ‌تر)" }) {
            choose("تعداد هسته‌ها", threadsList.map { it.toString() }, threadsList.indexOf(Prefs.threads(this)).coerceAtLeast(0)) {
                Prefs.setThreads(this, threadsList[it])
            }
        }
    }

    private fun modelSummary(): String {
        val m = Prefs.modelFile(this) ?: return "هیچ مدلی اضافه نشده است"
        return m.name + " (" + (m.length() / (1024 * 1024)) + " مگابایت)"
    }

    private fun chooseModel() {
        val all = Prefs.models(this)
        if (all.isEmpty()) { tell("ابتدا یک مدل اضافه کنید"); return }
        val cur = all.indexOf(Prefs.modelFile(this)).coerceAtLeast(0)
        choose("مدل فعال", all.map { it.name }, cur) { Prefs.setModel(this, all[it].name) }
    }

    private fun deleteModel() {
        val all = Prefs.models(this)
        if (all.isEmpty()) { tell("مدلی برای حذف نیست"); return }
        AlertDialog.Builder(this)
            .setTitle("کدام مدل حذف شود؟")
            .setItems(all.map { it.name }.toTypedArray()) { _, i ->
                try { all[i].delete() } catch (ignored: Exception) {}
                refreshAll()
            }
            .setNegativeButton("بستن", null)
            .show()
    }

    private fun downloadModels() {
        val have = Prefs.models(this).map { it.name }.toSet()
        val labels = ModelDownload.items.map {
            val st = if (it.file in have) "نصب شده" else if (File(Prefs.modelsDir(this), it.file + ".part").exists()) "نیمه‌کاره" else "نصب نشده"
            it.title + " (حدود " + it.mb + " مگابایت) - " + it.note + " - " + st
        }
        AlertDialog.Builder(this)
            .setTitle("دانلود مدل")
            .setItems(labels.toTypedArray()) { _, i ->
                val it = ModelDownload.items[i]
                if (it.file in have) {
                    Prefs.setModel(this, it.file)
                    refreshAll()
                    tell("این مدل فعال شد")
                } else {
                    AlertDialog.Builder(this)
                        .setTitle(it.title)
                        .setMessage("حجم دانلود حدود " + it.mb + " مگابایت است. اگر با اینترنت گوشی هستید حجم مصرف می‌شود. ادامه می‌دهید؟")
                        .setPositiveButton("دانلود") { _, _ -> startModelDownload(it) }
                        .setNegativeButton("انصراف", null)
                        .show()
                }
            }
            .setNegativeButton("بستن", null)
            .show()
    }

    private fun startModelDownload(item: ModelDownload.Item) {
        val cancel = AtomicBoolean(false)
        val msg = TextView(this).apply {
            text = "در حال شروع…"
            setPadding(dp(24), dp(16), dp(24), dp(16))
            textSize = 16f
            accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        }
        val dlg = AlertDialog.Builder(this)
            .setTitle("دانلود " + item.title)
            .setView(msg)
            .setCancelable(false)
            .setNegativeButton("لغو") { _, _ -> cancel.set(true) }
            .show()
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        Thread {
            var lastPct = -10L
            val err = ModelDownload.download(Prefs.modelsDir(this), item.file, cancel) { done, total ->
                val mb = done / (1024 * 1024)
                val t = if (total > 0) {
                    " از " + (total / (1024 * 1024)) + " مگابایت (" + (done * 100 / total) + " درصد)"
                } else " مگابایت"
                val pct = if (total > 0) done * 100 / total else -1L
                // a screen reader reads the text each time it changes, so it is updated every 10 percent only
                if (total <= 0 || pct >= lastPct + 10 || pct == 100L) {
                    lastPct = pct
                    runOnUiThread { msg.text = "دانلود شده: $mb$t\nصفحه را نبندید تا دانلود تمام شود." }
                }
            }
            runOnUiThread {
                window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                try { dlg.dismiss() } catch (ignored: Exception) {}
                if (err == null) {
                    Prefs.setModel(this, item.file)
                    tell("مدل دانلود شد و فعال شد")
                } else {
                    tell(err)
                }
                refreshAll()
            }
        }.start()
    }

    private fun importModel(u: Uri) {
        var name = SpeechStore.displayName(this, u).replace(Regex("[^A-Za-z0-9._-]"), "_")
        if (!name.endsWith(".bin")) name += ".bin"
        val dest = File(Prefs.modelsDir(this), name)
        val msg = TextView(this).apply {
            text = "در حال کپی مدل…"
            setPadding(dp(24), dp(16), dp(24), dp(16))
            textSize = 16f
        }
        val dlg = AlertDialog.Builder(this).setTitle("افزودن مدل").setView(msg).setCancelable(false).show()
        Thread {
            var ok = false
            var magicOk = true
            try {
                contentResolver.openInputStream(u)?.use { ins ->
                    dest.outputStream().use { out ->
                        val buf = ByteArray(1 shl 20)
                        var first = true
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            if (first) {
                                first = false
                                magicOk = n >= 4 && buf[0] == 'l'.code.toByte() && buf[1] == 'm'.code.toByte() &&
                                    buf[2] == 'g'.code.toByte() && buf[3] == 'g'.code.toByte()
                            }
                            out.write(buf, 0, n)
                        }
                    }
                    ok = true
                }
            } catch (e: Exception) {
                ok = false
            }
            if (!ok) { try { dest.delete() } catch (ignored: Exception) {} }
            runOnUiThread {
                dlg.dismiss()
                if (ok) {
                    Prefs.setModel(this, dest.name)
                    tell(if (magicOk) "مدل اضافه شد و فعال شد" else "مدل اضافه شد، ولی شبیه مدل ggml از whisper.cpp نیست؛ اگر ساخت زیرنویس شروع نشد فایل دیگری بگیرید")
                } else {
                    tell("افزودن مدل ناموفق بود (شاید جای خالی کافی نیست)")
                }
                refreshAll()
            }
        }.start()
    }

    private fun speechLangSummary(): String {
        val l = Prefs.lang(this)
        return if (l == "auto") "تشخیص خودکار" else Langs.name(l)
    }

    private fun chooseSpeechLang() {
        val codes = listOf("auto") + Langs.list.map { it.first }
        val labels = listOf("تشخیص خودکار") + Langs.list.map { it.second }
        choose("زبان گفتار فیلم", labels, codes.indexOf(Prefs.lang(this)).coerceAtLeast(0)) { Prefs.setLang(this, codes[it]) }
    }


    // ---------- subtitle translation ----------

    private fun buildTranslateRows() {
        header("ترجمه‌ی زیرنویس")
        row("زبان ترجمه", { Langs.name(Prefs.targetLang(this)) }) {
            val codes = Langs.list.filter { Translator.supported(it.first) }
            choose("ترجمه به کدام زبان؟", codes.map { it.second }, codes.indexOfFirst { it.first == Prefs.targetLang(this) }.coerceAtLeast(0)) {
                Prefs.setTargetLang(this, codes[it].first)
            }
        }
        row("روش ترجمه", {
            when (Prefs.translateMode(this)) {
                "online" -> "آنلاین گوگل (اگر خطا داد، آفلاین)"
                "gemini" -> "Gemini با کلید شما (اگر خطا داد، آفلاین)"
                else -> "آفلاین (روی گوشی)"
            }
        }) {
            val labels = listOf(
                "آفلاین: روی گوشی و بدون اینترنت؛ کیفیت ساده‌تر",
                "آنلاین گوگل: بدون کلید؛ متن زیرنویس به سرور گوگل فرستاده می‌شود. اگر خطا داد خودکار آفلاین می‌شود",
                "Gemini: بهترین کیفیت؛ نیاز به کلید API خودتان از Google AI Studio دارد. متن زیرنویس به گوگل فرستاده می‌شود. اگر خطا داد آفلاین می‌شود"
            )
            val modes = listOf("offline", "online", "gemini")
            choose("روش ترجمه", labels, modes.indexOf(Prefs.translateMode(this)).coerceAtLeast(0)) {
                Prefs.setTranslateMode(this, modes[it])
                if (modes[it] == "gemini" && Prefs.geminiKey(this).isBlank()) tell("کلید Gemini را از ردیف «کلید Gemini» وارد کنید")
            }
        }
        row("کلید Gemini", { if (Prefs.geminiKey(this).isBlank()) "وارد نشده (از aistudio.google.com بگیرید)" else "وارد شده (…" + Prefs.geminiKey(this).takeLast(4) + ")" }) {
            askText("کلید Gemini", "کلید API را اینجا بچسبانید", Prefs.geminiKey(this)) { Prefs.setGeminiKey(this, it); refreshAll() }
        }
        row("مدل Gemini", { Prefs.geminiModel(this) }) {
            askText("اسم مدل Gemini", GeminiTranslator.DEFAULT_MODEL, Prefs.geminiModel(this)) {
                Prefs.setGeminiModel(this, it.ifBlank { GeminiTranslator.DEFAULT_MODEL }); refreshAll()
            }
        }
        row("آزمایش ترجمه با Gemini", { "یک جمله‌ی کوتاه ترجمه می‌شود تا کلید و مدل بررسی شود" }) { testGemini() }
        row("مدل‌های ترجمه‌ی آفلاین", { "دانلود یک‌باره‌ی مدل هر زبان (نیاز به اینترنت)" }) { translationModels() }
    }

    private fun askText(title: String, hint: String, current: String, onOk: (String) -> Unit) {
        val et = android.widget.EditText(this).apply {
            setText(current)
            this.hint = hint
            setSingleLine(true)
            textDirection = View.TEXT_DIRECTION_LTR
        }
        val holder = LinearLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(et, LinearLayout.LayoutParams(-1, -2))
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(holder)
            .setPositiveButton("ذخیره") { _, _ -> onOk(et.text.toString().trim()) }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun testGemini() {
        val key = Prefs.geminiKey(this)
        if (key.isBlank()) { tell("اول کلید Gemini را وارد کنید"); return }
        tell("در حال آزمایش…")
        val target = Prefs.targetLang(this)
        val model = Prefs.geminiModel(this)
        Thread {
            val r = GeminiTranslator.translate(listOf("Hello, how are you today?"), "en", target, key, model)
            runOnUiThread {
                if (r != null) tell("کار می‌کند. نمونه: " + r[0]) else tell("ناموفق: " + (GeminiTranslator.lastError ?: "نامشخص"))
            }
        }.start()
    }

    private fun translationModels() {
        tell("در حال بررسی مدل‌های نصب‌شده…")
        Thread {
            val status = Langs.list.map { Translator.isDownloaded(it.first) }
            runOnUiThread { if (!isFinishing) showTranslationList(status) }
        }.start()
    }

    private fun showTranslationList(status: List<Boolean>) {
        val labels = Langs.list.mapIndexed { i, p ->
            val note = if (p.first == Prefs.targetLang(this)) " (زبان ترجمه‌ی انتخابی)" else if (p.first == "en") " (برای زبان‌های غیرانگلیسی هم لازم است)" else ""
            p.second + note + " - " + (if (status[i]) "نصب شده" else "نصب نشده")
        }
        AlertDialog.Builder(this)
            .setTitle("مدل‌های ترجمه")
            .setItems(labels.toTypedArray()) { _, i ->
                val code = Langs.list[i].first
                if (status[i]) {
                    Translator.delete(code) { ok ->
                        tell(if (ok) "مدل حذف شد" else "حذف مدل ناموفق بود")
                        translationModels()
                    }
                } else {
                    tell("در حال دانلود مدل " + Langs.list[i].second + "… اینترنت لازم است")
                    Translator.download(code) { ok ->
                        tell(if (ok) "مدل دانلود شد" else "دانلود مدل ناموفق بود؛ اینترنت را بررسی کنید")
                        translationModels()
                    }
                }
            }
            .setNegativeButton("بستن", null)
            .show()
    }

    // ---------- speech engine ----------

    private fun engineLabel(pkg: String?): String {
        if (pkg == null) return "پیش‌فرض گوشی"
        val e = tts?.engines?.firstOrNull { it.name == pkg }
        return e?.label?.toString() ?: pkg
    }

    private fun engineSummary(): String {
        val lang = when (persian) {
            true -> "دارد"
            false -> "موتور اجرا نشد"
            null -> if (ttsReady) "نامشخص" else "در حال بررسی"
        }
        return engineLabel(Prefs.engine(this)) + "\nصدای فارسی: " + lang
    }

    private fun chooseEngine() {
        val list = tts?.engines ?: emptyList()
        if (list.isEmpty()) {
            tell("موتور گفتاری پیدا نشد")
            return
        }
        val names = ArrayList<String?>()
        val labels = ArrayList<String>()
        names.add(null); labels.add("پیش‌فرض گوشی")
        for (e in list) { names.add(e.name); labels.add(e.label.toString()) }
        val current = names.indexOf(Prefs.engine(this)).coerceAtLeast(0)
        choose("موتور گفتار", labels, current) { i ->
            Prefs.setEngine(this, names[i])
            restartTts()
        }
    }

    private fun restartTts() {
        ttsReady = false
        persian = null
        tts?.shutdown()
        tts = TextToSpeech(this, this, Prefs.engine(this))
        refreshAll()
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) {
            if (Prefs.engine(this) != null) {
                Prefs.setEngine(this, null)
                tell("این موتور گفتار اجرا نشد. موتور پیش‌فرض گوشی استفاده می‌شود")
                restartTts()
                return
            }
            ttsReady = false
            persian = false
            refreshAll()
            tell("موتور گفتار اجرا نشد")
            return
        }
        // Some engines (eSpeak for example) do not report Persian but still read it with the voice
        // set in their own settings, so "not reported" is not treated as an error.
        persian = if (TtsUtil.usePersian(t)) true else null
        t.setSpeechRate(Prefs.rate(this))
        ttsReady = true
        refreshAll()
    }

    private fun speakTest(msg: String) {
        val t = tts
        if (t == null || !ttsReady) {
            tell("موتور گفتار آماده نیست")
            return
        }
        t.setSpeechRate(Prefs.rate(this))
        val params = Bundle().apply {
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, Prefs.volume(this@SettingsActivity))
        }
        t.speak(msg, TextToSpeech.QUEUE_FLUSH, params, "test")
    }

    private fun launch(i: Intent): Boolean = try { startActivity(i); true } catch (e: Exception) { false }

    private fun installVoice() {
        if (!launch(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)))
            tell("نصب صدا ممکن نیست")
    }

    private fun openSystemTts() {
        if (!launch(Intent("com.android.settings.TTS_SETTINGS")) && !launch(Intent(Settings.ACTION_SETTINGS)))
            tell("باز کردن تنظیمات گوشی ممکن نشد")
    }

    // ---------- OCR ----------

    private fun langName(code: String) = when (code) {
        "fas" -> "فارسی"
        "eng" -> "انگلیسی"
        "ara" -> "عربی"
        else -> code
    }

    private fun ocrSummary(): String {
        val l = ocr.installed()
        return if (l.isEmpty()) "هیچ فایل زبانی نصب نیست"
        else "نصب‌شده: " + l.joinToString("، ") { langName(it) }
    }

    private fun ocrLangSummary(): String {
        val p = Prefs.ocrLang(this)
        return if (p == "all") "همه‌ی نصب‌شده‌ها" else langName(p)
    }

    private fun ocrEngineSummary(): String =
        if (Prefs.ocrEngine(this) == "drive") "آفلاین + گوگل‌درایو (آنلاین) هنگام ساختن فایل زیرنویس از فیلم"
        else "فقط آفلاین (Tesseract)"

    private fun chooseOcrEngine() {
        val labels = listOf("فقط آفلاین (Tesseract)", "آفلاین + گوگل‌درایو (آنلاین، دقیق‌تر و کندتر)")
        choose("موتور تشخیص متن", labels, if (Prefs.ocrEngine(this) == "drive") 1 else 0) { i ->
            if (i == 0) {
                Prefs.setOcrEngine(this, "tess")
            } else {
                AlertDialog.Builder(this)
                    .setMessage("هنگام ساختن فایل زیرنویس از فیلم، تصویر هر زیرنویس به صورت موقت در گوگل‌درایوِ خودتان بارگذاری، با گوگل خوانده و بلافاصله پاک می‌شود. به اینترنت و ورود با حساب گوگل نیاز دارد و ساخت زیرنویس کندتر می‌شود. خواندن زنده‌ی زیرنویس هنگام پخش همچنان آفلاین است. ادامه می‌دهید؟")
                    .setPositiveButton("بله") { _, _ -> enableDrive() }
                    .setNegativeButton("خیر", null)
                    .show()
            }
        }
    }

    private fun enableDrive() {
        Identity.getAuthorizationClient(this).authorize(DriveOcr.request())
            .addOnSuccessListener { res ->
                val pi = res.pendingIntent
                if (res.hasResolution() && pi != null) {
                    authLauncher.launch(IntentSenderRequest.Builder(pi.intentSender).build())
                } else {
                    Prefs.setOcrEngine(this, "drive")
                    DriveOcr.resetRun()
                    tell("ورود به گوگل‌درایو انجام شد")
                    refreshAll()
                }
            }
            .addOnFailureListener {
                tell("ورود به گوگل ممکن نیست. اینترنت، سرویس‌های گوگل‌پلی و ثبت پروژه در گوگل را بررسی کنید")
            }
    }

    private fun chooseOcrLang() {
        val installed = ocr.installed()
        val values = ArrayList<String>()
        val labels = ArrayList<String>()
        values.add("all"); labels.add("همه‌ی نصب‌شده‌ها")
        for (l in installed) { values.add(l); labels.add(langName(l)) }
        choose("زبان تشخیص متن", labels, values.indexOf(Prefs.ocrLang(this)).coerceAtLeast(0)) { i ->
            Prefs.setOcrLang(this, values[i])
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        ocr.release()
        super.onDestroy()
    }
}
