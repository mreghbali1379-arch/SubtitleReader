package com.example.subtitlereader

import android.content.Context

/**
 * Translates a whole subtitle (every line, timing kept). Methods: Gemini (many lines per request), Google online,
 * or ML Kit on the phone. When an online method fails, the offline models are used for the rest.
 */
class SubtitleTranslator(
    private val context: Context,
    private val cues: List<SubtitleFormats.Cue>,
    private val src: String,
    private val target: String,
    private val mode: String
) {
    @Volatile private var cancelled = false
    @Volatile var error: String? = null
        private set
    /** Lines that could not be translated and were kept in the original language. */
    @Volatile var untranslated = 0
        private set

    fun cancel() { cancelled = true }

    private var session: Translator.Session? = null
    private var offlineChecked = false
    private var offlineOk = false
    private var geminiOff = mode != "gemini"
    private var geminiFails = 0
    private var onlineOff = mode != "online"
    private var onlineFails = 0
    private var offlineNote: String? = null

    private fun offline(text: String): String? {
        if (!offlineChecked) {
            offlineChecked = true
            if (src == "auto") {
                offlineNote = "ترجمه‌ی آفلاین زبان زیرنویس را باید بداند؛ زبان زیرنویس را انتخاب کنید"
            } else if (Translator.ready(src, target)) {
                session = Translator.Session(src, target)
                offlineOk = true
            } else {
                offlineNote = "مدل ترجمه‌ی " + Langs.name(src) + " یا " + Langs.name(target) +
                    " نصب نیست. از تنظیمات، بخش «ترجمه‌ی زیرنویس»، «مدل‌های ترجمه» را دانلود کنید (برای زبان‌های غیرانگلیسی مدل انگلیسی هم لازم است)"
            }
        }
        if (!offlineOk) return null
        return session?.translate(text)
    }

    private fun line(text: String): String? {
        if (text.isBlank()) return text
        if (!onlineOff) {
            val r = OnlineTranslator.translate(text, src, target)
            if (r != null) { onlineFails = 0; return r }
            onlineFails++
            if (onlineFails >= 3) onlineOff = true
        }
        return offline(text)
    }

    /** [onProgress] gets (percent, message). Returns the translated lines, or null when stopped or failed ([error] says why). */
    fun run(onProgress: (Int, String) -> Unit): List<SubtitleFormats.Cue>? {
        val n = cues.size
        val out = ArrayList<SubtitleFormats.Cue>(n)
        var failedRow = 0
        try {
            var i = 0
            while (i < n) {
                if (cancelled) return null
                val end = minOf(n, i + 30)
                val batch = cues.subList(i, end)
                var got: List<String>? = null
                if (!geminiOff) {
                    got = GeminiTranslator.translate(batch.map { it.text }, src, target, Prefs.geminiKey(context), Prefs.geminiModel(context))
                    if (got != null) {
                        geminiFails = 0
                    } else {
                        geminiFails++
                        onProgress(i * 100 / n, "ترجمه با Gemini انجام نشد: " + (GeminiTranslator.lastError ?: "نامشخص") +
                            (if (geminiFails >= 2) "؛ از روش بعدی استفاده می‌شود" else ""))
                        if (geminiFails >= 2) { geminiOff = true; if (mode == "gemini") onlineOff = true }
                    }
                }
                for ((k, c) in batch.withIndex()) {
                    if (cancelled) return null
                    val t = got?.get(k) ?: line(c.text)
                    if (t == null) {
                        untranslated++
                        failedRow++
                        out.add(c)
                        if (failedRow >= 5 && geminiOff && onlineOff && !offlineOk) {
                            error = offlineNote ?: "ترجمه انجام نشد"
                            return null
                        }
                        if (failedRow >= 5 && offlineOk) {
                            error = "ترجمه انجام نشد: " + (session?.lastError ?: "نامشخص")
                            return null
                        }
                    } else {
                        failedRow = 0
                        out.add(SubtitleFormats.Cue(c.start, c.end, t))
                    }
                    if (k % 10 == 9) onProgress((i + k + 1) * 100 / n, "")
                }
                onProgress(end * 100 / n, "")
                i = end
            }
            return out
        } catch (e: Throwable) {
            error = "خطا: " + (e.message ?: e.javaClass.simpleName)
            return null
        } finally {
            try { session?.close() } catch (ignored: Throwable) {}
        }
    }
}
