package com.example.subtitlereader

import android.content.Context

/**
 * Translates a whole subtitle (every line, timing kept). Methods: Gemini, Google online or ML Kit on the phone; each one gets the
 * WHOLE subtitle as one text and gives the whole translation back once. Only if that does not work (too big, a line lost) is the
 * text halved and tried again, and single lines are the last resort. When an online method fails, the offline models are used.
 */
class Bulk(val text: String?, val fatal: Boolean = false)

class SubtitleTranslator(
    private val context: Context,
    private val cues: List<SubtitleFormats.Cue>,
    private val src: String,
    private val target: String,
    private val mode: String
) {
    @Volatile private var cancelled = false
    @Volatile var error: String? = null
        private set
    /** Lines that could not be translated and were kept in the original language. */
    @Volatile var untranslated = 0
        private set

    @Volatile private var workerThread: Thread? = null
    @Volatile private var interruptible = false

    fun cancel() {
        cancelled = true
        GeminiTranslator.abort()
        OnlineTranslator.abort()
        if (interruptible) workerThread?.interrupt()   // an offline translation of the whole text can be long
    }

    private var session: Translator.Session? = null
    private var offlineChecked = false
    private var offlineOk = false
    private var geminiOff = mode != "gemini"
    private var onlineOff = mode != "online"
    private var onlineFails = 0
    private var offlineNote: String? = null

    private fun ensureOffline(): Boolean {
        if (!offlineChecked) {
            offlineChecked = true
            if (src == "auto") {
                offlineNote = "ترجمه‌ی آفلاین زبان زیرنویس را باید بداند؛ زبان زیرنویس را انتخاب کنید"
            } else if (Translator.ready(src, target)) {
                session = Translator.Session(src, target)
                offlineOk = true
            } else {
                offlineNote = "مدل ترجمه‌ی " + Langs.name(src) + " یا " + Langs.name(target) +
                    " نصب نیست. از تنظیمات، بخش «ترجمه‌ی زیرنویس»، «مدل‌های ترجمه» را دانلود کنید (برای زبان‌های غیرانگلیسی مدل انگلیسی هم لازم است)"
            }
        }
        return offlineOk
    }

    private fun offline(text: String): String? {
        if (!ensureOffline()) return null
        return session?.translate(text)
    }

    private fun line(text: String): String? {
        if (text.isBlank()) return text
        if (!onlineOff) {
            val r = OnlineTranslator.translate(text, src, target)
            if (r != null) { onlineFails = 0; return r }
            onlineFails++
            if (onlineFails >= 3) onlineOff = true
        }
        return offline(text)
    }

    // ---- one text for everything -------------------------------------------------------------------------------

    private var bulkStop = false
    private var bulkSends = 0
    private var bulkDone = 0
    private var bulkTotal = 0

    /** Sends texts[lo, hi) as one text (one line each). If that fails or comes back with another number of lines, halves it. */
    private fun bulkRange(
        texts: List<String>, lo: Int, hi: Int, out: Array<String?>,
        send: (String) -> Bulk, onProgress: (Int, String) -> Unit
    ) {
        if (cancelled || bulkStop || hi <= lo) return
        if (++bulkSends > 80) { bulkStop = true; return }   // a text that keeps coming back wrong: the rest goes line by line
        val r = send(texts.subList(lo, hi).joinToString("\n"))
        if (cancelled) return
        if (r.fatal) { bulkStop = true; return }
        val t = r.text
        if (t != null) {
            val parts = t.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
            if (parts.size == hi - lo) {
                for (k in parts.indices) out[lo + k] = parts[k]
                bulkDone += hi - lo
                onProgress(minOf(95, bulkDone * 95 / maxOf(1, bulkTotal)), "")
                return
            }
        }
        if (hi - lo <= 8) return            // too small to split further: the single-line path takes these
        val mid = (lo + hi) / 2
        bulkRange(texts, lo, mid, out, send, onProgress)
        bulkRange(texts, mid, hi, out, send, onProgress)
    }

    /** Lines of [pending] cues are sent as one text; what comes back is put in [tr]. Returns false if the sender said stop (Google limiting us). */
    private fun bulkPhase(pending: List<Int>, tr: Array<String?>, send: (String) -> Bulk, onProgress: (Int, String) -> Unit): Boolean {
        class Flat(val cue: Int, val k: Int, val text: String)
        val perCue = HashMap<Int, Array<String?>>()
        val flat = ArrayList<Flat>()
        for (i in pending) {
            val lines = cues[i].text.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
            val arr = arrayOfNulls<String>(lines.size)
            for ((k, l) in lines.withIndex()) {
                if (l.any { it.isLetter() }) flat.add(Flat(i, k, l)) else arr[k] = l   // "♪", "...", "-" stay as they are
            }
            perCue[i] = arr
        }
        val outLines = arrayOfNulls<String>(flat.size)
        bulkStop = false; bulkSends = 0; bulkDone = 0; bulkTotal = flat.size
        bulkRange(flat.map { it.text }, 0, flat.size, outLines, send, onProgress)
        for ((j, f) in flat.withIndex()) perCue[f.cue]!![f.k] = outLines[j]
        for (i in pending) {
            val arr = perCue[i] ?: continue
            if (arr.all { it != null }) tr[i] = arr.joinToString("\n")
        }
        return !bulkStop
    }

    private fun pendingList(tr: Array<String?>): List<Int> =
        cues.indices.filter { tr[it] == null && cues[it].text.isNotBlank() }

    /** [onProgress] gets (percent, message). Returns the translated lines, or null when stopped or failed ([error] says why). */
    fun run(onProgress: (Int, String) -> Unit): List<SubtitleFormats.Cue>? {
        val n = cues.size
        val out = ArrayList<SubtitleFormats.Cue>(n)
        val tr = arrayOfNulls<String>(n)
        var failedRow = 0
        workerThread = Thread.currentThread()
        try {
            // 1. Gemini: the whole subtitle in one request, the whole translation back once
            if (!geminiOff) {
                val items = ArrayList<Pair<Int, String>>()
                for ((i, c) in cues.withIndex()) if (c.text.isNotBlank()) items.add(Pair(i, c.text))
                val key = Prefs.geminiKey(context)
                val model = Prefs.geminiModel(context)
                onProgress(0, "کل زیرنویس یک‌جا برای Gemini فرستاده شد؛ منتظر ترجمه… (برای فیلم بلند چند دقیقه طول می‌کشد)")
                val first = GeminiTranslator.translateAll(items, src, target, key, model) { cancelled }
                if (cancelled) return null
                val got = HashMap<Int, String>()
                if (first == null) {
                    onProgress(0, "ترجمه با Gemini انجام نشد: " + (GeminiTranslator.lastError ?: "نامشخص") + "؛ از روش بعدی استفاده می‌شود")
                    geminiOff = true
                } else {
                    got.putAll(first)
                    val missing = items.filter { !got.containsKey(it.first) }
                    if (missing.isNotEmpty()) {
                        onProgress(0, "" + missing.size + " خط در جواب Gemini جا افتاده بود؛ فقط همین خط‌ها دوباره فرستاده می‌شود…")
                        val second = GeminiTranslator.translateAll(missing, src, target, key, model) { cancelled }
                        if (cancelled) return null
                        if (second != null) got.putAll(second)
                    }
                }
                for ((i, t) in got) if (i in 0 until n) tr[i] = t
            }

            // 2. Google online: the whole text in one request (halved only if that does not work)
            if (!onlineOff) {
                val pending = pendingList(tr)
                if (pending.isNotEmpty()) {
                    onProgress(0, "کل زیرنویس یک‌جا برای ترجمه‌ی گوگل فرستاده شد…")
                    val ok = bulkPhase(pending, tr, { OnlineTranslator.translateBlock(it, src, target) }, onProgress)
                    if (cancelled) return null
                    if (!ok) {
                        onlineOff = true
                        onProgress(0, "ترجمه‌ی گوگل ادامه پیدا نکرد: " + (OnlineTranslator.lastError ?: "نامشخص") + "؛ از روش بعدی استفاده می‌شود")
                    }
                }
            }

            // 3. on the phone (ML Kit): the whole text in one go
            val pendingOff = pendingList(tr)
            if (pendingOff.isNotEmpty() && ensureOffline()) {
                onProgress(0, "کل زیرنویس یک‌جا با ترجمه‌ی آفلاین گوشی ترجمه می‌شود… (چند دقیقه طول می‌کشد)")
                interruptible = true
                try {
                    bulkPhase(pendingOff, tr, { val r = session?.translate(it, 1200); Bulk(r, r == null) }, onProgress)
                } finally {
                    interruptible = false
                }
                if (cancelled) return null
            }

            // 4. whatever is still missing: line by line
            val stragglers = maxOf(1, pendingList(tr).size)
            var done = 0
            for ((i, c) in cues.withIndex()) {
                if (cancelled) return null
                var t = tr[i]
                if (t == null) {
                    t = line(c.text)
                    if (c.text.isNotBlank()) { done++; if (done % 10 == 0) onProgress(95 + minOf(5, done * 5 / stragglers), "") }
                }
                if (t == null) {
                    untranslated++
                    failedRow++
                    out.add(c)
                    if (failedRow >= 5 && geminiOff && onlineOff && !offlineOk) {
                        error = offlineNote ?: "ترجمه انجام نشد"
                        return null
                    }
                    if (failedRow >= 5 && offlineOk) {
                        error = "ترجمه انجام نشد: " + (session?.lastError ?: "نامشخص")
                        return null
                    }
                } else {
                    failedRow = 0
                    out.add(SubtitleFormats.Cue(c.start, c.end, t))
                }
            }
            onProgress(100, "")
            return out
        } catch (e: Throwable) {
            error = "خطا: " + (e.message ?: e.javaClass.simpleName)
            return null
        } finally {
            try { session?.close() } catch (ignored: Throwable) {}
        }
    }
}
