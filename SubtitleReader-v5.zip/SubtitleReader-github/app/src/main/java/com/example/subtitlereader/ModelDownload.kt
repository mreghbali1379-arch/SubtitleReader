package com.example.subtitlereader

import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

/** Whisper models that can be downloaded from inside the app (ggerganov/whisper.cpp on Hugging Face). */
object ModelDownload {
    class Item(val file: String, val title: String, val mb: Int, val note: String)

    val items = listOf(
        Item("ggml-base-q5_1.bin", "Base", 60, "سریع، دقت کم‌تر؛ برای گوشی ضعیف"),
        Item("ggml-small-q5_1.bin", "Small", 190, "تعادل خوب؛ پیشنهاد برای شروع"),
        Item("ggml-medium-q5_0.bin", "Medium", 540, "دقیق ولی کندتر"),
        Item("ggml-large-v3-turbo-q5_0.bin", "Large v3 Turbo", 575, "بهترین دقت؛ برای گوشی قوی")
    )

    private fun url(file: String) = "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/$file"

    /**
     * Downloads [file] into [dir]. Continues an interrupted download (the unfinished part is kept as .part).
     * Returns null on success, otherwise a Persian message. [onProgress] gets (bytes so far, total bytes or -1).
     */
    fun download(dir: File, file: String, cancel: AtomicBoolean, onProgress: (Long, Long) -> Unit): String? {
        val dest = File(dir, file)
        val part = File(dir, "$file.part")
        var conn: HttpURLConnection? = null
        try {
            var have = if (part.exists()) part.length() else 0L
            conn = URL(url(file)).openConnection() as HttpURLConnection
            conn.connectTimeout = 20000
            conn.readTimeout = 30000
            conn.instanceFollowRedirects = true
            if (have > 0) conn.setRequestProperty("Range", "bytes=$have-")
            val code = conn.responseCode
            if (code == 416) { part.delete(); return "دانلود ناقص بود؛ دوباره امتحان کنید" }
            if (code != 200 && code != 206) return "سرور جواب نداد (کد $code)؛ اینترنت را بررسی کنید"
            if (code == 200) have = 0L
            val len = conn.contentLengthLong
            val total = if (len > 0) have + len else -1L
            RandomAccessFile(part, "rw").use { raf ->
                if (code == 206) raf.seek(have) else raf.setLength(0)
                conn.inputStream.use { ins ->
                    val buf = ByteArray(1 shl 16)
                    var done = have
                    var last = 0L
                    while (true) {
                        if (cancel.get()) return "دانلود لغو شد (می‌توانید بعداً ادامه دهید)"
                        val n = ins.read(buf)
                        if (n < 0) break
                        raf.write(buf, 0, n)
                        done += n
                        val now = System.currentTimeMillis()
                        if (now - last > 400) { last = now; onProgress(done, total) }
                    }
                    onProgress(done, total)
                }
            }
            if (total > 0 && part.length() != total) return "دانلود کامل نشد؛ دوباره امتحان کنید تا ادامه پیدا کند"
            val ok = part.inputStream().use { s ->
                val h = ByteArray(4)
                s.read(h) == 4 && h[0] == 'l'.code.toByte() && h[1] == 'm'.code.toByte() &&
                    h[2] == 'g'.code.toByte() && h[3] == 'g'.code.toByte()
            }
            if (!ok) { part.delete(); return "فایل دانلودشده مدل معتبر نبود" }
            if (dest.exists()) dest.delete()
            if (!part.renameTo(dest)) return "ذخیره‌ی مدل ناموفق بود (شاید جای خالی کافی نیست)"
            return null
        } catch (e: Exception) {
            return "دانلود قطع شد: " + (e.message ?: e.javaClass.simpleName) + " — دوباره بزنید تا ادامه پیدا کند"
        } finally {
            try { conn?.disconnect() } catch (ignored: Exception) {}
        }
    }
}
