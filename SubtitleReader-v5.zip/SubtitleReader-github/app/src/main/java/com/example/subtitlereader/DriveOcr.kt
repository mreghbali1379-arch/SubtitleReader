package com.example.subtitlereader

import android.content.Context
import android.graphics.Bitmap
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.Tasks
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit
import kotlin.math.max

/**
 * Optional online OCR: a picture is uploaded to the user's own Google Drive and converted to a Google Doc
 * (Google does the OCR while converting), the text is exported and the temporary file is deleted.
 * Only the drive.file permission is used, so the app can see just the files it creates.
 * Every function here blocks on the network: call them from a background thread only.
 */
object DriveOcr {
    private const val SCOPE = "https://www.googleapis.com/auth/drive.file"
    private const val API = "https://www.googleapis.com"

    class Unauthorized : Exception()

    @Volatile private var token: String? = null
    @Volatile private var tokenAt = 0L
    @Volatile private var fails = 0

    fun request(): AuthorizationRequest =
        AuthorizationRequest.builder().setRequestedScopes(listOf(Scope(SCOPE))).build()

    /** Forget the saved token and the failure count (call at the start of every conversion). */
    fun resetRun() { token = null; tokenAt = 0L; fails = 0 }

    /** Access token for background work. Null when the user has not signed in yet or Google services are missing. */
    private fun tokenBlocking(c: Context): String? = try {
        val r = Tasks.await(Identity.getAuthorizationClient(c).authorize(request()), 20, TimeUnit.SECONDS)
        if (r.hasResolution()) null else r.accessToken
    } catch (e: Exception) { null }

    @Synchronized private fun session(c: Context): String? {
        val t = token
        if (t != null && System.currentTimeMillis() - tokenAt < 45 * 60 * 1000L) return t
        val n = tokenBlocking(c)
        token = n
        tokenAt = System.currentTimeMillis()
        return n
    }

    private fun open(url: String, tok: String, method: String): HttpURLConnection {
        val con = URL(url).openConnection() as HttpURLConnection
        con.requestMethod = method
        con.setRequestProperty("Authorization", "Bearer $tok")
        con.connectTimeout = 20000
        con.readTimeout = 90000
        return con
    }

    private fun compress(b: Bitmap, q: Int): ByteArray {
        val o = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, q, o)
        return o.toByteArray()
    }

    private fun toJpeg(src: Bitmap): ByteArray {
        var b = src
        val m = max(src.width, src.height)
        val shrink = m > 2200
        if (shrink) {
            val f = 2200f / m
            b = Bitmap.createScaledBitmap(src, (src.width * f).toInt(), (src.height * f).toInt(), true)
        }
        var q = 88
        var out = compress(b, q)
        while (out.size > 1_800_000 && q > 40) { q -= 15; out = compress(b, q) }
        if (shrink) b.recycle()
        return out
    }

    private val cleaner = java.util.concurrent.Executors.newSingleThreadExecutor { r -> Thread(r).apply { isDaemon = true } }

    /** The temporary file is removed in the background so the next picture can be sent at once. */
    private fun deleteFile(id: String, tok: String) {
        try {
            cleaner.execute {
                try {
                    val d = open("$API/drive/v3/files/$id", tok, "DELETE")
                    d.responseCode
                    d.disconnect()
                } catch (e: Exception) { }
            }
        } catch (e: Exception) { }
    }

    private fun ocr(tok: String, bmp: Bitmap, lang: String?): String? {
        val jpg = toJpeg(bmp)
        val boundary = "subreader" + System.currentTimeMillis()
        val meta = "{\"name\":\"subtitlereader-temp\",\"mimeType\":\"application/vnd.google-apps.document\"}"
        val url = "$API/upload/drive/v3/files?uploadType=multipart&fields=id" + (if (lang != null) "&ocrLanguage=$lang" else "")
        var attempt = 0
        var conn: HttpURLConnection? = null
        var code = 0
        while (true) {
            val con = open(url, tok, "POST")
            conn = con
            con.doOutput = true
            con.setRequestProperty("Content-Type", "multipart/related; boundary=$boundary")
            con.outputStream.use { o ->
                o.write("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n--$boundary\r\nContent-Type: image/jpeg\r\n\r\n".toByteArray())
                o.write(jpg)
                o.write("\r\n--$boundary--".toByteArray())
            }
            code = con.responseCode
            // too many requests: wait a little and try again
            if ((code == 429 || code == 403) && attempt < 3) {
                attempt++
                con.disconnect()
                Thread.sleep(2000L * attempt)
                continue
            }
            break
        }
        if (code == 401) throw Unauthorized()
        if (code !in 200..299) return null
        val id = JSONObject((conn ?: return null).inputStream.bufferedReader().readText()).optString("id", "")
        if (id.isEmpty()) return null
        try {
            val ex = open("$API/drive/v3/files/$id/export?mimeType=text/plain", tok, "GET")
            val c2 = ex.responseCode
            if (c2 == 401) throw Unauthorized()
            if (c2 !in 200..299) return null
            val raw = ex.inputStream.bufferedReader(Charsets.UTF_8).readText()
            // a subtitle is one line of text: join the lines Google found
            return TextFix.fix(raw.replace('\r', ' ').replace('\n', ' '))
        } finally {
            deleteFile(id, tok)
        }
    }

    private fun langHint(c: Context): String? = when (Prefs.ocrLang(c)) { "fas" -> "fa"; "eng" -> "en"; else -> null }

    /**
     * Reads a picture (dark text on a light sheet works best) through Google Drive.
     * Null if the Drive engine is off, nothing was found, or the request failed. After eight failures in a
     * row the engine stays off until [resetRun], so a lost connection does not slow the whole conversion.
     */
    fun read(c: Context, bmp: Bitmap): String? {
        if (Prefs.ocrEngine(c) != "drive" || fails >= 8) return null
        var tok = session(c)
        if (tok == null) { fails = 8; return null }
        return try {
            val t = try {
                ocr(tok!!, bmp, langHint(c))
            } catch (e: Unauthorized) {
                token = null
                tok = session(c)
                if (tok == null) null else ocr(tok!!, bmp, langHint(c))
            }
            fails = 0
            t
        } catch (e: Exception) {
            fails++
            try { Thread.sleep(1000) } catch (ie: InterruptedException) { }
            null
        }
    }
}
