package com.example.subtitlereader

import android.os.Build
import java.io.File

/** Bridge to whisper.cpp (see app/src/main/cpp/whisper_jni.cpp). */
object Whisper {
    init { System.loadLibrary("whisper_jni") }

    external fun nativeInit(path: String): Long
    external fun nativeFree(ctx: Long)
    external fun nativeAbort(abort: Boolean)
    external fun nativeTranscribe(ctx: Long, samples: FloatArray, n: Int, lang: String, threads: Int, sensitive: Boolean): Int
    external fun nativeSegStart(ctx: Long, i: Int): Long
    external fun nativeSegEnd(ctx: Long, i: Int): Long
    external fun nativeSegText(ctx: Long, i: Int): ByteArray
    external fun nativeSegNoSpeech(ctx: Long, i: Int): Float
    external fun nativeLang(ctx: Long): String

    class Seg(val startMs: Long, val endMs: Long, val text: String, val noSpeech: Float)

    /** The native code is built for 64-bit phones with fp16 and dot-product instructions (most phones since about 2018). */
    fun cpuSupported(): Boolean {
        if (!Build.SUPPORTED_ABIS.contains("arm64-v8a")) return false
        return try {
            val feat = File("/proc/cpuinfo").readLines().firstOrNull { it.startsWith("Features") } ?: return true
            (feat.contains("asimdhp") || feat.contains("fphp")) && feat.contains("asimddp")
        } catch (e: Exception) { true }
    }
}

/** One loaded model. Not thread safe: use from one worker thread. */
class WhisperEngine private constructor(private var ctx: Long) {

    companion object {
        fun open(path: String): WhisperEngine? {
            val c = try { Whisper.nativeInit(path) } catch (e: Throwable) { 0L }
            return if (c == 0L) null else WhisperEngine(c)
        }
    }

    /** Segments of one window (times relative to the window start), null if it failed or was cancelled. [lang] may be "auto". */
    fun transcribe(samples: FloatArray, n: Int, lang: String, threads: Int, sensitive: Boolean = false): List<Whisper.Seg>? {
        val c = ctx
        if (c == 0L) return null
        val count = Whisper.nativeTranscribe(c, samples, n, lang, threads, sensitive)
        if (count < 0) return null
        val out = ArrayList<Whisper.Seg>(count)
        for (i in 0 until count) {
            val t = String(Whisper.nativeSegText(c, i), Charsets.UTF_8)
            out.add(Whisper.Seg(Whisper.nativeSegStart(c, i) * 10, Whisper.nativeSegEnd(c, i) * 10, t, Whisper.nativeSegNoSpeech(c, i)))
        }
        return out
    }

    fun lang(): String = if (ctx == 0L) "en" else Whisper.nativeLang(ctx)

    fun abort() { Whisper.nativeAbort(true) }

    fun close() {
        val c = ctx
        ctx = 0L
        if (c != 0L) Whisper.nativeFree(c)
    }
}
