package com.example.subtitlereader

import android.content.Context
import android.net.Uri

/** What the screens read while a conversion runs (one conversion at a time). */
object Convert {
    @Volatile var running = false
    @Volatile var key: String? = null
    @Volatile var name = ""
    @Volatile var percent = 0
    @Volatile var status = ""
    @Volatile var error: String? = null
    @Volatile var finished = false
    @Volatile var stoppedByUser = false
    @Volatile var lang = ""
    @Volatile var lastOrig = ""
    @Volatile var orig: LiveSubs? = null
    @Volatile var worker: SpeechConverter? = null
    @Volatile var startedAt = 0L
    @Volatile var startedFromMs = 0L
    @Volatile var coveredMs = 0L
    @Volatile var durationMs = 0L
}

/**
 * Film sound -> text (whisper.cpp, on the phone).
 * The sound is cut into windows of up to 30 seconds at the quietest point near the end of each window.
 */
class SpeechConverter(
    private val context: Context,
    private val uri: Uri,
    private val key: String,
    private val trackIndex: Int,
    private val durationMs: Long,
    private val fresh: Boolean,
    private val onProgress: () -> Unit
) {
    @Volatile private var cancelled = false
    private var engine: WhisperEngine? = null
    private val win = 30 * AudioDecoder.RATE
    private var buf = FloatArray(win + AudioDecoder.RATE * 5)
    private var bn = 0
    private var winStartMs = 0L

    private val langVotes = ArrayList<String>()
    private var lockedLang: String? = null

    private lateinit var orig: LiveSubs
    private var lastText = ""
    private var repeats = 0

    fun cancel() {
        cancelled = true
        engine?.abort()
    }

    private fun fail(msg: String) {
        Convert.error = msg
        Convert.status = msg
    }

    fun run() {
        val c = Convert
        try {
            if (fresh) {
                SpeechStore.deletePartial(context, key)
            }
            val modelFile = Prefs.modelFile(context)
            if (modelFile == null) { fail("هیچ مدل Whisper اضافه نشده است. از تنظیمات یک مدل اضافه کنید"); return }
            if (!Whisper.cpuSupported()) { fail("پردازنده‌ی این گوشی برای تشخیص گفتار پشتیبانی نمی‌شود"); return }
            c.status = "در حال بارگذاری مدل…"
            onProgress()
            val eng = WhisperEngine.open(modelFile.path)
            if (eng == null) { fail("مدل بارگذاری نشد. فایل باید مدل ggml از whisper.cpp باشد و حافظه‌ی کافی وجود داشته باشد"); return }
            engine = eng

            val op = SpeechStore.origPart(context, key)
            val om = SpeechStore.origMeta(context, key)
            orig = (if (fresh) null else LiveSubs.load(op, om)) ?: LiveSubs(op, om)
            val from = orig.coveredUpTo
            c.orig = orig
            c.startedFromMs = from
            c.coveredMs = from
            SpeechStore.lang(context, key)?.let { lockedLangFromDisk(it) }
            if (Prefs.lang(context) != "auto") lockedLang = Prefs.lang(context)
            c.startedAt = System.currentTimeMillis()
            c.status = "در حال خواندن صدا و تشخیص گفتار…"
            onProgress()

            val dec = AudioDecoder(context, uri)
            val err = dec.decode(
                trackIndex, from, { cancelled },
                { base -> winStartMs = base },
                { data, n -> addSamples(data, n) }
            )
            if (err != null) { fail(err); saveState(); return }
            if (cancelled) { saveState(); return }

            if (bn > 0) processWindow(true)
            if (cancelled) { saveState(); return }

            finish()
        } catch (e: Throwable) {
            fail("خطا: " + (e.message ?: e.javaClass.simpleName))
            try { saveState() } catch (ignored: Throwable) {}
        } finally {
            engine?.close()
            engine = null
        }
    }

    private fun lockedLangFromDisk(l: String) {
        // a resumed conversion keeps the language found the first time
        if (Prefs.lang(context) == "auto") lockedLang = l
    }

    private fun saveState() {
        orig.save()
    }

    private fun finish() {
        orig.finish()
        try {
            SpeechStore.orig(context, key).writeText(orig.toSrt())
            SpeechStore.setLang(context, key, Convert.lang)
            SpeechStore.deletePartial(context, key)
        } catch (e: Exception) {
            fail("ذخیره‌ی فایل زیرنویس ناموفق بود")
            return
        }
        Convert.percent = 100
        Convert.finished = true
        Convert.status = "ساخت زیرنویس تمام شد"
    }

    private fun addSamples(data: FloatArray, n: Int) {
        if (bn + n > buf.size) buf = buf.copyOf(maxOf(buf.size * 2, bn + n))
        System.arraycopy(data, 0, buf, bn, n)
        bn += n
        while (bn >= win && !cancelled) processWindow(false)
    }

    /** Cut near the end of a full window where the sound is quietest, so words are rarely split. */
    private fun quietCut(len: Int): Int {
        val block = AudioDecoder.RATE / 10
        var best = len
        var bestE = Double.MAX_VALUE
        var s = len - 8 * AudioDecoder.RATE
        while (s + block <= len - block) {
            var e = 0.0
            for (i in s until s + block) e += buf[i].toDouble() * buf[i]
            if (e < bestE) { bestE = e; best = s + block / 2 }
            s += block
        }
        return best
    }

    private fun hasSpeech(s: FloatArray, n: Int): Boolean {
        val frame = AudioDecoder.RATE / 50 // 20 ms
        val count = n / frame
        if (count < 10) return false
        val db = DoubleArray(count)
        for (f in 0 until count) {
            var e = 0.0
            val o = f * frame
            for (i in 0 until frame) e += s[o + i].toDouble() * s[o + i]
            db[f] = 10 * Math.log10(e / frame + 1e-10)
        }
        val sorted = db.sortedArray()
        val floor = sorted[count / 10]
        val limit = maxOf(floor + 9.0, -52.0)
        var loud = 0
        for (v in db) if (v > limit) loud++
        return loud >= 12
    }

    private fun processWindow(last: Boolean) {
        val len = if (bn >= win) win else bn
        var cut = len
        if (!last && len == win) cut = quietCut(len)
        val start = winStartMs
        transcribe(cut, start)
        System.arraycopy(buf, cut, buf, 0, bn - cut)
        bn -= cut
        winStartMs += cut * 1000L / AudioDecoder.RATE
        orig.covered(winStartMs)
        Convert.coveredMs = winStartMs
        if (durationMs > 0) Convert.percent = (winStartMs * 100 / durationMs).toInt().coerceIn(0, 99)
        orig.save()
        onProgress()
    }

    private fun transcribe(cut: Int, startMs: Long) {
        val eng = engine ?: return
        val samples = buf.copyOf(maxOf(cut, AudioDecoder.RATE * 11 / 10))
        val boost = Prefs.voiceBoost(context)
        if (boost > 0) VoiceBoost.process(samples, cut, boost)   // only the copy is changed, never the stored sound
        if (!hasSpeech(samples, cut)) return
        val lang = lockedLang ?: "auto"
        val segs = eng.transcribe(samples, samples.size, lang, Prefs.threads(context), boost > 0) ?: return
        if (segs.isEmpty()) return

        val detected = if (lang == "auto") eng.lang() else lang
        if (lockedLang == null) {
            langVotes.add(detected)
            if (langVotes.size >= 3) {
                lockedLang = langVotes.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
                lockedLang?.let { SpeechStore.setLang(context, key, it) }
            }
        }
        Convert.lang = lockedLang ?: detected

        for (s in segs) {
            val text = clean(s.text)
            if (text.isEmpty()) continue
            if (boost > 0 && s.noSpeech > 0.9f) continue   // after boosting, noise can make the model invent lines
            if (text == lastText) { repeats++; if (repeats >= 2) continue } else { lastText = text; repeats = 0 }
            val st = startMs + s.startMs
            val en = startMs + maxOf(s.endMs, s.startMs + 500)
            orig.add(st, en, text)
            Convert.lastOrig = text
        }
    }

    private val noteRe = Regex("\\[[^\\]]*\\]|\\([^)]*\\)|\\*[^*]*\\*|♪+")
    private val spaceRe = Regex("\\s+")

    private fun clean(t: String): String =
        t.replace(noteRe, " ").replace(spaceRe, " ").trim()
}
