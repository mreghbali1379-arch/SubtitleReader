package com.example.subtitlereader

import android.content.Context

/** Small settings store shared by the main screen and the settings screen. */
object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)

    /** Package name of the chosen speech engine, or null for the phone's default. */
    fun engine(c: Context): String? = sp(c).getString("tts_engine", null)
    fun setEngine(c: Context, e: String?) { sp(c).edit().putString("tts_engine", e).apply() }

    fun rate(c: Context): Float = sp(c).getFloat("speech_rate", 1.0f)
    fun setRate(c: Context, r: Float) { sp(c).edit().putFloat("speech_rate", r).apply() }

    fun volume(c: Context): Float = sp(c).getFloat("speech_volume", 1.0f)
    fun setVolume(c: Context, v: Float) { sp(c).edit().putFloat("speech_volume", v).apply() }

    /** Manual subtitle delay in ms (positive = subtitle later). Reset when a new film or subtitle is picked. */
    fun syncOffset(c: Context): Long = sp(c).getLong("sync_offset", 0L)
    fun setSyncOffset(c: Context, v: Long) { sp(c).edit().putLong("sync_offset", v).apply() }

    fun syncSupported(c: Context): Boolean = sp(c).getBoolean("sync_supported", false)
    fun setSyncSupported(c: Context, v: Boolean) { sp(c).edit().putBoolean("sync_supported", v).apply() }

    /** Volume of the film's own sound (0..1). */
    fun movieVolume(c: Context): Float = sp(c).getFloat("movie_volume", 1.0f)
    fun setMovieVolume(c: Context, v: Float) { sp(c).edit().putFloat("movie_volume", v).apply() }

    /** Seconds jumped by double tap and by the screen-reader scroll gesture. */
    fun skipSeconds(c: Context): Int = sp(c).getInt("skip_seconds", 10)
    fun setSkipSeconds(c: Context, v: Int) { sp(c).edit().putInt("skip_seconds", v).apply() }

    /** Seconds before the player buttons hide on their own. */
    fun hideSeconds(c: Context): Int = sp(c).getInt("hide_seconds", 5)
    fun setHideSeconds(c: Context, v: Int) { sp(c).edit().putInt("hide_seconds", v).apply() }

    /** Recently opened films as (uri, name), newest first. */
    fun recents(c: Context): List<Pair<String, String>> {
        val raw = sp(c).getString("recents", "") ?: ""
        return raw.split("\n").filter { it.isNotBlank() }.mapNotNull { line ->
            val i = line.indexOf('\t')
            if (i <= 0) null else Pair(line.substring(0, i), line.substring(i + 1))
        }
    }

    private fun saveRecents(c: Context, l: List<Pair<String, String>>) {
        sp(c).edit().putString("recents", l.take(20).joinToString("\n") { it.first + "\t" + it.second }).apply()
    }

    fun addRecent(c: Context, uri: String, name: String) {
        val l = recents(c).filter { it.first != uri }.toMutableList()
        l.add(0, Pair(uri, name.replace('\t', ' ').replace('\n', ' ')))
        saveRecents(c, l)
    }

    fun removeRecent(c: Context, uri: String) {
        saveRecents(c, recents(c).filter { it.first != uri })
    }

    /** Read subtitles that are burned into the picture (hard subs). */
    fun hardsub(c: Context): Boolean = sp(c).getBoolean("hardsub", false)
    fun setHardsub(c: Context, v: Boolean) { sp(c).edit().putBoolean("hardsub", v).apply() }

    /** Height of the bottom part of the picture that is read, in percent. */
    fun hardsubBand(c: Context): Int = sp(c).getInt("hardsub_band", 30)
    fun setHardsubBand(c: Context, v: Int) { sp(c).edit().putInt("hardsub_band", v).apply() }

    /** Milliseconds between the frames read when building a subtitle file from hard-coded subtitles. */
    fun hardsubStepMs(c: Context): Int = sp(c).getInt("hardsub_step_ms", 2000)
    fun setHardsubStepMs(c: Context, v: Int) { sp(c).edit().putInt("hardsub_step_ms", v).apply() }

    /** OCR language: "all" (every installed language) or one language code such as fas or eng. */
    fun ocrLang(c: Context): String = sp(c).getString("ocr_lang", "all") ?: "all"
    fun setOcrLang(c: Context, v: String) { sp(c).edit().putString("ocr_lang", v).apply() }

    /** OCR model: "best" (more accurate, slower) or "fast". */
    fun ocrModel(c: Context): String = sp(c).getString("ocr_model", "best") ?: "best"
    fun setOcrModel(c: Context, v: String) { sp(c).edit().putString("ocr_model", v).apply() }

    /** "tess" = offline Tesseract only, "drive" = also use Google Drive OCR when converting a whole film to a subtitle file. */
    /** With the Drive engine: also send every single frame that shows a subtitle to Google (slower, more readings per line). */
    fun driveAllFrames(c: Context): Boolean = sp(c).getBoolean("drive_all_frames", false)
    fun setDriveAllFrames(c: Context, v: Boolean) { sp(c).edit().putBoolean("drive_all_frames", v).apply() }

    /** With the Drive engine: live reading while the film plays also goes through Google (each line arrives a few seconds late). */
    fun driveLive(c: Context): Boolean = sp(c).getBoolean("drive_live", false)
    fun setDriveLive(c: Context, v: Boolean) { sp(c).edit().putBoolean("drive_live", v).apply() }

    /**
     * While a subtitle is being built, the film waits until the subtitle is ready this many seconds ahead of the
     * film position. 15 = the old behaviour (play at once, short waits). More than 15: playback also starts by itself
     * once that much subtitle exists.
     */
    fun leadSeconds(c: Context): Int = sp(c).getInt("lead_seconds", 15)
    fun setLeadSeconds(c: Context, v: Int) { sp(c).edit().putInt("lead_seconds", v).apply() }

    fun ocrEngine(c: Context): String = sp(c).getString("ocr_engine", "tess") ?: "tess"
    fun setOcrEngine(c: Context, v: String) { sp(c).edit().putString("ocr_engine", v).apply() }

    // ---------- subtitle from the film's sound (Whisper) ----------

    /** Whisper models (copied or downloaded into the app's private folder). */
    fun modelsDir(c: Context): java.io.File = java.io.File(c.filesDir, "models").also { it.mkdirs() }

    fun models(c: Context): List<java.io.File> =
        (modelsDir(c).listFiles() ?: emptyArray()).filter { it.isFile && it.name.endsWith(".bin") }.sortedBy { it.name }

    /** The chosen model file, or the only/first installed one, or null when none is installed. */
    fun modelFile(c: Context): java.io.File? {
        val all = models(c)
        val name = sp(c).getString("model", null)
        return all.firstOrNull { it.name == name } ?: all.firstOrNull()
    }

    fun setModel(c: Context, name: String) { sp(c).edit().putString("model", name).apply() }

    /** Language spoken in the film: "auto" or a language code. */
    fun lang(c: Context): String = sp(c).getString("lang", "auto") ?: "auto"
    fun setLang(c: Context, v: String) { sp(c).edit().putString("lang", v).apply() }

    fun threads(c: Context): Int {
        val def = Runtime.getRuntime().availableProcessors().coerceIn(2, 4)
        return sp(c).getInt("threads", def)
    }
    fun setThreads(c: Context, v: Int) { sp(c).edit().putInt("threads", v).apply() }

    // ---------- subtitle translation ----------

    /** Language subtitles are translated to ("fa" by default). */
    fun targetLang(c: Context): String = sp(c).getString("target_lang", "fa") ?: "fa"
    fun setTargetLang(c: Context, v: String) { sp(c).edit().putString("target_lang", v).apply() }

    /** Language of the subtitle to translate: "auto" or a language code (auto works with the online methods only). */
    fun translateFrom(c: Context): String = sp(c).getString("translate_from", "en") ?: "en"
    fun setTranslateFrom(c: Context, v: String) { sp(c).edit().putString("translate_from", v).apply() }

    /** "offline" (ML Kit on the phone), "online" (Google Translate first) or "gemini" (own key); offline is the fallback. */
    fun translateMode(c: Context): String = sp(c).getString("translate_mode", "offline") ?: "offline"
    fun setTranslateMode(c: Context, v: String) { sp(c).edit().putString("translate_mode", v).apply() }

    fun geminiKey(c: Context): String = sp(c).getString("gemini_key", "") ?: ""
    fun setGeminiKey(c: Context, v: String) { sp(c).edit().putString("gemini_key", v.trim()).apply() }
    fun geminiModel(c: Context): String = sp(c).getString("gemini_model", GeminiTranslator.DEFAULT_MODEL) ?: GeminiTranslator.DEFAULT_MODEL
    fun setGeminiModel(c: Context, v: String) { sp(c).edit().putString("gemini_model", v.trim()).apply() }
}
