plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.subtitlereader"
    compileSdk = 34
    ndkVersion = "26.1.10909125"
    defaultConfig {
        applicationId = "com.example.subtitlereader"
        minSdk = 24
        targetSdk = 34
        versionCode = 6
        versionName = "1.6"
        // the speech recognition code (whisper.cpp) is built for 64-bit phones only
        ndk { abiFilters += listOf("arm64-v8a") }
        externalNativeBuild {
            cmake {
                cppFlags += listOf("-O3", "-std=c++17")
                arguments += listOf("-DANDROID_STL=c++_static")
            }
        }
    }
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false; checkReleaseBuilds = false }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")
    implementation("com.google.android.gms:play-services-auth:21.2.0")
    implementation("cz.adaptech.tesseract4android:tesseract4android:4.7.0")
    implementation("com.google.mlkit:translate:17.0.3")
}

// whisper.cpp (speech recognition) is fetched by the build itself when it is not in the project folder yet,
// so it works with any workflow, also one that only unpacks the project zip.
val whisperDir = file("src/main/cpp/whisper.cpp")
val fetchWhisper by tasks.registering(Exec::class) {
    onlyIf { !File(whisperDir, "CMakeLists.txt").exists() }
    commandLine("sh", "-c",
        "rm -rf '${whisperDir.path}'; " +
        "git clone --depth 1 --branch v1.7.5 https://github.com/ggml-org/whisper.cpp '${whisperDir.path}' || " +
        "{ rm -rf '${whisperDir.path}'; git clone --depth 1 https://github.com/ggml-org/whisper.cpp '${whisperDir.path}'; }; " +
        "rm -rf '${whisperDir.path}/.git'")
}
tasks.configureEach {
    if (name.startsWith("configureCMake") || name.startsWith("generateJsonModel") ||
        name.startsWith("buildCMake") || name.startsWith("externalNativeBuild")) {
        dependsOn(fetchWhisper)
    }
}
